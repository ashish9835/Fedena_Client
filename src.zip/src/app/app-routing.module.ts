import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'tutorial',
    pathMatch: 'full'
  },
  {
    path: 'tutorial',
    loadChildren: () => import('../pages/tutorial/tutorial.module').then(m => m.TutorialPageModule)
  },
  {
    path: 'static-page/:id',
    loadChildren: () => import('../pages/static-page/static-page.module').then(m => m.StaticPagePageModule)
  },
  {
    path: 'demo-login-email',
    loadChildren: () => import('../pages/login-pages/demo-login-email/demo-login-email.module').then(m => m.DemoLoginEmailPageModule)
  },
  {
    path: 'login-email',
    loadChildren: () => import('../pages/login-pages/login-email/login-email.module').then(m => m.LoginEmailPageModule)
  },
  {
    path: 'contact-admin',
    loadChildren: () => import('../pages/login-pages/contact-admin/contact-admin.module').then(m => m.ContactAdminPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('../pages/login/login.module').then(m => m.LoginPageModule)
  },
  {
    path: 'otp-email',
    loadChildren: () => import('../pages/login-pages/otp-email/otp-email.module').then(m => m.OtpEmailPageModule)
  },
  {
    path: 'otp',
    loadChildren: () => import('../pages/otp/otp.module').then(m => m.OtpPageModule)
  },
  {
    path: 'login-confirmation/:token',
    loadChildren: () => import('../pages/login-confirmation/login-confirmation.module').then(m => m.LoginConfirmationPageModule)
  },
  {
    path: 'my-profile',
    loadChildren: () => import('../pages/my-profile/my-profile.module').then(m => m.MyProfilePageModule)
  },
  {
    path: 'tabs',
    loadChildren: () => import('../pages/tabs/tabs.module').then(m => m.TabsPageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('../pages/home/home.module').then(m => m.HomePageModule)
  },
  {
    path: 'account',
    loadChildren: () => import('../pages/account/account.module').then(m => m.AccountPageModule)
  },
  {
    path: 'notification/:count',
    loadChildren: () => import('../pages/notification/notification.module').then(m => m.NotificationPageModule)
  },
  {
    path: 'announcements',
    loadChildren: () => import('../pages/announcements/announcements.module').then(m => m.AnnouncementsPageModule)
  },
  {
    path: 'announcements-details',
    loadChildren: () => import('../pages/announcements-details/announcements-details.module').then(m => m.AnnouncementsDetailsPageModule)
  },
  {
    path: 'my-institution',
    loadChildren: () => import('../pages/my-institution/my-institution.module').then(m => m.MyInstitutionPageModule)
  },
  {
    path: 'events',
    loadChildren: () => import('../pages/events/events.module').then(m => m.EventsPageModule)
  },
  {
    path: 'event-modal',
    loadChildren: () => import('../pages/event-modal/event-modal.module').then(m => m.EventModalPageModule)
  },
  {
    path: 'my-class',
    loadChildren: () => import('../pages/my-class/my-class.module').then(m => m.MyClassPageModule)
  },
  {
    path: 'student-class',
    loadChildren: () => import('../pages/student-class/student-class.module').then(m => m.StudentClassPageModule)
  },
  {
    path: 'subjects',
    loadChildren: () => import('../pages/subjects/subjects.module').then(m => m.SubjectsPageModule)
  },
  {
    path: 'timetable',
    loadChildren: () => import('../pages/timetable/timetable.module').then(m => m.TimetablePageModule)
  },
  {
    path: 'student-attendance',
    loadChildren: () => import('../pages/student-attendance/student-attendance.module').then(m => m.StudentAttendancePageModule)
  },
  {
    path: 'student-attendance-details',
    loadChildren: () => import('../pages/student-attendance/student-attendance-details/student-attendance-details.module').then(m => m.StudentAttendanceDetailsPageModule)
  },
  {
    path: 'students',
    loadChildren: () => import('../pages/students/students.module').then(m => m.StudentsPageModule)
  },
  {
    path: 'batch-subjects',
    loadChildren: () => import('../pages/batch-subjects/batch-subjects.module').then(m => m.BatchSubjectsPageModule)
  },
  {
    path: 'attendance-report',
    loadChildren: () => import('../pages/attendance/attendance-report/attendance-report.module').then(m => m.AttendanceReportPageModule)
  },
  {
    path: 'report-students-list',
    loadChildren: () => import('../pages/attendance/attendance-report/report-students-list/report-students-list.module').then(m => m.ReportStudentsListPageModule)
  },
  {
    path: 'report-subjects-list',
    loadChildren: () => import('../pages/attendance/attendance-report/report-subjects-list/report-subjects-list.module').then(m => m.ReportSubjectsListPageModule)
  },
  {
    path: 'report-subject-students-list',
    loadChildren: () => import('../pages/attendance/attendance-report/report-subjects-list/students-list/students-list.module').then(m => m.ReportSubjectStudentsListPageModule)
  },
  {
    path: 'academic-days',
    loadChildren: () => import('../pages/attendance/academic-days/academic-days.module').then(m => m.AcademicDaysPageModule)
  },
  {
    path: 'students-list',
    loadChildren: () => import('../pages/attendance/students-list/students-list.module').then(m => m.StudentsListPageModule)
  },
  {
    path: 'subjects-list',
    loadChildren: () => import('../pages/attendance/subjects-list/subjects-list.module').then(m => m.SubjectsListPageModule)
  },
  {
    path: 'subject-absentees-list',
    loadChildren: () => import('../pages/attendance/subject-absentees-list/subject-absentees-list.module').then(m => m.SubjectAbsenteesListPageModule)
  },
  {
    path: 'gallery',
    loadChildren: () => import('../pages/gallery/gallery.module').then(m => m.GalleryPageModule)
  },
  {
    path: 'albums/:id',
    loadChildren: () => import('../pages/albums/albums.module').then(m => m.AlbumsPageModule)
  },
  {
    path: 'lightbox-image',
    loadChildren: () => import('../pages/lightbox-image/lightbox-image.module').then(m => m.LightBoxImagePageModule)
  },
  {
    path: 'my-leave',
    loadChildren: () => import('../pages/my-leave/my-leave.module').then(m => m.MyLeavePageModule)
  },
  {
    path: 'apply-leave/:type',
    loadChildren: () => import('../pages/my-leave/apply-leave/apply-leave.module').then(m => m.ApplyLeavePageModule)
  },
  {
    path: 'leave-details',
    loadChildren: () => import('../pages/leave-details/leave-details.module').then(m => m.LeaveDetailsPageModule)
  },
  {
    path: 'leave-requests',
    loadChildren: () => import('../pages/leave-requests/leave-requests.module').then(m => m.LeaveRequestsPageModule)
  },
  {
    path: 'leave-requests-details',
    loadChildren: () => import('../pages/leave-requests-details/leave-requests-details.module').then(m => m.LeaveRequestsDetailsPageModule)
  },
  {
    path: 'fees',
    loadChildren: () => import('../pages/fees/fees.module').then(m => m.FeesPageModule)
  },
  {
    path: 'fees-details',
    loadChildren: () => import('../pages/fees-details/fees-details.module').then(m => m.FeesDetailsPageModule)
  },
  {
    path: 'transaction-details',
    loadChildren: () => import('../pages/fees-details/transaction-details/transaction-details.module').then(m => m.TransactionDetailsPageModule)
  },
  {
    path: 'pay-all-fees',
    loadChildren: () => import('../pages/pay-all-fees/pay-all-fees.module').then(m => m.PayAllFeesPageModule)
  },
  {
    path: 'errors',
    loadChildren: () => import('../pages/errors/errors.module').then(m => m.ErrorsPageModule)
  },
  {
    path: 'exam-reports',
    loadChildren: () => import('../pages/exam-reports/exam-reports.module').then(m => m.ExamReportsPageModule)
  },
  {
    path: 'assignments',
    loadChildren: () => import('../pages/assignments/assignments.module').then(m => m.AssignmentsPageModule)
  },
  {
    path: 'assignment-create',
    loadChildren: () => import('../pages/assignments/assignment-create/assignment-create.module').then(m => m.AssignmentCreatePageModule)
  },
  {
    path: 'attendees-selection',
    loadChildren: () => import('../pages/assignments/attendees-selection/attendees-selection.module').then(m => m.AttendeesSelectionComponentModule)
  },
  {
    path: 'assignment-details',
    loadChildren: () => import('../pages/assignments/assignment-details/assignment-details.module').then(m => m.AssignmentDetailsPageModule)
  },
  {
    path: 'assignment-response-create',
    loadChildren: () => import('../pages/assignments/assignment-response-create/assignment-response-create.module').then(m => m.AssignmentResponseCreatePageModule)
  },
  {
    path: 'assignment-response-details/:id',
    loadChildren: () => import('../pages/assignments/assignment-response-details/assignment-response-details.module').then(m => m.AssignmentResponseDetailsPageModule)
  },
  {
    path: 'walkthrough',
    loadChildren: () => import('../pages/walkthrough/walkthrough.module').then(m => m.WalkthroughPageModule)
  },
  {
    path: 'school-search',
    loadChildren: () => import('../pages/school-search/school-search.module').then(m => m.SchoolSearchPageModule)
  },
  {
    path: 'schools-list',
    loadChildren: () => import('../pages/schools-list/schools-list.module').then(m => m.SchoolsListPageModule)
  },
  {
    path: 'school-login',
    loadChildren: () => import('../pages/school-login/school-login.module').then(m => m.SchoolLoginPageModule)
  },
  {
    path: 'transport',
    loadChildren: () => import('../pages/transport/transport.module').then(m => m.TransportPageModule)
  },
  {
    path: 'track',
    loadChildren: () => import('../pages/track/track.module').then(m => m.TrackPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
