import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./pages/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'announcment',
    loadChildren: () => import('./pages/announcment/announcment.module').then( m => m.AnnouncmentPageModule)
  },
  {
    path: 'read-more',
    loadChildren: () => import('./pages/read-more/read-more.module').then( m => m.ReadMorePageModule)
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./pages/dashboard/dashboard.module').then( m => m.DashboardPageModule)
  },
  {
    path: 'attendance',
    loadChildren: () => import('./pages/attendance/attendance.module').then( m => m.AttendancePageModule)
  },
  {
    path: 'gallery',
    loadChildren: () => import('./pages/gallery/gallery.module').then( m => m.GalleryPageModule)
  },
  {
    path: 'albums',
    loadChildren: () => import('./pages/albums/albums.module').then( m => m.AlbumsPageModule)
  },
  {
    path: 'selected-photo',
    loadChildren: () => import('./pages/selected-photo/selected-photo.module').then( m => m.SelectedPhotoPageModule)
  },
  {
    path: 'change-password',
    loadChildren: () => import('./pages/change-password/change-password.module').then( m => m.ChangePasswordPageModule)
  },
  {
    path: 'notification-setting',
    loadChildren: () => import('./pages/notification-setting/notification-setting.module').then( m => m.NotificationSettingPageModule)
  },
  {
    path: 'gate-management',
    loadChildren: () => import('./pages/gate-management/gate-management.module').then( m => m.GateManagementPageModule)
  },
  {
    path: 'filter-reports',
    loadChildren: () => import('./pages/filter-reports/filter-reports.module').then( m => m.FilterReportsPageModule)
  },
  {
    path: 'make-attendance',
    loadChildren: () => import('./pages/make-attendance/make-attendance.module').then( m => m.MakeAttendancePageModule)
  },
  {
    path: 'view-reports',
    loadChildren: () => import('./pages/view-reports/view-reports.module').then( m => m.ViewReportsPageModule)
  },
  {
    path: 'notification-status',
    loadChildren: () => import('./pages/notification-status/notification-status.module').then( m => m.NotificationStatusPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
