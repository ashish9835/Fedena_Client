import { Component, OnInit, ViewChild } from '@angular/core';
import { Platform, MenuController, NavController, AlertController, IonRouterOutlet, ModalController, ActionSheetController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Storage } from '@ionic/storage';
import { Router, RouterOutlet } from '@angular/router';
import { Network } from '@ionic-native/network/ngx';
import { Push, PushObject, PushOptions } from '@ionic-native/push/ngx';

import { TranslateService } from '@ngx-translate/core';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { EventsService } from 'src/providers/events/events.service';
import { School } from 'src/providers/school';
import { CommonService } from 'src/providers/common/common.service';
import { Profile } from 'src/providers/profile';
import { User } from 'src/providers/user';
import { Authentication } from 'src/providers/providers';
import { TutorialModel } from 'src/models/tutorials/tutorials';
import { AppSettings } from 'src/models/app-settings';
import { MultiSchool } from 'src/providers/multi-school';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
@Component({
  selector: 'app-root',
  templateUrl: 'app.html',
  styleUrls: ['app.scss']
})

export class AppComponent implements OnInit {
  // @ViewChild(Content, { static: false }) content: any;
  hasInternetConnection: boolean = true;
  initCompleted: boolean = false;
  @ViewChild(IonRouterOutlet, { static: true }) routerOutlet: IonRouterOutlet;
  multiSchoolMode = AppSettings.MULTI_SCHOOL_MODE;
  enteredFromNotification: boolean = false;
  test: any;
  id: any;
  testID: any;
  appSettingsa: any = AppSettings;
  notificationContent: string;
  loading: any;
  showswap: boolean = false;
  swapicon = 'chevron-down-sharp';
  name = '';
  currentAccountRole: any;
  currentAccountId: any;
  profileTitle = '';
  profileSubTitle = '';
  token = '';
  profilePhoto = 'assets/img/appicon.png';
  accounts: any;
  users: any;
  role: string;
  schoolData: any;

  logoname = 'assets/img/appicon.png';
  schoolLogo = AppSettings.SCHOOL_LOGO;
  // sender_device_id = AppSettings.SENDER_ID

  schoolName: string;
  device = { device_id: '0', device_type: '' };
  user = { name: 'not logged in', userclass: 'NA', image: this.logoname };
  statusbarColour = AppSettings.COLOUR_STATUS_BAR;
  active = 'none';
  loaderStatus: any;
  exitApp: boolean;
  isExitAlertShown: boolean;
  inappLanguageSwitching: boolean = AppSettings.INAPP_LANGUAGE_SWITCHING;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private network: Network,
    private events: EventsService,
    private menuCtrl: MenuController,
    private school: School,
    private commonService: CommonService,
    private translate: TranslateService,
    private profileService: Profile,
    private userService: User,
    private storage: Storage,
    private router: Router,
    private authService: Authentication,
    private keyboard: Keyboard,
    private navCtrl: NavController,
    private push: Push,
    private alertCtrl: AlertController,
    private modalController: ModalController,
    private actionsheetController: ActionSheetController,
    private multiSchoolService: MultiSchool,
    private profile: Profile,
    private localNotifications: LocalNotifications
  ) {
    console.log('in constructor');

    this.initializeApp();
  }

  async initializeApp() {
    this.storage.ready().then(async () => {
      // this.storage.clear();
      this.checkDisconnection();
      this.changeDir('ltr')
      this.translate.setDefaultLang('en');
      this.events.subscribe('user:created', (token) => {
        console.log(token, 'token');
        this.role = token.role;
        localStorage.setItem('userRole', token.role);
        this.currentAccountRole = token.role;
        this.token = token.accessToken;
        if (token.role === 'guardian') {
          this.name = token.profile[0].fullName;
          this.profilePhoto = token.profile[0].profilePhoto;
          this.profileTitle = 'Student :';
          this.profileSubTitle = token.profile[0].batchName;
          this.currentAccountId = token.profile[0].id;
        } else {
          this.currentAccountId = token.profile.id;
          if (token.role === 'employee') {
            this.profileTitle = 'Employee :';
            this.profileSubTitle = token.profile.employeeDepartmentName;
          }
          if (token.role === 'student') {
            this.profileTitle = 'Student :';
            this.profileSubTitle = token.profile.batchName;
          }
          this.name = token.profile.fullName;
          this.profilePhoto = token.profile.profilePhoto;
        }
      });
      this.events.subscribe('swap:enable', (tokens) => {
        this.accounts = [];
        this.setAccounts(tokens);
        this.userService.setAccounts(this.accounts);
      });
      this.events.subscribe('user:logout', (data) => { this.logout(); });
      this.events.subscribe('school:load', () => {
        this.school.getSchool('name').then((value) => { this.schoolName = value; });
      });
      this.events.subscribe('user:refresh', () => { this.refreshUser(); });
      this.events.subscribe('load:menu', () => {
        this.loadMenuData()
      })
      this.events.subscribe('login:success', async () => {
        console.log('in login success');
        this.storage.get('is_first_launch').then(val => {
          if (!val && AppSettings.MULTI_SCHOOL_MODE) {
            this.storage.set('is_first_launch', true)
          }
        })
        //On 'user' login success store the school information in logged schools list.
        this.multiSchoolService.addLoggedInSchool();

      })
      this.school.getSchool('name').then((value) => {
        this.storage.get('SCHOOL_NAME').then((value) => { this.schoolName = value; });
      });
      await this.translate.setDefaultLang('en');
      if (!this.multiSchoolService.isSwitchingSchool && !this.enteredFromNotification)
        this.platformReady();
      this.platform.backButton.subscribe(async () => {
        console.log('in backButton');
        const activeView = this.router.url;
        console.log('activeView', activeView);
        const modalView = await this.modalController.getTop();
        const actionView = await this.actionsheetController.getTop();
        if (modalView) {
          this.modalController.dismiss();
          if (this.isExitAlertShown) this.isExitAlertShown = false;
          return;
        }
        if (actionView) {
          this.actionsheetController.dismiss();
          if (this.isExitAlertShown) this.isExitAlertShown = false;
          return;
        }
        if (this.menuCtrl.isOpen()) {
          this.menuCtrl.close();
        }
        if (activeView === '/errors') {
          this.showExitAlert();
        }
        else if (activeView === "/announcements") {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tabs', { replaceUrl: true })
        }
        else if (activeView === '/tabs/home' || activeView === '/tutorial' || activeView === '/tabs/class/student-class' || activeView === '/tabs/class/my-class' || activeView === '/tabs/events' || activeView === '/events' || activeView === '/tabs/messages' || activeView === '/tabs/account' || activeView === '/schools-list' || activeView === '/school-login') {
          console.log('this.routerOutlet.canGoBack()', this.routerOutlet.canGoBack());
          if (this.routerOutlet.canGoBack()) {
            this.routerOutlet.pop();
          } else if (!this.isExitAlertShown) {
            if (activeView === '/tabs/home' || activeView === '/tutorial' || activeView === '/schools-list' || activeView === '/school-login') {
              this.showExitAlert();
            }
            else {
              this.navCtrl.setDirection('root');
              this.router.navigateByUrl('/tabs', { replaceUrl: true })
            }
          }
        }
        else {
          this.routerOutlet.pop();
        }
      });
      if (this.platform.is('ios')) {
        this.device.device_type = 'ios';
      }
      if (this.platform.is('android')) {
        this.device.device_type = 'android';
      }
      await this.profileService.getSchool().then(async (res: any) => {
        let data: any = JSON.parse(JSON.stringify(res));
        if (data.status === 500) {
          this.userService.errorHandler();
        }
        this.schoolData = await new TutorialModel(data);
        console.log(this.schoolData, 'schooldata');
        this.school.setSchool('locale', this.schoolData.prefLocale);
        this.storage.get('user_preferred_locale').then((res) => {
          let pref_locale: any = res;
          console.log("locale preferred by the user. . . " + pref_locale)
          this.school.setSchool('rtl', this.schoolData.rtl);
          let locale = this.schoolData ? this.schoolData.locale : undefined;
          let rtl = this.schoolData.rtl;
          if (pref_locale) {
            this.changeLanguage(pref_locale);
          } else if (locale && locale !== 'en') {
            this.changeLanguage(locale);
            if (rtl && rtl == true) {
              this.changeDir('rtl');
            }
          }
        })

      })
    });


  }
  async platformReady() {
    console.log('platfooooooooooooooorm ready $$$$$$$$$$$$$$$$$$$$$$$');
    const self: any = this;
    this.platform.ready().then(async () => {
      console.log("entered platform ready method...")
      this.statusBar.styleLightContent();
      this.statusBar.backgroundColorByHexString(this.statusbarColour);
      this.initPushNotification();
      this.splashScreen.hide();
      this.loadMenuData();
      if (this.hasInternetConnection && !this.multiSchoolService.isSwitchingSchool && !this.enteredFromNotification)
        this.loadMenuData();
      setTimeout(async () => {
        let isFirstLaunch = await this.storage.get('is_first_launch')
        if (!isFirstLaunch && AppSettings.MULTI_SCHOOL_MODE) {//checks if it is the first launch of the app in the multischool mode.
          await this.multiSchoolService.storage.clear()//clears the restored data from the old apps if any.
          this.initPushNotification();
          this.setRootPage('/walkthrough');
          return;
        }
        if (isFirstLaunch && !AppSettings.MULTI_SCHOOL_MODE) {//this condition checks if there is data from the old multischool app with the same package as the current standalone app. 
          await this.multiSchoolService.storage.clear()
          this.initPushNotification();
        }
        this.multiSchoolService.getCurrentSchoolClientId().then(id => {
          console.log("current school --current school --current school --current school --current school --current school --current school -- " + id)
          if (id) AppSettings.SCHOOL_IDENTITY = id
          this.userService.getAccessToken().then(async (value) => {
            if (value) {
              this.userService.storeItem(this.userService.ACCESSTOKEN, value);
              this.userService.storeItem(this.userService.HAS_LOGGED_IN, true);
              let data: any = await this.profile.getSchool();
              if (data.status === 500) {
                this.userService.errorHandler();
              }
              this.schoolData = new TutorialModel(data);
              // do-check and change
              this.school.setSchool('locale', this.schoolData.locale);
              this.school.setSchool('rtl', this.schoolData.rtl);
              let locale = this.schoolData.locale;
              let rtl = this.schoolData.rtl;
              if (locale) {
                this.translate.use(locale);
              }
              if (rtl && rtl == true) {
                this.changeDir('rtl');
              }
              this.navCtrl.setDirection('root');
              this.router.navigateByUrl('/tabs', { state: { isSession: true } })
            }
            else {
              if (AppSettings.MULTI_SCHOOL_MODE) {
                this.multiSchoolService.getLoggedInSchools().then(schools => {
                  let page = schools && Object.keys(schools).length != 0 ? '/schools-list' : 'school-login';
                  this.setRootPage(page)
                })
              } else {
                this.setRootPage('/tutorial');
              };
            }
          });
        })
        this.initCompleted = true;
      }, 1000);
      let locale;
      let rtl;
      let pref_locale = await this.storage.get('user_preferred_locale')
      if (!AppSettings.MULTI_SCHOOL_MODE) {
        let data: any = await this.profile.getSchool();
        if (data.status === 500) {
          this.userService.errorHandler();
        }
        this.schoolData = new TutorialModel(data);
        this.school.setSchool('locale', this.schoolData.locale);
        this.school.setSchool('rtl', this.schoolData.rtl);
        locale = this.schoolData.locale;
        rtl = this.schoolData.rtl;
        if (locale && locale !== 'en') this.translate.use(locale)
        if (rtl && rtl == true) this.changeDir('rtl');
      }
      else {
        locale = await this.storage.get('locale')
        console.log("this is the locale -- " + locale)
        if (locale)
          this.translate.use(locale)
        rtl = await this.storage.get('rtl')
        console.log("this is the locale -- " + locale)
        if (rtl)
          this.changeDir('rtl')
      }
      if (pref_locale) {
        this.changeLanguage(pref_locale);
      } else if (locale && locale !== 'en') {
        this.changeLanguage(locale);
        if (rtl && rtl == true) {
          this.changeDir('rtl');
        }
      }
      
    });
  }
  setRootPage(page, options?: any) {
    if (this.hasInternetConnection && !this.multiSchoolService.isSwitchingSchool && !this.enteredFromNotification) {
      this.navCtrl.setDirection('root');
      this.router.navigateByUrl(page, { replaceUrl: true }).then((val) => {
        this.splashScreen.hide();
      })
      if (this.routerOutlet.canGoBack()) {
        this.navCtrl.back();
      }
    }
    else this.initCompleted = false;
  }
  async showExitAlert() {
    let titleString = 'App termination';
    let messageString = 'Do you want to close the app?';
    let cancelBtnString = 'Cancel';
    let exitBtnString = 'Exit';
    this.translate.get('alert.title_app_termination').subscribe(val => titleString = val)
    this.translate.get('alert.msg_close_app').subscribe(val => messageString = val)
    this.translate.get('alert.btn_cancel').subscribe(val => cancelBtnString = val)
    this.translate.get('alert.btn_exit').subscribe(val => exitBtnString = val)
    const alert = await this.alertCtrl.create({
      header: titleString,
      message: messageString,
      buttons: [{
        text: cancelBtnString,
        role: 'cancel',
        handler: () => {
          console.log('Application exit prevented!');
          this.isExitAlertShown = false;
        },
      }, {
        text: exitBtnString,
        handler: () => {
          navigator['app'].exitApp();// Close this application
        },
      }],
    });
    await alert.present();
    this.isExitAlertShown = true;
  }

  checkDisconnection() {
    const disconnectSubscription = this.network.onDisconnect().subscribe(() => {
      this.hasInternetConnection = false;
      this.checkConnection();
      this.events.publish('event:no_network', {});
      disconnectSubscription.unsubscribe();
      this.router.navigateByUrl('/errors');
    });
  }

  checkConnection() {
    const connectSubscription = this.network.onConnect().subscribe(() => {
      this.hasInternetConnection = true;
      this.checkDisconnection();
      connectSubscription.unsubscribe();
      this.navCtrl.back();
    });
  }
  refreshUser() {
    this.loadMenuData();
  }

  menuClosed() {
    this.showswap = false;
  }
  changeDir(dir) {
    this.platform.ready().then(
      () => {
        document.documentElement.dir = dir;
        if (dir === 'rtl') {
          this.menuCtrl.enable(false, 'left')
          this.menuCtrl.enable(true, 'right')
        } else {
          this.menuCtrl.enable(true, 'left')
          this.menuCtrl.enable(false, 'right')
        }
      }
    )
  }
  changeLanguage(languageCode: string) {
    if (languageCode === 'ar') {
      this.changeDir('rtl');
    } else this.changeDir('ltr')
    this.schoolData.locale = languageCode;
    return this.translate.use(languageCode);
  }
  toggleswapOption() {
    if (this.accounts.length > 1) {
      this.showswap = !this.showswap;
      if (!this.showswap) {
        this.swapicon = 'chevron-down-sharp';
      } else {
        this.swapicon = 'chevron-up-sharp';
      }
    }

  }
  ngOnInit() {
  }

  loadMenuData() {
    this.school.getSchool('name').then((value) => { this.schoolName = value; });
    if (AppSettings.MULTI_SCHOOL_MODE)
      this.storage.get('logo_thumb_url').then(val => { this.schoolLogo = val })
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getRole().then((role) => {
          this.role = role;
          this.userService.getUser().then((value) => {
            if (value) {
              console.log(value, 'value');
              this.currentAccountId = value.id;
              this.currentAccountRole = value.role;
              this.name = value.fullName;
              if (role === 'employee') {
                this.profileTitle = 'Employee :';
                this.profileSubTitle = value.employeeDepartmentName;
              }
              if (role === 'student' || role === 'guardian') {
                this.profileTitle = 'Student :';
                this.profileSubTitle = value.batchName;
              }
              if (role === 'guardian') {
                // this.userService.setAccessToken(value.token + ';student_id=' + value.id);
              }
              if (value.profilePhoto !== '') {
                this.profilePhoto = value.profilePhoto;
              }

              this.loadAccounts();
            }

          });
        });
      }

    });
  }
  swapProfile(profile) {
    console.log(profile);
    this.currentAccountRole = profile.role;
    if (profile.role === 'student' || profile.role === 'guardian') {
      this.profileTitle = 'Student : ';
      this.profileSubTitle = profile.batchName;
    }
    if (profile.role === 'employee') {
      this.profileTitle = 'Employee : ';
      this.profileSubTitle = profile.employeeDepartmentName;
    }
    if (profile.role === 'guardian') {
      // this.userService.setAccounts(profile.accounts);
      this.userService.setRole(profile.role);
      this.userService.setUserId(profile.id);
      this.userService.setAccessToken(profile.token + ';student_id=' + profile.id);
      this.currentAccountId = profile.id;
    } else {

      this.userService.setAccessToken(profile.token);
      this.userService.setUserId(profile.id);
      this.userService.setRole(profile.role);
      this.currentAccountId = profile.id;
    }
    // this.content.scrollToTop();
    if (this.platform.is('ios')) {
      this.keyboard.disableScroll(false);
    }
    console.log(profile);
    this.userService.setUser(profile);
    this.userService.setMasterUserId(profile.userId);
    this.name = profile.fullName;
    this.profilePhoto = profile.profilePhoto;
    this.router.navigateByUrl('/tabs', { replaceUrl: true })
  }
  openMarket() {
    // if (this.platform.is('android')) {
    //   window.open(AppSettings.PLAY_STORE_LINK, '_system', 'location=yes');
    // }
    // else {
    //   window.open(AppSettings.APP_STORE_LINK, '_system', 'location=yes')
    // }
  }
  logout() {
    this.userService.getAccessToken().then((value) => {
      this.token = value;
      this.authService.deleteDevice(this.token, this.device.device_id, this.device.device_type)
        .subscribe((response) => {
          this.userService.logout();
          if (AppSettings.MULTI_SCHOOL_MODE) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/schools-list', { replaceUrl: true });
          }
          else {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        })
    });

  }
  loadAccounts() {
    this.userService.getAccessTokens().then((value) => {
      this.accounts = [];
      if (value) {
        this.setAccounts(value);
      }
      this.userService.setAccounts(this.accounts);
    });
  }
  setAccounts(value) {
    console.log(value, 'value');
    this.users = value;
    for (const user of this.users) {
      user.profile.userId = user.userId;
      if (user.role !== 'guardian') {
        user.profile.role = user.role;
        user.profile.token = user.accessToken;
        this.accounts.push(user.profile);
      }
      if (user.role === 'guardian') {
        for (const profile of user.profile) {
          profile.role = 'guardian';
          profile.token = user.accessToken;
          profile.userId = user.userId;
          this.accounts.push(profile);
        }
      }
    }
  }
  initPushNotification() {
    if (!this.platform.is('cordova')) {
      console.warn('Push notifications not initialized. Cordova is not available - Run in physical device');
      return;
    }
    this.checkPushStatus();
    const options: any = {
      android: {
        senderID: AppSettings.SENDER_ID,
        icon: 'push_icon',
        iconColor: '#000000',
        sound: 'default'
      },
      ios: {
        senderID: AppSettings.SENDER_ID,
        alert: 'true',
        badge: 'true',
        sound: 'true',
      },
    };
    const pushObject: PushObject = this.push.init(options);
    pushObject.on('notification').subscribe(
      async (notification: any) => {
        // this.splashScreen.hide();
        console.log(notification)
        let payloadu = notification.additionalData.payload;
        if (this.platform.is('ios')) payloadu = JSON.parse(notification.additionalData.payload);
        if (AppSettings.MULTI_SCHOOL_MODE) {
          let id = await this.storage.get('current_school_id');
          if (id !== notification.additionalData.school_id && !notification.additionalData.foreground)
            await this.multiSchoolService.switchSchoolById(Number.parseInt(notification.additionalData.school_id))
        }
        this.userService.setNotification(JSON.stringify(notification));
        console.log(notification.additionalData.user_ids);
        if (notification.additionalData.target === 'message') {
          let id = await this.storage.get('current_school_id');
          let school_id = notification.additionalData.school_id;
          if (AppSettings.MULTI_SCHOOL_MODE && id !== Number.parseInt(school_id) && notification.additionalData.foreground) {//notification recieved in foreground
            this.localNotifications.schedule({
              id: 1,
              icon: '',
              title: notification.title,
              text: notification.message,
              foreground: true,
              data: notification.additionalData
            });
          }
          else {
            this.test = !this.platform.is('ios') ? notification.additionalData.user_ids[0] : JSON.parse(notification.additionalData.user_ids)[0];
            if (this.platform.is('ios')) {
              this.userService.getMasterUserId().then((id) => {
                const usID = this.test.toString();
                this.id = id;
                if (usID === id || usID.includes(id)) {
                  this.events.publish('message:received', notification);
                  this.events.publish('chat:received', notification);
                  this.events.publish('newmessage:received', notification);
                }
              });
            } else {
              this.userService.getAccessToken().then((value) => {
                if (value) {
                  this.token = value;
                  this.userService.getMasterUserId().then((id) => {
                    this.id = id;
                    console.log(this.id);
                    console.log('master user id', this.id);
                    console.log('aditional user id', this.test);
                    if (this.test === id) {
                      this.events.publish('message:received', notification);
                      this.events.publish('chat:received', notification);
                      this.events.publish('newmessage:received', notification);
                    }
                  });
                }
              })
            }
            if (notification.additionalData.foreground === false) {
              this.router.navigateByUrl('/tabs').then(val => { this.splashScreen.hide() });
              this.events.publish('school:load');
              this.events.publish('load:menu');
            }
          }
          return
        }
        if (notification.additionalData.target === 'transport') {
          if (notification.additionalData.foreground === false) {//if the notification is in recieved in background navigate to TrackPage with the payload data.
            this.enteredFromNotification = true;
            let options = notification.additionalData.payload;
            if (this.platform.is('ios')) options = JSON.parse(notification.additionalData.payload);
            this.router.navigateByUrl('/track', {
              state: {
                data: {
                  trackParams: {
                    routeId: options.route_id,
                    vehicleId: options.vehicle_id,
                    stopId: options.stop_id,
                    direction: options.direction,
                    url: options.tracking_url
                  }
                }
              }
            })
            this.splashScreen.hide()
          }
          else if (notification.additionalData.foreground) {//notification recieved in foreground
            let navViews = this.router.url
            if (navViews !== '/track')//current view is other than 'TrackPage' display a local notification 
              this.localNotifications.schedule({                 //( push plugin doesn't display notification when in foreground thus Local notification is used).
                id: 1,
                icon: '',
                title: notification.title,
                text: notification.message,
                foreground: true,
                data: notification.additionalData
              });
            else// 'tracking_details:reiceved' event is processed by 'TrackPage' as the current view is 'TrackPage'
              this.events.publish('tracking_details:received', notification);
          }
          return;

        }
        if (notification.additionalData.foreground === false) {
          this.router.navigateByUrl('/tabs').then(val => { this.splashScreen.hide() });
          this.events.publish('school:load');
          this.events.publish('load:menu');
        } else {//notification recieved in foreground
          this.localNotifications.schedule({
            id: 1,
            icon: '',
            title: notification.title,
            text: notification.message,
            foreground: true,
            data: notification.additionalData
          });
        }

      },
    );

    pushObject.on('registration').subscribe(
      (registration: any) => {
        console.log('Device registered', registration);
        this.device.device_id = registration.registrationId;
        this.device.device_type = this.device.device_type;
        this.notificationContent = registration.registrationId;
        console.log(this.device);
        this.userService.setDevice(this.device);
      },
    );
    this.localNotifications.on('click').subscribe(async (event) => {//on click handler for local notification. currently only Transport Target is considered.
      if (AppSettings.MULTI_SCHOOL_MODE) {
        let id = await this.storage.get('current_school_id');
        if (id !== event.data.school_id && event.data.foreground)
          await this.multiSchoolService.switchSchoolById(Number.parseInt(event.data.school_id))
      }
      this.splashScreen.hide();
      if (event.data.target === "transport") {
        let options = event.data.payload;
        if (this.platform.is('ios')) options = JSON.parse(event.data.payload);
        this.router.navigateByUrl('/track', {
          state: {
            data: {
              trackParams: {
                routeId: options.route_id,
                vehicleId: options.vehicle_id,
                stopId: options.stop_id,
                direction: options.direction,
                url: options.tracking_url
              }
            }
          }
        })
        this.events.publish('school:load');
        this.events.publish('load:menu');
        return;
      }

      if (event.data.target === "message") {
        this.router.navigateByUrl('/tabs').then(val => { this.splashScreen.hide() });
        this.events.publish('school:load');
        this.events.publish('load:menu');
        this.test = !this.platform.is('ios') ? event.data.user_ids[0] : JSON.parse(event.data.user_ids)[0];

        // if (notification.additionalData.foreground === false) {
        //   // console.log("entered..")
        //   this.nav.push('MessagesPage')
        //   this.enteredFromNotification = true;
        // }

        if (this.platform.is('ios')) {

          // this.events.publish('newmessage:received', notification);
          // this.presentToast('Message Received');

          this.userService.getMasterUserId().then((id) => {

            const usID = this.test.toString();

            this.id = id;

            if (usID === id || usID.includes(id)) {
              // this.presentToast('');
              // this.presentToast('blah')
              this.events.publish('message:received', event);
              this.events.publish('chat:received', event);
              this.events.publish('newmessage:received', event);
            }

          });
        } else {
          // this.presentToast('Event Notification');
          this.userService.getAccessToken().then((value) => {
            // this.presentToast('Access token');
            // this.presentToast('');

            if (value) {
              this.token = value;
              this.userService.getMasterUserId().then((id) => {
                this.id = id;
                console.log(this.id);
                console.log('master user id', this.id);
                console.log('aditional user id', this.test);

                if (this.test === id) {
                  // this.presentToast('Final');
                  // this.presentToast('blah')
                  this.events.publish('message:received', event);
                  this.events.publish('chat:received', event);
                  this.events.publish('newmessage:received', event);
                }
              });
            }
          });
        }
        this.events.publish('school:load');
        this.events.publish('load:menu');
        return;

      }
      this.router.navigateByUrl('/tabs').then(val => { this.splashScreen.hide() });
      this.events.publish('school:load');
      this.events.publish('load:menu');

    })
    pushObject.on('error').subscribe(
      error =>
        console.error('Error with Push plugin', error),
    );
  }
  checkPushStatus() {
    this.push.hasPermission()
      .then((res: any) => {
        if (res.isEnabled) {
          console.log('We have permission to send push notifications');
        } else {
          console.log('We do not have permission to send push notifications');
        }
      });
  }
  openSchoolsList() {
    this.navCtrl.setDirection('root');
    this.router.navigateByUrl('/schools-list', { state: { showNavbar: false } });
  }
  openHome() {
    this.menuCtrl.toggle();
    this.navCtrl.setDirection('root');
    this.router.navigateByUrl('/tabs/home', { replaceUrl: true });
  }
  openAnnouncements() {
    this.menuCtrl.toggle();
    this.router.navigateByUrl('/announcements');
  }
  openEvents() {
    this.menuCtrl.toggle();
    this.navCtrl.setDirection('root');
    this.router.navigateByUrl('/tabs/events', { replaceUrl: true });
  }
  openInstitute() {
    this.menuCtrl.toggle();
    this.router.navigateByUrl('/my-institution');
  }
}
