import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { HttpClientModule, HttpClient } from '@angular/common/http';

//plugins
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { IonicStorageModule } from '@ionic/storage';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { Clipboard } from '@ionic-native/clipboard/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { Network } from '@ionic-native/network/ngx';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { TranslateCompiler, TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateMessageFormatCompiler } from 'ngx-translate-messageformat-compiler';
import { MESSAGE_FORMAT_CONFIG } from 'ngx-translate-messageformat-compiler';
import { Downloader } from '@ionic-native/downloader/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { Chooser } from '@ionic-native/chooser/ngx';
import { FilePath } from '@ionic-native/file-path/ngx';
import { Camera } from '@ionic-native/camera/ngx';
import { ChartsModule } from 'ng2-charts';
import { Push } from '@ionic-native/push/ngx';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { catchError } from 'rxjs/operators';


import { PipesModule } from 'src/pipes/pipes.module';
import { DirectivesModule } from 'src/directives/directives.module';
import { httpInterceptorProviders } from 'src/providers/interceptors/allInterceptors';
import { AppSettings, LANGUAGE_SELECTOR_CONFIG } from 'src/models/app-settings';

export function HttpLoaderFactory(http: HttpClient) {
  return new CustomTranslateHttpLoader(http);
}
class CustomTranslateHttpLoader implements TranslateLoader {
  private http: HttpClient;
  private srcUrl: string = AppSettings.APP_API_URL;

  constructor(http: HttpClient, srcUrl?: string) {
    this.http = http;
    if (srcUrl)
      this.srcUrl = srcUrl;
  }
  getTranslation(lang: string) {
    // return this.http.get(this.srcUrl + 'locales/' + lang + '.json').pipe(
    //   catchError(
    //     err => {
    //       console.log(err)
          return this.http.get('./assets/i18n/' + lang + '.json');
    //     }
    //   )
    // );
  }
}
@NgModule({
  declarations: [AppComponent,],
  entryComponents: [],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      },
      compiler: {
        provide: TranslateCompiler,
        useClass: TranslateMessageFormatCompiler
      }
    }),
    IonicStorageModule.forRoot(),
    AppRoutingModule,
    PipesModule,
    DirectivesModule,
    HttpClientModule,
    ChartsModule
  ],
  providers: [
    StatusBar,
    SplashScreen,
    CallNumber,
    EmailComposer,
    Clipboard,
    InAppBrowser,
    Network,
    Keyboard,
    Downloader,
    File,
    FileTransfer,
    FileOpener,
    Chooser,
    FilePath,
    Camera,
    Push,
    LocalNotifications,
    httpInterceptorProviders,
    { provide: MESSAGE_FORMAT_CONFIG, useValue: { locales: LANGUAGE_SELECTOR_CONFIG.LOCALE_CODES } },
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }
