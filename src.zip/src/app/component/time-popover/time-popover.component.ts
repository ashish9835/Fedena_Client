import { Component, OnInit, ViewChild } from '@angular/core';
import { IonDatetime } from '@ionic/angular';

@Component({
  selector: 'app-time-popover',
  templateUrl: './time-popover.component.html',
  styleUrls: ['./time-popover.component.scss'],
})
export class TimePopoverComponent implements OnInit {

  customPickerOptions: any;

  @ViewChild('mydt') mydt: IonDatetime;

  constructor() { 
    this.customPickerOptions = {
      buttons: [{
        text: 'Set Time',
        handler: (res) => {
          console.log('Set Time', res);
        }
      }, {
        text: 'Cancel',
        handler: () => {
          console.log('Clicked Log. Do not Dismiss.');
          return false;
        }
      }]
    }
  }

  ngOnInit() {}

}
