import  data from '../../app-config.json';
export class AppSettings {
    public static APP_API_URL = data.api_url;
}