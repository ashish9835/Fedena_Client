import { DatePipe } from '@angular/common'
import { Component, Input, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { ModalController } from '@ionic/angular'

@Component({
  selector: 'app-filter-reports',
  templateUrl: './filter-reports.page.html',
  styleUrls: ['./filter-reports.page.scss'],
})
export class FilterReportsPage implements OnInit {
  @Input() dateData: any;
  @Input() modelTitle: any;
  value_selected: string = '';

  filterReportsData = {
    date_range: '',
    start_date: '',
    end_date: '',
  }
  startDate: any;
  endDate: any;

  constructor(
    private router: Router,
    public modalController: ModalController,
    public datepipe: DatePipe,
  ) {
  }

  ngOnInit() {
    this.filterReportsData = this.dateData;
    // this.value_selected = this.filterReportsData.date_range;
    console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5");
    console.log("--------------------------",this.modelTitle);
    console.log("----------------------",this.dateData);
    this.value_selected = this.filterReportsData.date_range;
    this.startDate = this.filterReportsData.start_date;
    this.endDate = this.filterReportsData.end_date;
  }

  dismissModel() {
    this.modalController.dismiss();
  }


  onSubmit() {
    this.filterReportsData.date_range = this.value_selected;
    if (this.value_selected == 'custom') {
      this.filterReportsData.start_date = this.datepipe.transform(
        this.startDate,
        'yyyy-MM-dd',
      )
      this.filterReportsData.end_date = this.datepipe.transform(
        this.endDate,
        'yyyy-MM-dd',
      )

      console.log(
        this.filterReportsData.start_date,
        this.filterReportsData.end_date,
      )

      this.modalController.dismiss(this.filterReportsData)
    } else {
      this.modalController.dismiss(this.filterReportsData)
    }
  }

  clearFilter() {
    this.value_selected = '';
    this.filterReportsData.start_date ='';
    this.filterReportsData.end_date ='';
  }
}
