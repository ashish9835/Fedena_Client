import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GateManagementPageRoutingModule } from './gate-management-routing.module';

import { GateManagementPage } from './gate-management.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GateManagementPageRoutingModule
  ],
  declarations: [GateManagementPage]
})
export class GateManagementPageModule {}
