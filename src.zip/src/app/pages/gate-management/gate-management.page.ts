import { HttpClient, HttpParams } from '@angular/common/http'
import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { LoadingController, ModalController } from '@ionic/angular'
import { AppSettings } from 'src/app/models/app-setting'
import { GateManagementService } from 'src/app/providers/gate-managementService'
import { FilterReportsPage } from '../filter-reports/filter-reports.page'
import { Chart, ChartType } from 'chart.js'
// import ChartDataLabels from 'chartjs-plugin-datalabels';

// Chart.plugins.register(ChartDataLabels);

@Component({
  selector: 'app-gate-management',
  templateUrl: './gate-management.page.html',
  styleUrls: ['./gate-management.page.scss'],
})
export class GateManagementPage implements OnInit {
  selectedSegment: string = 'user_entry_log'
  view: boolean = false
  userTypeData: any
  totalUsers: []
  graphTypeData: any
  graphData = []
  table: boolean = true
  graph: boolean = false
  filterDataRange: any
  target = {
    entryType: '',
  }

  dataSelected = {
    date_range: '',
    start_date: '',
    end_date: '',
  }

  object = {
    entryType: '',
    date_range: '',
    start_date: '',
    end_date: '',
  }

  userEntryTable = {
    entryType: '',
    date_range: '',
    start_date: '',
    end_date: '',
  }
  userEntryGraph = {
    entryType: '',
    date_range: '',
    start_date: '',
    end_date: '',
  }
  gatePassTable = {
    entryType: '',
    date_range: '',
    start_date: '',
    end_date: '',
  }
  gatePassGraph = {
    entryType: '',
    date_range: '',
    start_date: '',
    end_date: '',
  }
  visitorEntryTable = {
    entryType: '',
    date_range: '',
    start_date: '',
    end_date: '',
  }
  visitorEntryGraph = {
    entryType: '',
    date_range: '',
    start_date: '',
    end_date: '',
  }
  fetchLocation: string
  httpParams: HttpParams
  dates: []
  entry_count: []
  segmentName: string

  constructor(
    private http: HttpClient,
    public router: Router,
    public reportService: GateManagementService,
    public modalController: ModalController,
    public loadingController: LoadingController,
  ) {}

  ngOnInit() {
    this.checkingSegment()
  }

  segmentChanged(ev: any) {
    // console.log('Segment changed', ev)
    this.selectedSegment = ev.target.value
    // console.log(this.selectedSegment);
    // this.viewChanged()
    this.checkingSegment()
  }

  viewChanged() {
    // if (this.view == false) {
    //   this.checkingSegment()
    // } else {
    //   this.checkingSegment()
    // }
    this.checkingSegment()
  }

  async presentLoading(message: string) {
    const loading = await this.loadingController.create({
      message,
      duration: 2000,
    })
    await loading.present()
  }

  async presentModal() {
    let filterObject = this.dataRange()
    console.log('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55')
    console.log(filterObject)
    // console.log(response);
    // this.dataSelected.date_range =  response.date_range;
    // this.dataSelected.start_date = response.start_date;
    // this.dataSelected.end_date = response.end_date;
    const modal = await this.modalController.create({
      component: FilterReportsPage,
      cssClass: 'my-custom-class',
      componentProps: {
        modelTitle: this.segmentName,
        dateData: filterObject,
      },
    })
    modal.onDidDismiss().then((res) => {
      console.log(res)
      console.log(res.data)
      if (res.data != undefined) {
        if (this.selectedSegment == 'user_entry_log') {
          if (this.view == false) {
            this.userEntryTable = res.data
          } else {
            this.userEntryGraph = res.data
          }
        } else if (this.selectedSegment == 'gate_pass') {
          if (this.view == false) {
            this.gatePassTable = res.data
          } else {
            this.gatePassGraph = res.data
          }
        } else {
          if (this.view == false) {
            this.visitorEntryTable = res.data
          } else {
            this.visitorEntryGraph = res.data
          }
        }
        this.checkingSegment()
      }
    })
    await modal.present()
  }

  dataRange() {
    if (this.selectedSegment == 'user_entry_log') {
      if (this.view == false) {
        return this.userEntryTable
      } else {
        return this.userEntryGraph
      }
    } else if (this.selectedSegment == 'gate_pass') {
      if (this.view == false) {
        return this.gatePassTable
      } else {
        return this.gatePassGraph
      }
    } else {
      if (this.view == false) {
        return this.visitorEntryTable
      } else {
        return this.visitorEntryGraph
      }
    }
  }

  getTableData(object) {
    this.presentLoading('Loading Table Data')
    console.log(this.selectedSegment)
    let apiUrl = this.conditions(object)
    console.log(
      '--------------------------------------------------------------------------',
    )
    console.log(apiUrl)
    this.reportService.getTableData(apiUrl).subscribe((res) => {
      this.loadingController.dismiss()
      console.log(res)
      this.userTypeData = res
      // console.log(this.userTypeData.data[0]);
      this.totalUsers = this.userTypeData.data
      console.log(this.totalUsers)
    })
  }

  getGraphData(object) {
    this.presentLoading('Loading Graph Data')
    console.log(this.selectedSegment)
    console.log(
      '-----------------------------------------------------------------------------',
    )
    let apiUrl = this.conditions(object)
    console.log(apiUrl)
    this.reportService.getGraphData(apiUrl).subscribe((res) => {
      this.loadingController.dismiss()
      this.userTypeData = res
      console.log(this.userTypeData)

      this.dates = this.userTypeData.data.dates
      this.entry_count = this.userTypeData.data.entry_count
      console.log(this.dates, this.entry_count)

      const labels = this.dates
      const data = {
        labels: labels,
        datasets: [
          {
            axis: 'y',
            data: this.entry_count,
            fill: false,
            backgroundColor: 'blue',
            borderColor: 'rgb(54, 162, 235)',
            borderWidth: 1,
          },
        ],
      }

      const myChart = new Chart('myChart', {
        type: 'horizontalBar' as ChartType,
        // plugins: [ChartDataLabels],
        data,
        options: {
          legend: {
            display: false,
          },
          indexAxis: 'y',
          scales: {
            xAxes: [
              {
                position: 'top',
                borderDash: [8, 4],
                color: "#348632"
              },
            ],
            yAxes: [
              {
                gridLines: {
                  display: false,
                },
              },
            ],
          },
        }
      })
    })
  }

  checkingSegment() {
    console.log('We are in checking segment and view')
    if (this.selectedSegment == 'user_entry_log') {
      if (this.view == false) {
        this.userEntryTable.entryType = 'user_entry_log'
        this.getTableData(this.userEntryTable)
        this.segmentName = '1'
      } else {
        this.userEntryGraph.entryType = 'user_entry_log'
        this.getGraphData(this.userEntryGraph)
        this.segmentName = '2'
      }
    } else if (this.selectedSegment == 'gate_pass') {
      if (this.view == false) {
        this.gatePassTable.entryType = 'gate_pass'
        this.getTableData(this.gatePassTable)
        this.segmentName = '3'
      } else {
        this.gatePassGraph.entryType = 'gate_pass'
        this.getGraphData(this.gatePassGraph)
        this.segmentName = '4'
      }
    } else {
      if (this.view == false) {
        this.visitorEntryTable.entryType = 'visitor_record'
        this.getTableData(this.visitorEntryTable)
        this.segmentName = '5'
      } else {
        this.visitorEntryGraph.entryType = 'visitor_record'
        this.getGraphData(this.visitorEntryGraph)
        this.segmentName = '6'
      }
    }
  }

  conditions(object) {
    console.log(object)
    let param = 'entry_type=' + object.entryType
    param += object.date_range != '' ? `&date_range=${object.date_range}` : ''
    param += object.start_date != '' ? `&start_date=${object.start_date}` : ''
    param += object.end_date != '' ? `&end_date=${object.end_date}` : ''
    return param
  }
}
