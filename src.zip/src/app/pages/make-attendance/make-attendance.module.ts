import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MakeAttendancePageRoutingModule } from './make-attendance-routing.module';

import { MakeAttendancePage } from './make-attendance.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MakeAttendancePageRoutingModule
  ],
  declarations: [MakeAttendancePage]
})
export class MakeAttendancePageModule {}
