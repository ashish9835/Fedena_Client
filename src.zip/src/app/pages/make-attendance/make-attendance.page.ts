import { HttpClient } from '@angular/common/http'
import { Component, OnInit, ViewChild } from '@angular/core'
import { IonDatetime, LoadingController, ModalController } from '@ionic/angular'
import { format, parseISO } from 'date-fns'
import { DatePipe } from '@angular/common'
import { ViewReportsPage } from '../view-reports/view-reports.page'
import { ViewReportsPageModule } from '../view-reports/view-reports.module'
import { Router } from '@angular/router'

@Component({
  selector: 'app-make-attendance',
  templateUrl: './make-attendance.page.html',
  styleUrls: ['./make-attendance.page.scss'],
})
export class MakeAttendancePage implements OnInit {
  @ViewChild(IonDatetime, { static: true }) datetime: IonDatetime
  public myDate: string = new Date().toISOString()
  selectedDate: string = format(parseISO(this.myDate), 'MMM dd')
  dateValue2 = ''
  studentListData: any
  studentList: any = []
  isVisible: boolean = false
  isAbsentDivVisible: boolean = false
  isLateDivVisible: boolean = false
  time_selected: string = ''
  buttonValue = 0
  view: boolean = false
  storeDate: any
  checkBoxList: any
  saveFinalData = []

  obj: any = [];


  constructor(
    public modalController: ModalController,
    public httpClient: HttpClient,
    public loadingController: LoadingController,
    public datepipe: DatePipe,
    public router: Router
  ) {
    this.checkBoxList = [
      { val: 'Forenoon', isChecked: false },
      { val: 'Afternoon', isChecked: false },
    ]

  }

  ngOnInit() {
    this.onChangeMode()
    this.storeDate =  new Date().toISOString();
  }

  onChangeMode() {
    if (this.view == false) {
      this.getNormalJsondata()
      console.log(this.getNormalJsondata)
      console.log(this.time_selected)
    } else {
      this.getRapidJsondata()
      console.log(this.getRapidJsondata)
    }
  }

  async presentLoading(message: string) {
    const loading = await this.loadingController.create({
      message,
      duration: 2000,
    })
    await loading.present()
  }

  getNormalJsondata() {
    this.presentLoading('Loading Normal Mode Data')
    this.httpClient.get('../../../assets/attendance.json').subscribe((res) => {
      console.log(res)
      this.loadingController.dismiss()
      this.studentListData = res
      // console.log(this.studentListData.students);
      this.studentList = this.studentListData.students
      console.log(this.studentList.length)
      for (let i = 0; i < this.studentList.length; i++) {
        this.studentList[i]['visibility'] = false
      }
      console.log(this.studentList)
    })
  }

  getRapidJsondata() {
    this.presentLoading('Loading Normal Mode Data')
    this.httpClient.get('../../../assets/rapid.json').subscribe((res) => {
      console.log(res)
      this.loadingController.dismiss()
      this.studentListData = res
      // console.log(this.studentListData.students);
      this.studentList = this.studentListData.students
      console.log(this.studentList.length)
      for (let i = 0; i < this.studentList.length; i++) {
        this.studentList[i]['visibility'] = false
      }
      console.log(this.studentList)
    })
  }

  absentstyle(student): Object {
    if (student.isAbsentDivVisible) {
      return { 'background-color': 'red', color: 'white' }
    }
    return {}
  }

  latestyle(student): Object {
    if (student.isLateDivVisible) {
      return { 'background-color': 'red', color: 'white' }
    }
    return {}
  }

  formatDate(value) {
    this.selectedDate = format(parseISO(value), 'MMM dd')
    console.log(value)
    this.storeDate = value
    console.log(this.storeDate)
    console.log(this.selectedDate)
    this.studentListData.date = this.selectedDate;
    console.log(this.studentListData)
    return format(parseISO(value), 'MMM dd')
  }

  decreaseDate() {
    let date: Date = new Date(this.storeDate)
    console.log(this.storeDate)
    date.setDate(date.getDate() - 1)
    console.log(date)
    this.storeDate = new Date(date).toISOString()
    this.selectedDate = format(parseISO(this.storeDate), 'MMM dd')
    console.log(this.selectedDate)
  }

  increaseDate() {
    console.log(this.storeDate)
    let date: Date = new Date(this.storeDate)
    date.setDate(date.getDate() + 1)
    // console.log(date)
    this.storeDate = new Date(date).toISOString()
    // console.log(this.storeDate)
    this.selectedDate = format(parseISO(this.storeDate), 'MMM dd')
    // console.log(this.selectedDate)
  }

  absentDisplay(student) {
    console.log('absent display opened')
    student.isAbsentDivVisible = !student.isAbsentDivVisible
    student.isLateDivVisible = false
    student.visibility = !student.visibility
    student.type = 'Absent'
    console.log(student)
    console.log('late display is closed')
  }

  lateDisplay(student) {
    console.log('late display is opened')
    student.isLateDivVisible = !student.isLateDivVisible
    student.isAbsentDivVisible = false
    console.log('absent display is closed')
    student.visibility = !student.visibility
    student.type = 'Late'
    console.log(student)
  }

  checkboxSelection(student, item) {
    // console.log('student value is----------', student)
    const totalItems = this.checkBoxList.length
    let checked = 0
    this.checkBoxList.map((obj) => {
      if (obj.isChecked) checked++
    })
    console.log(checked)
    if (checked > 0 && checked < totalItems) {
      //If even one item is checked but not all
      console.log(item.val)
      student.time = item.val
      console.log(student)
    } else if (checked == totalItems) {
      //If all are checked
      student.time = 'Full'
      console.log(student)
    } else {
      //If none is checked
      student.time = ''
    }
  }

  setAllAbsent() {
    for (let i = 0; i < this.studentList.length; i++) {
      this.studentList[i].type = 'absent'
    }
    console.log(this.studentList)
  }

  onSave() {
    console.log(this.studentList)
    console.log(this.obj)
    if (this.view == false) {
      this.saveFinalData= [];
      for (let i = 0; i < this.studentList.length; i++) {
        if (this.studentListData.date) {
          if (this.studentList[i].type != '') {
            this.saveFinalData.push(this.studentList[i])
          }
        }
      }
      console.log(this.saveFinalData)
    }
    if (this.view == true) {
      this.saveFinalData= [];
      for (let i = 0; i < this.studentList.length; i++) {
        if (this.studentListData.date) {
          if (this.studentList[i].type != '') {
            this.saveFinalData.push(this.studentList[i])
          }
        }
      }
      console.log(this.saveFinalData)
    }
  }


  async viewReports(){
    console.log("pressed")
    const modal = await this.modalController.create({
      component: ViewReportsPage,
      cssClass: 'my-custom-class',
      componentProps: {
        filterData: this.saveFinalData,
        selectedDate: this.selectedDate,
        storeDate: this.storeDate
      },
    })
    await modal.present();
  }

  openNotificationStatus(){
    this.router.navigate(['/notification-status']);
  }
}
