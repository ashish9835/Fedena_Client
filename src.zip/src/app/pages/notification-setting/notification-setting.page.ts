import { Component, OnInit, ViewChild } from '@angular/core';
import { AlertController, IonDatetime, PopoverController } from '@ionic/angular';
import { TimePopoverComponent } from 'src/app/component/time-popover/time-popover.component';

@Component({
  selector: 'app-notification-setting',
  templateUrl: './notification-setting.page.html',
  styleUrls: ['./notification-setting.page.scss'],
})
export class NotificationSettingPage implements OnInit {
  start_time: string;
  end_time: string;

  @ViewChild(IonDatetime, { static: true }) datetime: IonDatetime;

  dateValue = '';
  dateValue2 = '';
  time1: string;
  time2: any;
  constructor(public alertController: AlertController,public popoverController: PopoverController) { 
    
  }
  

  ngOnInit() {
  }

  // async startTime() {
  //   const alert = await this.alertController.create({
  //     cssClass: 'my-custom-class',
  //     header: 'Start Time',
  //     inputs: [

  //       // input date with min & max
  //       {
  //         name: 'startTime',
  //         type: 'time'
  //       }
  //     ],
  //     buttons: [
  //       {
  //         text: 'Cancel',
  //         role: 'cancel',
  //         cssClass: 'secondary',
  //         handler: () => {
  //           console.log('Confirm Cancel');
  //         }
  //       }, {
  //         text: 'Ok',
  //         handler: (data) => {
  //           // console.log('Confirm Ok');
  //           console.log(data.startTime);
  //           this.start_time = data.startTime;
  //         }
  //       }
  //     ]
  //   });

  //   await alert.present();
  // }



  // async endTime() {
  //   const alert = await this.alertController.create({
  //     cssClass: 'my-custom-class',
  //     header: 'End Time',
  //     inputs: [
  //       {
  //         name: 'endTime',
  //         type: 'time'
  //       }
  //     ],
  //     buttons: [
  //       {
  //         text: 'Cancel',
  //         role: 'cancel',
  //         cssClass: 'secondary',
  //         handler: () => {
  //           console.log('Confirm Cancel');
  //         }
  //       }, {
  //         text: 'Ok',
  //         handler: (data) => {
  //           // console.log('Confirm Ok');
  //           console.log(data.endTime);
  //           this.end_time = data.endTime;
  //         }
  //       }
  //     ]
  //   });

  //   await alert.present();
  // }

  startTime(myTime1) {
    console.log('click..', myTime1);
    this.time1 = this.getFormatedTime1(myTime1);
    this.start_time = this.time1;
    document.getElementById('hidden').style.display = "block";
    this.popoverController.dismiss();
  }

  endTime(myTime2) {
    console.log('click..', myTime2);
    this.time2 = this.getFormatedTime2(myTime2);
    this.end_time = this.time2;
    document.getElementById('hidden').style.display = "block";
    this.popoverController.dismiss();

  }



  getFormatedTime1(myTime1) {
    var date = new Date(myTime1);
    var hours = date.getHours() > 12 ? date.getHours() - 12 : date.getHours();
    var am_pm = date.getHours() >= 12 ? "pm" : "am";
    var minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
    let time = hours + ":" + minutes + " " + am_pm;
    console.log(time);
    return time;

  }

  getFormatedTime2(myTime2) {
    var date = new Date(myTime2);
    var hours = date.getHours() > 12 ? date.getHours() - 12 : date.getHours();
    var am_pm = date.getHours() >= 12 ? "pm" : "am";
    var minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
    let time = hours + ":" + minutes + " " + am_pm;
    console.log(time);
    return time;
  }

  start() {
    document.getElementById('trigger-button1').click();
  }

  end() {
    document.getElementById('trigger-button2').click();
  }

  cancelPopUp(){
    this.popoverController.dismiss();
  }
}
