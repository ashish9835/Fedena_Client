import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NotificationStatusPageRoutingModule } from './notification-status-routing.module';

import { NotificationStatusPage } from './notification-status.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NotificationStatusPageRoutingModule
  ],
  declarations: [NotificationStatusPage]
})
export class NotificationStatusPageModule {}
