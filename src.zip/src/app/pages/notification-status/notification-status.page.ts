import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { LoadingController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-notification-status',
  templateUrl: './notification-status.page.html',
  styleUrls: ['./notification-status.page.scss'],
})
export class NotificationStatusPage implements OnInit {
  studentListData: any;
  students = [];
  isIconVisibility: boolean = false;

  constructor(private http: HttpClient,public loadingController:  LoadingController,public toastController: ToastController) { }

  ngOnInit() {
    this.getNoTificationJsondata();
  }

  async presentLoading(message: string) {
    const loading = await this.loadingController.create({
      message,
      duration: 2000,
    })
    await loading.present()
  }

  getNoTificationJsondata() {
    this.presentLoading('Loading Notification Status Data')
    this.http.get('../../../assets/notification.json').subscribe((res) => {
      console.log(res)
      this.loadingController.dismiss()
      this.studentListData = res
      console.log(this.studentListData.students);
      this.students=this.studentListData.students;
      for (let i = 0; i < this.students.length; i++) {
        this.students[i].isNotified = false;
      }
      console.log(this.students);
    })
  }

  cardstyle(student): Object {
    if (student.isNotified) {
      return { 'background-color': '#edecec'}
    }
    return {}
  }

  onClick(student){
    student.isNotified = !student.isNotified;
    student.isIconVisibility = !student.isIconVisibility;
    console.log(student);
  }

  onSelectAll(event){
    console.log(event);
    if(event.detail.checked == true){
      for (let i = 0; i < this.students.length; i++) {
        this.students[i].isNotified = true;
        this.students[i].isIconVisibility = true;
      }
    }else{
      for (let i = 0; i < this.students.length; i++) {
        this.students[i].isNotified = false;
        this.students[i].isIconVisibility = false;
      }
    }
  }


  async presentToast() {
    const toast = await this.toastController.create({
      message: 'Notification Sent...',
      duration: 2000
    });
    toast.present();
  }

  sendNotification(){
    this.presentToast();
  }


}
