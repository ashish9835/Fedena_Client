import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { IonDatetime, ModalController, PopoverController } from '@ionic/angular';
import { format, parseISO } from 'date-fns'
import {FormGroup, FormControl} from '@angular/forms';

@Component({
  selector: 'app-view-reports',
  templateUrl: './view-reports.page.html',
  styleUrls: ['./view-reports.page.scss'],
})


export class ViewReportsPage implements OnInit {
  @ViewChild(IonDatetime, { static: true }) datetime: IonDatetime;
  selectedSegment: any = 'attendance';

  @Input() filterData: any;
  @Input() selectedDate: any;
  @Input() storeDate: any;
  date: string;
  all=[];
  absent=[];
  late=[];
  allDataVisibility: boolean = true;
  absentDataVisibility: boolean = false;
  lateDataVisibility: boolean = false;
 
  constructor(public modalController: ModalController,public popoverController: PopoverController) { }

  ngOnInit() {
    console.log(this.filterData);
    for (let i = 0; i < this.filterData.length; i++) {
      this.all.push(this.filterData[i]);
      if(this.filterData[i].type == "Absent"){
        this.absent.push(this.filterData[i]);
      }
      else if (this.filterData[i].type == "Late"){
        this.late.push(this.filterData[i])
      }
      else{
        console.log('Different type data');
      }
    }
    console.log(this.all);
    console.log(this.absent);
    console.log(this.late);
  }

  dismissModel() {
    this.modalController.dismiss();
  }

  formatDate(value) {
    this.selectedDate = format(parseISO(value), 'MMM dd')
    console.log(value)
    this.storeDate = value
    console.log(this.storeDate)
    console.log(this.selectedDate)
    return format(parseISO(value), 'MMM dd')
  }

  start() {
    document.getElementById('trigger-button1').click();
  }

  allData(){
    console.log(this.all);
    this.allDataVisibility = !this.allDataVisibility;
    this.absentDataVisibility = false;
    this.lateDataVisibility =false;
  }

  absentData(){
    console.log(this.absent);
    this.absentDataVisibility = !this.absentDataVisibility;
    this.allDataVisibility = false;
    this.lateDataVisibility = false;
  }

  lateData(){
    console.log(this.late);
    this.lateDataVisibility = !this.lateDataVisibility;
    this.allDataVisibility = false;
    this.absentDataVisibility =false;
  }

  absentstyle(): Object {
    if (this.absentDataVisibility) {
      return { 'background-color': 'black', color: 'white' }
    }
    return {}
  }

  latestyle(): Object {
    if (this.lateDataVisibility) {
      return { 'background-color': 'black', color: 'white' }
    }
    return {}
  }

  allstyle(): Object {
    if (this.allDataVisibility) {
      return { 'background-color': 'black', color: 'white' }
    }
    return {}
  }

}
