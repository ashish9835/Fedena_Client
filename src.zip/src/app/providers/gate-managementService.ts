import { HttpClient, HttpParams } from '@angular/common/http'
import { Injectable, OnInit } from '@angular/core'
import { AppSettings } from '../models/app-setting'

@Injectable({
  providedIn: 'root',
})
export class GateManagementService {


  constructor(public http: HttpClient) {}

  ngOnInit() {}

  getTableData(httpParams) {
    const apiUrl = AppSettings.APP_API_URL + 'gate_management/reports?' + httpParams;
    return this.http.get(`${apiUrl}`)
  }

  getGraphData(httpParams) {
    const apiUrl = AppSettings.APP_API_URL + 'gate_management/statistics?' + httpParams;
    return this.http.get(`${apiUrl}`)
  }
}
