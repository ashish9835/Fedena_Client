import { Component, Input, ViewChild, ElementRef, Output, EventEmitter, OnInit } from '@angular/core';
/**
 * Generated class for the AttachmentChipComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'attachment-chip',
  templateUrl: 'attachment-chip.html',
  styleUrls: ['attachment-chip.scss']
})
export class AttachmentChipComponent implements OnInit {
  previousPosition: number = 0;
  previousPreviousPosition: number = -1;
  @Input() file: any;
  @Input() uploadProgress: number;
  @Input() showRemove: boolean = true;
  @Output() onClickRemove = new EventEmitter();
  @Output() onClickReload = new EventEmitter();
  @ViewChild('progressBar') progressBar: any;
  progressStyleUpdate: any = {
    width: "16px"
  }

  constructor() { }

  ngOnInit() {
  }
  onClick_Reload() {
    console.log("this is called ... . . .. . . .")
    if (this.file.isCanceled || this.file.errorUploading) {
      this.file.isCanceled = false;
      this.file.errorUploading = false;
      this.file.uploadProgress = 0;
      this.file.isReloaded = true;
    }
    this.ngOnChanges();
    return this.onClickReload.emit(this.file)
  }
  ngOnChanges() {
    this.progressStyleUpdate.width = this.uploadProgress + "%";

    // let localPreviousPosition = this.previousPosition;
    // let counter = localPreviousPosition;
    // let localPreviousPreviousPosition = this.previousPosition;

    //  this.previousPosition = this.uploadProgress;
    //  this.previousPreviousPosition = this.previousPosition;
    // //  let counter = this.previousPosition;             

    //  while(counter<=this.uploadProgress && localPreviousPosition >= this.previousPreviousPosition)
    //  {
    // setTimeout(()=>{

    //   this.progressStyleUpdate.width = counter + "%";
    //  console.log("counter  "+counter)
    //   counter++;},50)}
    //   if(this.previousPosition ===0)
    //  { this.previousPosition = 1
    //   setTimeout(()=>{
    //     console.log("hah first time")

    //   },4000)}


  }

}