
import { CommonModule } from '@angular/common';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { PipesModule } from 'src/pipes/pipes.module';
import { AttachmentChipComponent } from './attachment-chip/attachment-chip';
import { MultipleStateCheckboxComponent } from './multiple-state-checkbox/multiple-state-checkbox';
import { SortButtonComponent } from './sort-button/sort-button';
import { SortOptionsComponent } from './sort-button/sort-options/sort-options';
@NgModule({
	declarations: [AttachmentChipComponent, MultipleStateCheckboxComponent, SortButtonComponent, SortOptionsComponent],
	imports: [
		CommonModule,
		PipesModule,
	],
	exports: [AttachmentChipComponent, MultipleStateCheckboxComponent, SortButtonComponent, SortOptionsComponent],
	schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ComponentsModule { }