import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { MultipleStateCheckboxComponent } from './multiple-state-checkbox';

describe('multiplestate', () => {
  let component: MultipleStateCheckboxComponent;
  let fixture: ComponentFixture<MultipleStateCheckboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MultipleStateCheckboxComponent],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MultipleStateCheckboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
