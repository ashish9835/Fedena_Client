import { Component, ElementRef, Input, EventEmitter, Output, OnInit } from '@angular/core';

/**
 * Generated class for the MultipleStateCheckboxComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
enum States {
  Complete = 'complete',
  Partial = 'partial',
  Null = 'null'
}
@Component({
  selector: 'multiple-state-checkbox',
  templateUrl: 'multiple-state-checkbox.html',
  styleUrls: ['multiple-state-checkbox.scss']
})
export class MultipleStateCheckboxComponent implements OnInit {
  @Input()
  state: States = States.Null;

  icon: string;

  @Output()
  onStateChange = new EventEmitter()

  constructor(
    private _elementRef: ElementRef
  ) {
    this.updateView()
  }
  ngOnChanges() {
    this.updateView()
  }
  ngOnInit(){
    
  }
  //on click handler.
  onClick() {
    switch (this.state) {
      case undefined:
      case States.Null: this.state = States.Complete; break;
      case States.Complete: this.state = States.Null; break;
      case States.Partial: this.state = States.Null; break;
    }
    this.onStateChange.emit(this.state);//emit the state change as event.
    this.updateView();//update view 
  }
  //update the ion-icon based on the state.
  updateView() {
    switch (this.state) {
      case States.Null: this.icon = 'add-circle-outline'; break;
      case States.Complete: this.icon = 'checkmark-circle'; break;
      case States.Partial: this.icon = 'checkmark-circle-outline'; break;
    }
  }
}
