import { EventEmitter } from '@angular/core';
import { Component, Input, Output } from '@angular/core';
import { PopoverController } from '@ionic/angular';
import { EventsService } from 'src/providers/events/events.service';
import { SortOptionsComponent } from './sort-options/sort-options';
@Component(
  {
    selector: 'sort-button',
    template: `<ion-button (click)='presentOptions()'>
                     <ion-icon slot="icon-only" name="funnel"></ion-icon>
                  </ion-button>`,
    styles: ['button { box-shadow:none !important }']
  }
)
export class SortButtonComponent {
  @Input() title: string;
  @Input() cssClass: string;
  @Input() selectedValue: number;
  @Input() options: any[];//component recieves an array of options. array of {string name, any value}
  @Output() onOptionChange = new EventEmitter();//emits output option emitted on select (used by sort options comp)
  @Input() default: any; //component recieves a default option to be selected.{string name, any value}
  constructor(
    public popoverCtrl: PopoverController,
    private event: EventsService
  ) {

  }
  async presentOptions(myEvent) {
    //opens a popover with sortoptions component.
    const popover = await this.popoverCtrl.create({
      component: SortOptionsComponent,
      cssClass: this.cssClass,
      event: myEvent,
      translucent: true,
      componentProps: { context: this, title: this.title, options: this.options, default: this.default, selectedValue: this.selectedValue }
    });
    this.event.subscribe('dismiss:overlay', () => {
      if (popover)
        popover.dismiss();
    })
    return await popover.present();
  }

}
