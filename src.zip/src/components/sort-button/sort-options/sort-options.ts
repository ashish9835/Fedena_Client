import { Storage } from '@ionic/storage';
import { Component, OnInit } from "@angular/core";
import { SortButtonComponent } from '../sort-button';
import { EventsService } from 'src/providers/events/events.service';


@Component({
   selector: 'sort-options',
   templateUrl: 'sort-options.html',
   styleUrls: ['sort-options.scss']
})
//this component is invoked by popover controller in the sort button component.
export class SortOptionsComponent implements OnInit {
   title: string;
   options: any[];
   selectedOptionValue: any;
   firstChange: boolean;
   context: SortButtonComponent
   constructor(private storage: Storage, private events: EventsService) {
      // this.options = this.navParams.get('options');//set of options to display
      // this.context = this.navParams.get('context');//context points to sort button component.
      // this.selectedOptionValue = this.navParams.get('default') ? this.navParams.get('default').value : null;//set the selection option value to default input option
      // this.title = this.navParams.get('title');
      // this.selectedOptionValue = this.navParams.get('selectedValue') ? this.navParams.get('selectedValue') : null;
   }
   ngOnInit() {
      console.log(this.options, 'options');
   }
   onOptionChange(event) {
      console.log(event, 'event')
      this.selectedOptionValue = event.detail.value; 
      //invokes the emitter in SortButtonComponent with the selected option.
      if (!this.firstChange && this.selectedOptionValue) {
         let option = this.options.find(a => { return a.value === Number.parseInt(this.selectedOptionValue); })//get the selected option from the options.
         this.context.onOptionChange.emit(option)//output the selected option through sort button component output emitter.
      }
      //when the options pop the 'selectedOptionValue' assignment in the constructor causes 'onChange' event 
      //So, at first onChange event this should not dismiss the options(overlay), only when the user selects
      //an option it should be dismissed.

      if (!this.firstChange) this.dismissOverlay(); else this.firstChange = false;
   }
   dismissOverlay() {
      this.events.publish('dismiss:overlay', {});
   }

}
