import { NgModule } from '@angular/core';
import { SwitchLanguageDirective } from './switch-language/switch-language';
import { AutoResizeTextareaDirective } from './auto-resize-textarea/auto-resize-textarea';
@NgModule({
	declarations: [SwitchLanguageDirective,
    AutoResizeTextareaDirective],
	imports: [],
	exports: [SwitchLanguageDirective,
    AutoResizeTextareaDirective]
})
export class DirectivesModule {}
