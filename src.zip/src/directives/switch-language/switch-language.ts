

/**
 * See https://angular.io/api/core/Directive for more info on Angular
 * Directives.
 * 
 * this directive can be used change the language of the app based selction from dialog box it presents.
 * the language selection dialog box will be shown when the user 'click' on the host element or
 * based on 'showLangDialog' input.
 */

import { Directive, HostListener, Input } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, MenuController, NavController, Platform } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { AppSettings, LANGUAGE_SELECTOR_CONFIG } from 'src/models/app-settings';
import { EventsService } from 'src/providers/events/events.service';
import { School } from 'src/providers/school';
import { User } from 'src/providers/user';

@Directive({
  selector: '[switchLanguage]',
})
export class SwitchLanguageDirective {
  @Input() showLangDialog: boolean;

  TITLE_TEXT: string = 'Select your preferred language.';
  CANCEL_TEXT: string = 'Cancel';
  OK_TEXT: string = 'OK'
  alert: any;
  constructor(
    private menu: MenuController,
    private school: School,
    private alertCtrl: AlertController,
    private platform: Platform,
    private translate: TranslateService,
    private events: EventsService,
    private user: User,
    private router: Router,
    private navCtrl: NavController
  ) {
  }
  ngOnInit() {
    this.platform.ready().then(()=> {
      setTimeout(() => {
        this.initTranslationTexts();
      }, 100);
    })
  }

  async initTranslationTexts() {
    this.TITLE_TEXT = await this.translate.get('dialog.select_language').toPromise();
    this.CANCEL_TEXT = await this.translate.get('button.cancel').toPromise();
    this.OK_TEXT = await this.translate.get('button.ok').toPromise();
  }

  ngOnChanges() {
    //can also show lang selection dialog box using an input 'showLangDialog' to the directive
    if (this.showLangDialog === true) {
      this.showLangModal();
    } else {
      if (this.alert) this.alert.dismiss();
    }
  }
  //on click show a modal with the different available languages.
  @HostListener('click')
  async showLangModal() {
    if (!AppSettings.INAPP_LANGUAGE_SWITCHING) return;
    let locale = 'en';
    locale = await this.school.getSchool('user_preferred_locale');
    if (!locale) {//if no user preferred locale 
      locale = await this.school.getSchool('locale') || 'en';//get the default locale
    }
    let inputs = []
    LANGUAGE_SELECTOR_CONFIG.LOCALES.forEach(val => {
      inputs.push({
        type: 'radio',
        label: val.name,
        value: val.code,
        checked: (val.code === locale)
      });
    });
    this.alert = await this.alertCtrl.create({
      header: this.TITLE_TEXT,
      inputs: inputs,
      buttons: [
        {
          text: this.CANCEL_TEXT,
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {

          }
        }, {
          text: this.OK_TEXT,
          handler: data => {
            //on select language change the language 
            this.changeLanguage(data).subscribe(() => {
              this.school.setSchool('user_preferred_locale', data);//set current selected language as the user preferred lang. 
              //Reload pages so that change in language is reflected properly.
              this.user.getAccessToken().then(val => {

                if (AppSettings.MULTI_SCHOOL_MODE) {
                  let currentpage = this.getCurrentPage();
                  switch (currentpage) {
                    case '/school-login':
                    case '/schools-list':
                    case '/walkthrough':
                      this.navCtrl.setDirection('root');
                      this.router.navigateByUrl(currentpage, { replaceUrl: true });
                      return;
                    case '/login-email':
                      this.navCtrl.back();
                      this.navCtrl.setDirection('root');
                      this.router.navigateByUrl(currentpage, { replaceUrl: true });
                      return;
                    default:
                      this.navCtrl.setDirection('root');
                      this.router.navigateByUrl('/tabs', { replaceUrl: true })
                      return;
                  }
                } else {
                  this.user.getUsername().then(val => {
                    if (val) {
                      this.navCtrl.setDirection('root');
                      this.router.navigateByUrl('/tabs', { replaceUrl: true })
                      this.events.publish('school:load');
                      this.events.publish('load:menu');
                    } else {
                      this.navCtrl.setDirection('root');
                      this.router.navigateByUrl('/tutorial', { replaceUrl: true })
                    }
                  })

                }

              })

            });
            if (alert)
              this.alert.dismiss();
          }
        }
      ]
    });
    await this.alert.present();
  }
  getCurrentPage() {
    return this.router.url;
  }
  //Changes the directon and also switch menu based on direction. 
  changeDir(dir) {
    this.platform.ready().then(
      () => {
        document.documentElement.dir = dir;
        if (dir === 'rtl') {
          this.menu.enable(false, 'left')
          this.menu.enable(true, 'right')
        } else {
          this.menu.enable(true, 'left')
          this.menu.enable(false, 'right')
        }
      }
    )
  }
  changeLanguage(languageCode: string) {
    if (languageCode === 'ar') {//changes dir to rtl for language code 'ar'
      this.changeDir('rtl');
    } else this.changeDir('ltr')
    //set the language to use by the translate service.
    return this.translate.use(languageCode);
  }

}

