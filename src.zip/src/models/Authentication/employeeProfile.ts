/**
 * A employee profile model that our Master-Detail pages list, create, and delete.
 *
 * Change "Item" to the noun your app will use. For example, a "Contact," or a
 * "Customer," or a "Animal," or something like that.
 *
 * The Items service manages creating instances of Item, so go ahead and rename
 * that something that fits your app as well.
 */
import { TransformKeyNames } from '../transformKeyNames';

export class ProfileModel {
  id: number;
  employeeNumber: string;
  gender: string;
  jobTitle: string;
  qualification: string;
  status: boolean;
  email: string;
  fullName: string;
  employeeCategoryName: string;
  employeeDepartmentName: string;
  employeePositionName: string;
  employeeGradeName: string;
  reportingManagerFullName: string;
  totalExperience: number[];
  profilePhoto: string;
  biometricInfo: string;
  joiningDate: string;
  createdAt: string;
  updatedAt: string;
  token: string;
  role: string;
  userId: number;
  private transform = new TransformKeyNames();
  constructor(profile?: any) {
    
    // Transform all underscore keynames to camelCase
    if (profile) {
      // tslint:disable-next-line:max-line-length
      const flattenedNewProfile = this.transform.fromUnderscoreToCamelCase(profile);
      console.log('The flattenedNewProfile object is:', flattenedNewProfile);
      const flattendedObjectKeys = Object.keys(flattenedNewProfile);
      flattendedObjectKeys.forEach((key) => {
        this[key] = flattenedNewProfile[key];
      });
      console.log('The flattenedNewProfile is:', this);

    }
  }
}

export class EmployeeProfileModel {
  userId: number;
  accessToken: string;
  username: string;
  role: string;
  profile : ProfileModel;
  private transform = new TransformKeyNames();
  constructor(newEmployeeProfile?: any) {
    
    // Transform all underscore keynames to camelCase
    if (newEmployeeProfile) {
      // tslint:disable-next-line:max-line-length
      const flattenedNewEmployeeProfile = this.transform.fromUnderscoreToCamelCase(newEmployeeProfile);
      // console.log('The flattenedNewEmployeeProfile object is:', flattenedNewEmployeeProfile);
      const flattendedObjectKeys = Object.keys(flattenedNewEmployeeProfile);
      flattendedObjectKeys.forEach((key) => {
        this[key] = flattenedNewEmployeeProfile[key];
      });
      // console.log('The EmployeeProfileModel is:', this);

    }
  }
  public getEmployeeData() {
    return this;
  }
}
