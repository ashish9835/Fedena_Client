/**
 * A guardian profile model that our Master-Detail pages list, create, and delete.
 *
 * Change "Item" to the noun your app will use. For example, a "Contact," or a
 * "Customer," or a "Animal," or something like that.
 *
 * The Items service manages creating instances of Item, so go ahead and rename
 * that something that fits your app as well.
 */
import { TransformKeyNames } from '../transformKeyNames';

export class ProfileModel {
  id: number;
  admissionNo: string;
  gender: string;
  email: string;
  fullName: string;
  batchName: string;
  batchCourseName: string;
  profilePhoto: string;
  guardianName: string;
  guardianId: string;
  studentRollNumber: string;
  admissionDate: string;
  createdAt: string;
  updatedAt: string;
  role: string;
  token: string;
  userId: number;
  private transform = new TransformKeyNames();
  constructor(profile?: any) {

    // Transform all underscore keynames to camelCase
    if (profile) {
      // tslint:disable-next-line:max-line-length
      const flattenedNewProfile = this.transform.fromUnderscoreToCamelCase(profile);
      console.log('The flattenedNewProfile object is:', flattenedNewProfile);
      const flattendedObjectKeys = Object.keys(flattenedNewProfile);
      flattendedObjectKeys.forEach((key) => {
        this[key] = flattenedNewProfile[key];
      });
      console.log('The flattenedNewProfile is:', this);

    }
  }
}

export class GuardianProfileModel {
  userId: number;
  accessToken: string;
  username: string;
  role: string;
  profile: ProfileModel[];

  private transform = new TransformKeyNames();
  constructor(newGuardianProfile?: any) {

    // Transform all underscore keynames to camelCase
    if (newGuardianProfile) {
      // tslint:disable-next-line:max-line-length
      const flattenedNewGuardianProfile = this.transform.fromUnderscoreToCamelCase(newGuardianProfile);
      // console.log('The flattenedNewGuardianProfile object is:', flattenedNewGuardianProfile);
      const flattendedObjectKeys = Object.keys(flattenedNewGuardianProfile);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedNewGuardianProfile[key];
        if (key === 'profile' && object) {
          const tempo = [];
          object.forEach(i => {
            tempo.push(new ProfileModel(i));
          });
          this[key] = tempo;
        } else this[key] = object;
      });
      // console.log('The GuardianProfileModel is:', this);

    }
  }
  public getGuardianData() {
    return this;
  }
}
