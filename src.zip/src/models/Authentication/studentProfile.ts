/**
 * A student profile model that our Master-Detail pages list, create, and delete.
 *
 * Change "Item" to the noun your app will use. For example, a "Contact," or a
 * "Customer," or a "Animal," or something like that.
 *
 * The Items service manages creating instances of Item, so go ahead and rename
 * that something that fits your app as well.
 */
import { TransformKeyNames } from '../transformKeyNames';
export class ProfileModel {
  id: number;
  admissionNo: string;
  gender: string;
  email: string;
  fullName: string;
  batchName: string;
  batchCourseName: string;
  profilePhoto: string;
  guardianName: string;
  guardianId: string;
  studentRollNumber: string;
  admissionDate: string;
  createdAt: string;
  updatedAt: string;
  role: string;
  token: string;
  userId: number;
  private transform = new TransformKeyNames();
  constructor(profile?: any) {

    // Transform all underscore keynames to camelCase
    if (profile) {
      // tslint:disable-next-line:max-line-length
      const flattenedNewProfile = this.transform.fromUnderscoreToCamelCase(profile);
      console.log('The flattenedNewProfile object is:', flattenedNewProfile);
      const flattendedObjectKeys = Object.keys(flattenedNewProfile);
      flattendedObjectKeys.forEach((key) => {
        this[key] = flattenedNewProfile[key];
      });
      console.log('The flattenedNewProfile is:', this);

    }
  }
}
export class StudentProfileModel {
  userId: number;
  accessToken: string;
  username: string;
  role: string;
  profile: ProfileModel;
  private transform = new TransformKeyNames();
  constructor(newStudentProfile?: any) {
    // Transform all underscore keynames to camelCase
    if (newStudentProfile) {
      // tslint:disable-next-line:max-line-length
      const flattenedNewStudentProfile = this.transform.fromUnderscoreToCamelCase(newStudentProfile);
      // console.log('The flattenedNewStudentProfile object is:', flattenedNewStudentProfile);
      const flattendedObjectKeys = Object.keys(flattenedNewStudentProfile);
      flattendedObjectKeys.forEach((key) => {
        this[key] = flattenedNewStudentProfile[key];
      });
      // console.log('The StudentProfileModel is:', this);

    }
  }
  public getStudentData() {
    return this;
  }
}
