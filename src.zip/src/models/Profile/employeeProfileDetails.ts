
import { TransformKeyNames } from '../transformKeyNames';

export class EmployeeProfileDetailsModel {
    id: number;
    employeeNumber: string;
    gender: string;
    jobTitle: string;
    qualification: string;
    status: boolean;
    email: string;
    createdAt: string;
    updatedAt: string;
    fullName: string;
    employeeCategoryName: string;
    employeeDepartmentName: string;
    employeePositionName: string;
    employeeGradeName: string;
    reportingManagerFullName: string;
    totalExperience: number[];
    profilePhoto: string;
    biometricInfo: string;
    joiningDate: string;
    maritalStatus: string;
    fatherName: string;
    motherName: string;
    bloodGroup: string;
    nationalityName: string;
    dateOfBirth: string;
    homeAddressLine1: string;
    homeAddressLine2: string;
    homeCity: string;
    homeState: string;
    homePinCode: string;
    officeAddressLine1: string;
    officeAddressLine2: string;
    officeCity: string;
    officeState: string;
    officePinCode: string;
    homeCountryName: string;
    officeCountryName: string;
    officePhone1: string;
    officePhone2: string;
    mobilePhone: string;
    homePhone: string;
    fax: string;
    additionalDetails: string[];
    bankDetails: string[];

    private transform = new TransformKeyNames();
    constructor(newEmployeeProfile?: any) {

        if (newEmployeeProfile) {
            // tslint:disable-next-line:max-line-length
            const flattenedNewEmployeeProfile = this.transform.fromUnderscoreToCamelCase(newEmployeeProfile);
            // console.log('The flattenedNewEmployeeProfile object is:', flattenedNewEmployeeProfile);
            const flattendedObjectKeys = Object.keys(flattenedNewEmployeeProfile);
            flattendedObjectKeys.forEach((key) => {
                this[key] = flattenedNewEmployeeProfile[key];
            });
            // console.log('The EmployeeProfileModel is:', this);

        }
    }
    public getEmployeeDetails() {
        return this;
    }
}