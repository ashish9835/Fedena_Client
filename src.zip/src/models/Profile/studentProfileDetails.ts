import { TransformKeyNames } from '../transformKeyNames';

export class StudentProfileDetailsModel {

  id?: number;
  admissionNo: string;
  gender: string;
  email: string;
  createdAt: string;
  updatedAt: string;
  fullName: string;
  batchName: string;
  batchCourseName: string;
  profilePhoto: string;
  guardianName: string;
  guardianId: number;
  studentRollNumber: string;
  admissionDate: string;
  bloodGroup: string;
  birthPlace: string;
  language: string;
  religion: string;
  nationalityName: string;
  dateOfBirth: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  pinCode: string;
  homeCountryName: string;
  phone1: string;
  phone2: string;
  guardianMobilePhone: string;
  additionalDetails: any[];


  private transform = new TransformKeyNames();
  constructor(studentProfile?: any) {

    if (studentProfile) {
      // tslint:disable-next-line:max-line-length
      const flattenedStudentProfile = this.transform.fromUnderscoreToCamelCase(studentProfile);
      // console.log('The flattenedStudentProfile object is:', flattenedStudentProfile);
      const flattendedObjectKeys = Object.keys(flattenedStudentProfile);
      flattendedObjectKeys.forEach((key) => {
        this[key] = flattenedStudentProfile[key];
      });
      // console.log('The StudentProfile is:', this);

    }
  }
  public getStudentData() {
    return this;
  }
}
