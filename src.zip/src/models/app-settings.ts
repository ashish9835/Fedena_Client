import * as data from '../../app_config.json';
import * as  demo_data from '../../demo_app_config.json';
import * as _lodash from 'lodash';

export class AppSettings {

  public static APP_API_URL = data.api_url;
  public static APP_NAME = data.app_name;
    // mandatory 
  public static SCHOOL_NAME       = data.school_name;
  public static SCHOOL_IDENTITY   = data.school_identity;
  public static SCHOOL_GROUP_IDENTITY   = data.school_identity;
  public static SENDER_ID         = data.sender_id;
  public static COLOUR_STATUS_BAR = data.status_bar_colour;

  // image links
  public static SCHOOL_LOGO = data.school_logo;
  public static SCHOOL_BANNER = data.school_cover;
  public static POWERED_BY_LOGO = data.powered_by_logo;
  public static POWERED_BY_URL = data.powered_by_url;

  // app details
  public static APP_VERSION = '1.0';
  public static DEVICE_TYPE = data.platform;
  public static PACKAGE_NAME = data.package_name;
  // public static PLAY_STORE_LINK = data.play_store_link;
  // public static APP_STORE_LINK = data.app_store_link;



  //demo details
  public static DEMO_MODE = data.demo_mode;
  public static DEMO_PARENT = demo_data.demo_parent;
  public static DEMO_STUDENT = demo_data.demo_student;
  public static DEMO_EMPLOYEE = demo_data.demo_employee;

  //multischool details
  public static MULTI_SCHOOL_MODE = data.multi_school_mode;

  // public static MULTI_SCHOOL_MODE = data.multi_school_mode;
  
  //inapp language switching.
  public static INAPP_LANGUAGE_SWITCHING = data.inapp_language_switching;
  constructor() {
  }
}
// export const LANGUAGE_SELECTOR_CONFIG = new Proxy(data.language_selector_config || {}, {
//   get: (obj, prop)=> {
//     if (!(prop in obj)) {
//       if (prop === 'LOCALES') {
//         let value = ('addon_languages' in obj) ? 
//         _lodash.unionBy(obj['addon_languages'], LANGUAGE_SELECTOR_CONFIG.default_languages, 'code'): 
//         LANGUAGE_SELECTOR_CONFIG.default_languages;
//         return value;
//       }
//       if (prop === 'default_languages') {
//         return [{
//           code: 'en',
//           name: 'English'
//         }]
//       }
//       if( prop === 'LOCALE_CODES' ){
//         let codes = []
//         LANGUAGE_SELECTOR_CONFIG.LOCALES.forEach(locale => {
//           codes.push(locale.code)
//         });
//         return codes;
//       }
//     } else {
//       return obj[prop]
//     }
//   }
// })
class $LANGUAGE_SELECTOR_CONFIG {
  // private static LOCALE_CODES = [{code: 'en', name: 'English'}]
  private config = data.language_selector_config || <any>{};
  public get default_languages() {
    return this.config.default_languages || [{ code: 'en', name: 'English' }];
  }
  public get LOCALE_CODES(): any {
    let value = []
    this.LOCALES.forEach(locale => {
      value.push(locale.code)
    });
    return value;
  }
  public get LOCALES(): any {

    let value = ('addon_languages' in this.config) ?
      _lodash.unionBy(this.config['addon_languages'], this.default_languages, 'code') :
      this.default_languages;
    return value;
  }

}
export const LANGUAGE_SELECTOR_CONFIG = new $LANGUAGE_SELECTOR_CONFIG();