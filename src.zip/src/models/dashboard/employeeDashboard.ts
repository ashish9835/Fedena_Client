import { TransformKeyNames } from '../transformKeyNames';
import { EventDataModel } from '../events/events';
import { PeriodModel } from '../time-table/time-table';
export class EventModel {
  total: number;
  events: EventDataModel[];

  private transform = new TransformKeyNames();
  constructor(event?: any) {
    
            // Transform all underscore keynames to camelCase
    if (event) {
                // tslint:disable-next-line:max-line-length
      const flattenedEvent = this.transform.fromUnderscoreToCamelCase(event);
          // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedEvent);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedEvent[key];
        if (key === 'events' && object) {
          const tempo = [];
          object.forEach(i => {
            tempo.push(new EventDataModel(i));
          });
          this[key] = tempo;
        } else this[key] = object;
      });
          // console.log('The Events is:', this);
    
    }
  }
  public getEvent() {
    return this;
  }
}
export class TimetablesModel {
  total: number;
  periods: PeriodModel[];

  private transform = new TransformKeyNames();
  constructor(timetable?: any) {
    
            // Transform all underscore keynames to camelCase
    if (timetable) {
                // tslint:disable-next-line:max-line-length
      const flattenedTimetable = this.transform.fromUnderscoreToCamelCase(timetable);
          // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedTimetable);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedTimetable[key];
        if (key === 'periods' && object) {
          const tempo = [];
          object.forEach(i => {
            tempo.push(new PeriodModel(i));
          });
          this[key] = tempo;
        } else this[key] = object;
      });
          // console.log('The Events is:', this);
    
    }
  }
  public getEvent() {
    return this;
  }
}
export class EmployeeDashboardModel {
  success: boolean;
  attendances: {
    percentage: number;
  };
  departmentName: string;
  employeeNumber: string;
  fullName: string;
  id: number;
  myBatch: boolean;
  news: true;
  events: EventModel;
  leaveRequests: {
    pendingCount: number;
  };
  timetables: TimetablesModel;
  gallery: any;
    
  private transform = new TransformKeyNames();
  constructor(employeeDashboard?: any) {
    
            // Transform all underscore keynames to camelCase
    if (employeeDashboard) {
                // tslint:disable-next-line:max-line-length
      const flattenedEmployeeDashboard = this.transform.fromUnderscoreToCamelCase(employeeDashboard);
          // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedEmployeeDashboard);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedEmployeeDashboard[key];
        if (key === 'events' && object) {          
          this[key] = new EventModel(object);
        }  else if (key === 'timetables' && object) {          
          this[key] = new TimetablesModel(object);
        } else this[key] = object;
      });
          // console.log('The Events is:', this);
    
    }
  }
  public getEmployeeDashboard() {
    return this;
  }
}
