import { TransformKeyNames } from '../transformKeyNames';
import { EventDataModel } from '../events/events';
import { PeriodModel } from '../time-table/time-table';
export class EventModel {
  total: number;
  events: EventDataModel[];

  private transform = new TransformKeyNames();
  constructor(event?: any) {
    
            // Transform all underscore keynames to camelCase
    if (event) {
                // tslint:disable-next-line:max-line-length
      const flattenedEvent = this.transform.fromUnderscoreToCamelCase(event);
          // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedEvent);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedEvent[key];
        if (key === 'events' && object) {
          const tempo = [];
          object.forEach(i => {
            tempo.push(new EventDataModel(i));
          });
          this[key] = tempo;
        } else this[key] = object;
      });
          // console.log('The Events is:', this);
    
    }
  }
  public getEvent() {
    return this;
  }
}
export class TimetablesModel {
  total: number;
  periods: PeriodModel[];

  private transform = new TransformKeyNames();
  constructor(timetable?: any) {
    
            // Transform all underscore keynames to camelCase
    if (timetable) {
                // tslint:disable-next-line:max-line-length
      const flattenedTimetable = this.transform.fromUnderscoreToCamelCase(timetable);
          // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedTimetable);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedTimetable[key];
        if (key === 'periods' && object) {
          const tempo = [];
          object.forEach(i => {
            tempo.push(new PeriodModel(i));
          });
          this[key] = tempo;
        } else this[key] = object;
      });
          // console.log('The Events is:', this);
    
    }
  }
  public getEvent() {
    return this;
  }
}

export class StudentDashboardModel {
  success: boolean;
  attendances: {
    percentage: number;
  };
  admissionNumber: string;
  batchFullName: string;
  batchName: string;
  fullName: string;
  fees: number;
  id: number;
  myBatch: boolean;
  news: true;
  events: EventModel;
  timetables: TimetablesModel;
  gallery: any;
    
  private transform = new TransformKeyNames();
  constructor(studentDashboard?: any) {
    
            // Transform all underscore keynames to camelCase
    if (studentDashboard) {
                // tslint:disable-next-line:max-line-length
      const flattenedStudentDashboard = this.transform.fromUnderscoreToCamelCase(studentDashboard);
          // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedStudentDashboard);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedStudentDashboard[key];
        if (key === 'events' && object) {          
          this[key] = new EventModel(object);
        } else if (key === 'timetables' && object) {          
          this[key] = new TimetablesModel(object);
        } else this[key] = object;
      });
          // console.log('The Events is:', this);
    
    }
  }
  public getEmployeeDashboard() {
    return this;
  }
}
