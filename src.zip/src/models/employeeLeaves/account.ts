import { TransformKeyNames } from '../transformKeyNames';
export class LeaveDetailModel {
  attendance: number;
  canApply: boolean;
  leavesLeft: string;
  leavesTaken: number;
  private transform = new TransformKeyNames();
  constructor(leaveDetail?: any) {

    // Transform all underscore keynames to camelCase
    if (leaveDetail) {
      // tslint:disable-next-line:max-line-length
      const flattenedLeaveDetail = this.transform.fromUnderscoreToCamelCase(leaveDetail);
      // console.log('The flattenedAdditionalLeaves object is:', flattenedAdditionalLeaves);
      const flattendedObjectKeys = Object.keys(flattenedLeaveDetail);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedLeaveDetail[key];
        this[key] = object;
      });
      // console.log('The Additional leave is:', this);

    }
  }
  public getAccount() {
    return this;
  }
}


export class EmployeeAccountModel {
  employeeDepartmentName: string;
  fullName: string;
  id: number;
  leaveDetails: LeaveDetailModel;

  private transform = new TransformKeyNames();
  constructor(account?: any) {

    // Transform all underscore keynames to camelCase
    if (account) {
      // tslint:disable-next-line:max-line-length
      const flattenedAccount = this.transform.fromUnderscoreToCamelCase(account);
      // console.log('The flattenedAdditionalLeaves object is:', flattenedAdditionalLeaves);
      const flattendedObjectKeys = Object.keys(flattenedAccount);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedAccount[key];
        this[key] = object;
      });
      // console.log('The Additional leave is:', this);

    }
  }
  public getAccount() {
    return this;
  }
}
