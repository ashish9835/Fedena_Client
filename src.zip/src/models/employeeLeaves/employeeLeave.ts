import { TransformKeyNames } from '../transformKeyNames';
export class LeaveTypeModel {
  additionalLeaves: number;
  availableLeaves: number;
  id: number;
  leavesTaken: number;
  lossOfPay: number;
  totalLeaves: number;
  name: string;
  resetDate: string;
  private transform = new TransformKeyNames();
  constructor(leaveType?: any) {
      
            // Transform all underscore keynames to camelCase
    if (leaveType) {
                // tslint:disable-next-line:max-line-length
      const flattenedLeaveType = this.transform.fromUnderscoreToCamelCase(leaveType);
      // console.log('The flattenedAdditionalLeaves object is:', flattenedAdditionalLeaves);
      const flattendedObjectKeys = Object.keys(flattenedLeaveType);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedLeaveType[key];
        this[key] = object;
      });
      // console.log('The Additional leave is:', this);
    
    }
  }
  public getLeaveType() {
    return this;
  }
}

export class EmployeeLeaveModel {
  id : number;
  canApply: boolean;
  employeeNumber : string;
  firstName: string;
  lastName: string;
  fullName: string;
  profilePhoto: string;
  totalAdditionalLeaves: number;
  totalLeaves: number;
  totalLeavesTaken: number;
  totalAvailableLeaves: number;
  totalLossOfPay: number;
  leaveTypes: LeaveTypeModel[];
  
  private transform = new TransformKeyNames();
  constructor(leaves?: any) {
    
            // Transform all underscore keynames to camelCase
    if (leaves) {
                // tslint:disable-next-line:max-line-length
      const flattenedLeaves = this.transform.fromUnderscoreToCamelCase(leaves);
      // console.log('The flattenedLeaves object is:', flattenedLeaves);
      const flattendedObjectKeys = Object.keys(flattenedLeaves);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedLeaves[key];
        if (key === 'leaveTypes' && object) {
          const temp = [];
          object.forEach (i => {
            temp.push(new LeaveTypeModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
      // console.log('The leaves is:', this);
    
    }
  }
  public getEmployeeLeavesData() {
    return this;
  }
}
