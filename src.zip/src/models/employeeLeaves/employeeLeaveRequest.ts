import { TransformKeyNames } from '../transformKeyNames';
export class AdditionalLeavesModel {
  date: string;
  day: number;
  record: string;
  halfDay: boolean;
  private transform = new TransformKeyNames();
  constructor(additionalLeave?: any) {
      
            // Transform all underscore keynames to camelCase
    if (additionalLeave) {
                // tslint:disable-next-line:max-line-length
      const flattenedAdditionalLeaves = this.transform.fromUnderscoreToCamelCase(additionalLeave);
      // console.log('The flattenedAdditionalLeaves object is:', flattenedAdditionalLeaves);
      const flattendedObjectKeys = Object.keys(flattenedAdditionalLeaves);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedAdditionalLeaves[key];
        this[key] = object;
      });
      // console.log('The Additional leave is:', this);
    
    }
  }
  public getEmployeeLeavesData() {
    return this;
  }
}

export class EmployeeLeaveRequestModel {
    
  dateRange: string;
  daysCount: number;
  departmentName: string;
  employeeId: number;
  employeeLeaveTypeId: number;
  employeeLeaveTypeName: string;
  employeeName: string;
  id: number;
  isApproved: boolean;
  isRejected: boolean;
  isPending: boolean;
  isHalfDay: boolean;
  profilePhoto: string;
  reason: string;
  isAdditional?: boolean;
  additionalLeaveCount?: number;
  approvingManager?: string;
  approvingManagarRecordFullName?: string;
  canMarkLop?: boolean;
  isDeductable?: boolean;
  isLop?: boolean;
  lopCount?: number;
  lopFlag?: boolean;
  managerRemark?: string;
  markedAsAbsent?: boolean;
  additionalLeaves: AdditionalLeavesModel[];

  private transform = new TransformKeyNames();
  constructor(leaves?: any) {
    
            // Transform all underscore keynames to camelCase
    if (leaves) {
                // tslint:disable-next-line:max-line-length
      const flattenedLeaves = this.transform.fromUnderscoreToCamelCase(leaves);
      // console.log('The flattenedLeaves object is:', flattenedLeaves);
      const flattendedObjectKeys = Object.keys(flattenedLeaves);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedLeaves[key];
        if (key === 'additionalLeaves' && object) {
          const temp = [];
          object.forEach (i => {
            temp.push(new AdditionalLeavesModel(i));
          });
          this[key] = temp;
        } else {
          if(key === "dateRange"){
            console.log("key:"+key)
            console.log(object.split('-'))
            let dates = object.split('-');
            this['leaveFrom'] = dates[0];
            this['leaveTo'] = dates[1];
            console.log(this)

          }
          
          this[key] = object;}
      });
      // console.log('The leaves is:', this);
    
    }
  }
  public getEmployeeLeavesData() {
    return this;
  }
}
