import { TransformKeyNames } from '../transformKeyNames';

export class EventDataModel {
  description: string;
  startDate: string;
  endDate: string;
  title: string;
  eventOrigin: string;
  eventType: string;
  subjectName?: string;
  dueDate?: string;

  private transform = new TransformKeyNames();
  constructor(events?: any) {
  
          // Transform all underscore keynames to camelCase
    if (events) {
              // tslint:disable-next-line:max-line-length
      const flattenedEvents = this.transform.fromUnderscoreToCamelCase(events);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedEvents);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedEvents[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);
  
    }
  }
  public getEventsData() {
    return this;
  }
}


export class EventsModel {
        
  date: string;
  data: EventDataModel;

  private transform = new TransformKeyNames();
  constructor(events?: any) {

        // Transform all underscore keynames to camelCase
    if (events) {
            // tslint:disable-next-line:max-line-length
      const flattenedEvents = this.transform.fromUnderscoreToCamelCase(events);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedEvents);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedEvents[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);

    }
  }
  public getEventsData() {
    return this;
  }
}
