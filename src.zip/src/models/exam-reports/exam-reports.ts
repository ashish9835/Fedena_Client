import { TransformKeyNames } from '../transformKeyNames';
export class ReportModel {
  batchId: number;
  batchName: string;
  examReports: ExamReportsModel[];
  overallReports: StudentReportModel[];
  studentId: number;
  success: boolean;
  private transform = new TransformKeyNames();
  constructor(reports?: any) {

        // Transform all underscore keynames to camelCase
    if (reports) {
            // tslint:disable-next-line:max-line-length
      const flattenedReports = this.transform.fromUnderscoreToCamelCase(reports);
            // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedReports);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedReports[key];
        if (key === 'examReports' && object) {
          const temp = [];
          object.forEach((i) => {
            temp.push(new ExamReportsModel(i));
          });
          this[key] = temp;
        } else if (key === 'overallReports' && object) {
          const temp = [];
          object.forEach((i) => {
            temp.push(new StudentReportModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
            // console.log('The Events is:', this);
    }
  }
}

export class ExamReportsModel {
  section: string;
  report: StudentReportModel[];
  private transform = new TransformKeyNames();
  constructor(reports?: any) {
          // Transform all underscore keynames to camelCase
    if (reports) {
              // tslint:disable-next-line:max-line-length
      const flattenedReports = this.transform.fromUnderscoreToCamelCase(reports);
              // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedReports);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedReports[key];
        if (key === 'report' && object) {
          const temp = [];
          object.forEach((i) => {
            temp.push(new StudentReportModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
              // console.log('The Events is:', this);
    }
  }
}

export class StudentReportModel {
  reportname: string;
  pdfLink: {
    sessionId: string;
    url: string;
  };
  private transform = new TransformKeyNames();
  constructor(reports?: any) {
   // Transform all underscore keynames to camelCase
    if (reports) {
              // tslint:disable-next-line:max-line-length
      const flattenedReports = this.transform.fromUnderscoreToCamelCase(reports);
              // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedReports);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedReports[key];
        if (key === 'report' && object) {
          const temp = [];
          object.forEach((i) => {
            temp.push(new StudentReportModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
              // console.log('The Events is:', this);
    }
  }
}
