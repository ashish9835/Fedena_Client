import { TransformKeyNames } from '../transformKeyNames';
import { LinkModel } from './feeDetail';


// "batch_details": {
//   "student_id": 809,
//   "current_batch_id": 205,
//   "current_batch": "G1 - A(2015-2016)",
//   "student_batches": [
//       {
//           "id": 205,
//           "name": "A(2015-2016)",
//           "full_name": "G1 - A(2015-2016)"
//       }
//   ]
// },
export class AllFeeDetailsModel{
    admissionNo: string;
    batchCourseName: string;
    batchId: number;
    currencyType:string;
    batchName: string;
    courseId: number;
    fullName: string;
    id: number;
    profilePhoto: string;
    studentRollNumber: string;
    totalFeeDue: string;
    feesDetails:any;  
    precision:number;
    sessionId:string;
    batchDetails:BatchDetails;
    onlinePaymentDetails:OnlinePaymentDetailsModel;
    paymentReceipts:PayAllFeeReceiptModel[] = [];
      private transform = new TransformKeyNames();
      constructor(fees?: any) {
    
            // Transform all underscore keynames to camelCase
        if (fees) {
                // tslint:disable-next-line:max-line-length
          const flattenedFees = this.transform.fromUnderscoreToCamelCase(fees);
          // console.log('The flattenedEvents object is:', flattenedEvents);
          const flattendedObjectKeys = Object.keys(flattenedFees);
          flattendedObjectKeys.forEach((key) => {
            const object = flattenedFees[key];
            if (key === 'feesDetails' && object) {
              let temp:any = {};
              object.forEach(i => {
                if(temp[i.finance_type] === undefined){
                    temp[i.finance_type]=[];
                }
                temp[i.finance_type].push(new FeesDetailModel(i,flattenedFees['precision']))
              });
              this[key] = temp;
            }
            else if(key === 'batchDetails' && object){
              this.batchDetails = new BatchDetails(object);
            }
            else if(key === 'onlinePaymentDetails' && object){
                 this.onlinePaymentDetails = new OnlinePaymentDetailsModel(object);
            }
            else if(key === 'paymentReceipts' && object){
              for (const key in object) {
                if (object.hasOwnProperty(key)) {
                  const element = object[key];
                  this.paymentReceipts.push(new PayAllFeeReceiptModel(element));
                }
              }
              console.log(this)
            }
             else this[key] = object;
          });
          // console.log('The Events is:', this);
    
        }
      }
    public getFees() {
      return this;
    }
}
// "batch_details": {
//   "student_id": 809,
//   "current_batch_id": 205,
//   "current_batch": "G1 - A(2015-2016)",
//   "student_batches": [
//       {
//           "id": 205,
//           "name": "A(2015-2016)",
//           "full_name": "G1 - A(2015-2016)"
//       }
//   ]
// },
export class BatchDetails{
  studentId:number;
  currentBatchId:number;
  currentBatch:string;
  studentBatches:any;
  private transform = new TransformKeyNames();
  constructor(details?:any){
    if(details){
       // tslint:disable-next-line:max-line-length
       const flattenedPayment = this.transform.fromUnderscoreToCamelCase(details);
       // console.log('The flattenedEvents object is:', flattenedEvents);
       const flattendedObjectKeys = Object.keys(flattenedPayment);
       flattendedObjectKeys.forEach((key) => {
         const object = flattenedPayment[key];
         this[key] = object;
       });

    }
  }
}
export class OnlinePaymentDetailsModel {
    paymentEnabled: boolean;
    paymentRequired: boolean;
    paymentUrl: string;
    partialPaymentEnabled:boolean;
  
    private transform = new TransformKeyNames();
    constructor(payment?: any) {
  
      // Transform all underscore keynames to camelCase
      if (payment) {
        // tslint:disable-next-line:max-line-length
        const flattenedPayment = this.transform.fromUnderscoreToCamelCase(payment);
        // console.log('The flattenedEvents object is:', flattenedEvents);
        const flattendedObjectKeys = Object.keys(flattenedPayment);
        flattendedObjectKeys.forEach((key) => {
          const object = flattenedPayment[key];
          this[key] = object;
        });
        // console.log('The Events is:', this);
  
      }
    }
    public getPayment() {
      return this;
    }
  }
  //"name": "Tution_fee_collection_july3",
  //"collection_id": 48,
  //"student_id": 844,
  //"paid_amount": "0.00",
  //"due_date": "03 July 2017",
  //"paid": false,
  //"amount_to_pay": "2300.00",
 // "finance_id": 617,
  //"finance_type": "FinanceFee",
 // "category_id": 168,
  //"title": "Receipt No..(Multiple Fees) F617",
 // "payee_type": "Student",
 // "tax_amount": "0.00",
 // "tax_enabled": false,
//"type": "general"
  export class FeesDetailModel {
    type: string;//
    collectionId: number; //
    financeId:number;//
    financeType:string;//
    categoryId:number;//
    dueDate: string;//
    amountToPay?: string;//
    title:string;
    payeeType:string;
    taxAmount:string;
    taxEnabled:string;
    name: string;//
    paid: boolean;//
    paidAmount: string;//
    studentId: number;//
    amountPaying:number;
    dueAmount:number;
    selected:boolean = false;
    isPayable:boolean = true;
      
        private transform = new TransformKeyNames();
        constructor(feesDetail?: any, precision?:number) {
      
              // Transform all underscore keynames to camelCase
          if (feesDetail) {
                  // tslint:disable-next-line:max-line-length
            const flattenedFeesDetail = this.transform.fromUnderscoreToCamelCase(feesDetail);
            // console.log('The flattenedEvents object is:', flattenedEvents);
            const flattendedObjectKeys = Object.keys(flattenedFeesDetail);
            flattendedObjectKeys.forEach((key) => {
              const object = flattenedFeesDetail[key];
              this[key] = object;
            });
            // console.log('The Events is:', this);
            this.amountPaying = Number.parseFloat(Number.parseFloat(this.amountToPay).toFixed(precision));
            this.dueAmount = Number.parseFloat(Number.parseFloat(this.amountToPay).toFixed(precision));
          }
        }
    public getFeesDetail() {
      return this;
    }
  }
  // "receipt_number": "Receipt525",
  // "payment_mode": "Online Payment",
  // "date": "2019-03-07",
  // "amount": "2392.00",
  // "link": {
  //     "url": "http://resource-8-m.navin.t.foradian.org/finance_extensions/generate_overall_fee_receipt_pdf?batch_id=205&student_id=809&transaction_id=896",
  //     "session_id": "824efe10052b75bdeda41fef9de238de"
  // }
  export class PayAllFeeReceiptModel{
     receiptNumber:string;
     paymentMode:string;
     date:string;
     amount:string;
     link:LinkModel;
     private transform = new TransformKeyNames();
     constructor(info:any){
          if(info){
            const flattenedInfo = this.transform.fromUnderscoreToCamelCase(info);
            for (const key in flattenedInfo) {
              if (flattenedInfo.hasOwnProperty(key)) {
                const element = flattenedInfo[key];
                if(key === "link" && element){
                    this[key] = new LinkModel(element);
                }else this[key] = element;
              }
            }
          }
     }

  }