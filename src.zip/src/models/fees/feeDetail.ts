import { TransformKeyNames } from '../transformKeyNames';

export class FineModel {
  fineName: string;
  fineAmount: string;
  fineAmountWithPrecision: string;
  private transform = new TransformKeyNames();
  constructor(fine?: any) {

    // Transform all underscore keynames to camelCase
    if (fine) {
      // tslint:disable-next-line:max-line-length
      const flattenedFine = this.transform.fromUnderscoreToCamelCase(fine);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedFine);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedFine[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);
    }
  }
  public getFine() {
    return this;
  }
}
export class ParticularsModel {
  amountWithPrecision: string;
  name: string;
  private transform = new TransformKeyNames();
  constructor(particulars?: any) {

    // Transform all underscore keynames to camelCase
    if (particulars) {
      // tslint:disable-next-line:max-line-length
      const flattenedParticulars = this.transform.fromUnderscoreToCamelCase(particulars);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedParticulars);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedParticulars[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);
    }
  }
  public getParticulars() {
    return this;
  }
}
export class LinkModel {
  sessionId: string;
  url: string;
  private transform = new TransformKeyNames();
  constructor(link?: any) {

    // Transform all underscore keynames to camelCase
    if (link) {
      // tslint:disable-next-line:max-line-length
      const flattenedLink = this.transform.fromUnderscoreToCamelCase(link);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedLink);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedLink[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);
    }
  }
  public getPaymentReceipt() {
    return this;
  }
}
export class PaymentReceiptModel {
  amountWithPrecision: string;
  paymentModeText: string;
  receiptNo: string;
  transactionDate: string;
  link: LinkModel;

  private transform = new TransformKeyNames();
  constructor(paymentReceipt?: any) {

    // Transform all underscore keynames to camelCase
    if (paymentReceipt) {
      // tslint:disable-next-line:max-line-length
      const flattenedPaymentReceipt = this.transform.fromUnderscoreToCamelCase(paymentReceipt);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedPaymentReceipt);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedPaymentReceipt[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);

    }
  }
  public getPaymentReceipt() {
    return this;
  }
}
export class SummaryModel {
  totalDiscount: string;
  totalFees: string;
  totalFine: string;

  private transform = new TransformKeyNames();
  constructor(summary?: any) {

   
    if (summary) {
      const flattenedSummary = this.transform.fromUnderscoreToCamelCase(summary);
      const flattendedObjectKeys = Object.keys(flattenedSummary);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedSummary[key];
        this[key] = object;
      });

    }
  }
  public getSummary() {
    return this;
  }
}
export class DiscountDataModel {
  name : string;
  amountWithPrecision: string;
  private transform = new TransformKeyNames();
  constructor(discount?: any) {
    if (discount) {
      const flattenedDiscount = this.transform.fromUnderscoreToCamelCase(discount);
      const flattendedObjectKeys = Object.keys(flattenedDiscount);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedDiscount[key];
        this[key] = object;
      });
    }
  }
  public getDiscount() {
    return this;
  }
}
export class DiscountModel {
  name : string;
  data : DiscountDataModel[];
  private transform = new TransformKeyNames();
  constructor(discount?: any) {
    if (discount) {
      const flattenedDiscount = this.transform.fromUnderscoreToCamelCase(discount);
      const flattendedObjectKeys = Object.keys(flattenedDiscount);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedDiscount[key];
        if (key === 'data' && object) {
          const temp = [];
          object.forEach((i) => {
            temp.push(new DiscountDataModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
    }
  }
  public getDiscount() {
    return this;
  }
}
export class TaxModel {
  name : string;
  amount: number;
  amountWithPrecision: string;
  private transform = new TransformKeyNames();
  constructor(tax?: any) {
    if (tax) {
      const flattenedTax = this.transform.fromUnderscoreToCamelCase(tax);
      const flattendedObjectKeys = Object.keys(flattenedTax);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedTax[key];
        this[key] = object;
      });
    }
  }
  public getTax() {
    return this;
  }
}
export class FeesDetailModel {
  batchCourseName: string;
  batchName: string;
  dueAmount: string;
  dueDate: string;
  dueDays: number;
  name: string;
  paid: boolean;
  taxEnabled: boolean;
  totalAmountPaid: string;
  totalAmountToPay: string;
  summary: SummaryModel;
  paymentReceipts: PaymentReceiptModel[];
  particulars: ParticularsModel[];
  fine: FineModel[];
  discounts?: DiscountModel[];
  taxes?: TaxModel[];
  private transform = new TransformKeyNames();
  constructor(feesDetail?: any) {

    if (feesDetail) {
      const flattenedFeesDetail = this.transform.fromUnderscoreToCamelCase(feesDetail);
      const flattendedObjectKeys = Object.keys(flattenedFeesDetail);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedFeesDetail[key];
        if (key === 'paymentReceipts' && object) {
          const temp = [];
          object.forEach((i) => {
            temp.push(new PaymentReceiptModel(i));
          });
          this[key] = temp;
        } else if (key === 'particulars' && object) {
          const tempo = [];
          object.forEach((i) => {
            tempo.push(new ParticularsModel(i));
          });
          this[key] = tempo;
        } else if (key === 'fine' && object) {
          const temp2 = [];
          object.forEach((i) => {
            temp2.push(new FineModel(i));
          });
          this[key] = temp2;
        } else if (key === 'discounts' && object) {
          const temp3 = [];
          object.forEach((i) => {
            temp3.push(new DiscountModel(i));
          });
          this[key] = temp3;
        } else if (key === 'taxes' && object) {
          const temp3 = [];
          object.forEach((i) => {
            temp3.push(new TaxModel(i));
          });
          this[key] = temp3;
        } else this[key] = object;
      });

    }
  }
  public getFeesDetail() {
    return this;
  }
}
export class OnlinePaymentDetailsModel {
  paymentEnabled: boolean;
  paymentRequired: boolean;
  paymentUrl: string;

  private transform = new TransformKeyNames();
  constructor(payment?: any) {

    // Transform all underscore keynames to camelCase
    if (payment) {
      // tslint:disable-next-line:max-line-length
      const flattenedPayment = this.transform.fromUnderscoreToCamelCase(payment);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedPayment);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedPayment[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);

    }
  }
  public getPayment() {
    return this;
  }
}
export class FeeDetailModel {
  admissionNo: string;
  batchCourseName: string;
  batchId: number;
  batchName: string;
  courseId: number;
  fullName: string;
  id: number;
  profilePhoto: string;
  studentRollNumber: string;
  type: string;
  feeDetails: FeesDetailModel;
  onlinePaymentDetails: OnlinePaymentDetailsModel;
  private transform = new TransformKeyNames();
  constructor(fees?: any) {

    // Transform all underscore keynames to camelCase
    if (fees) {
      // tslint:disable-next-line:max-line-length
      const flattenedFees = this.transform.fromUnderscoreToCamelCase(fees);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedFees);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedFees[key];
        if (key === 'feeDetails' && object) {
          this[key] = new FeesDetailModel(object);
        } else this[key] = object;
      });
      // console.log('The Events is:', this);

    }
  }
  public getFees() {
    return this;
  }
}
