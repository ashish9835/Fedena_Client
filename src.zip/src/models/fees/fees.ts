import { TransformKeyNames } from '../transformKeyNames';

export class FeesDetailModel {
  type: string;
  collectionId: number;
  dueDate: string;
  amountToPay?: string;
  transactionDate?: string;
  name: string;
  paid: boolean;
  paidAmount: string;
  studentId: number;
    
      private transform = new TransformKeyNames();
      constructor(feesDetail?: any) {
    
            // Transform all underscore keynames to camelCase
        if (feesDetail) {
                // tslint:disable-next-line:max-line-length
          const flattenedFeesDetail = this.transform.fromUnderscoreToCamelCase(feesDetail);
          // console.log('The flattenedEvents object is:', flattenedEvents);
          const flattendedObjectKeys = Object.keys(flattenedFeesDetail);
          flattendedObjectKeys.forEach((key) => {
            const object = flattenedFeesDetail[key];
            this[key] = object;
          });
          // console.log('The Events is:', this);
    
        }
      }
  public getFeesDetail() {
    return this;
  }
}
export class FeesModel {
  admissionNo: string;
  batchCourseName: string;
  batchId: number;
  batchName: string;
  courseId: number;
  fullName: string;
  id: number;
  profilePhoto: string;
  studentRollNumber: string;
  totalFeeDue: string;
  feesDetails: FeesDetailModel[];  
  
    private transform = new TransformKeyNames();
    constructor(fees?: any) {
  
          // Transform all underscore keynames to camelCase
      if (fees) {
              // tslint:disable-next-line:max-line-length
        const flattenedFees = this.transform.fromUnderscoreToCamelCase(fees);
        // console.log('The flattenedEvents object is:', flattenedEvents);
        const flattendedObjectKeys = Object.keys(flattenedFees);
        flattendedObjectKeys.forEach((key) => {
          const object = flattenedFees[key];
          if (key === 'feesDetails' && object) {
            const temp = [];
            object.forEach(i => {
              temp.push(new FeesDetailModel(i));
            });
            this[key] = temp;
          } else this[key] = object;
        });
        // console.log('The Events is:', this);
  
      }
    }
  public getFees() {
    return this;
  }
}
