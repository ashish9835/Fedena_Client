import { TransformKeyNames } from '../transformKeyNames';

export class MobileLoginModel {
  mobileIdentifier: string;
  otpSecret: string;
  private transform = new TransformKeyNames();
  constructor(login?: any) {
  
          // Transform all underscore keynames to camelCase
    if (login) {
              // tslint:disable-next-line:max-line-length
      const flattenedLogin = this.transform.fromUnderscoreToCamelCase(login);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedLogin);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedLogin[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);
  
    }
  }
  public getLogin() {
    return this;
  }
}
