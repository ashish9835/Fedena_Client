import { TransformKeyNames } from '../transformKeyNames';


export class MessageModel {
  attachment: string;
  body: string;
  id: number;
  senderId: number;
  messageTime: string;
  createdAt: string;
  private transform = new TransformKeyNames();
  constructor(message?: any) {
    
            // Transform all underscore keynames to camelCase
    if (message) {
                // tslint:disable-next-line:max-line-length
      const flattenedMessages = this.transform.fromUnderscoreToCamelCase(message);
          // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedMessages);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedMessages[key];
        this[key] = object;
      });
          // console.log('The Events is:', this);
    
    }
  }
  public getMessages() {
    return this;
  }
}

export class ChatBoxModel {
  recipientId: number;
  replyPossible: boolean;
  messages: MessageModel[];
  success: boolean;
  private transform = new TransformKeyNames();
  constructor(chatBox?: any) {
   
            // Transform all underscore keynames to camelCase
    if (chatBox) {
                // tslint:disable-next-line:max-line-length
      const flattenedChatBox = this.transform.fromUnderscoreToCamelCase(chatBox);
          // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedChatBox);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedChatBox[key];
        if (key === 'messages' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new MessageModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
          // console.log('The Events is:', this);
       
    }
  }
  public getChatBox() {
    return this;
  }
}
