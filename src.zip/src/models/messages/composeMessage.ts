import { TransformKeyNames } from '../transformKeyNames';

export class ComposeMessageModel {
  disableParent: boolean;
  disableStudent: boolean;
  status: boolean;
  success: boolean;
  private transform = new TransformKeyNames();
  constructor(message?: any) {
    
            // Transform all underscore keynames to camelCase
    if (message) {
                // tslint:disable-next-line:max-line-length
      const flattenedMessages = this.transform.fromUnderscoreToCamelCase(message);
          // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedMessages);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedMessages[key];
        this[key] = object;
      });
          // console.log('The Events is:', this);
    
    }
  }
  public getMessages() {
    return this;
  }
}
