import { TransformKeyNames } from '../transformKeyNames';
import { MessageModel } from './chatBox';

export class PrimaryMessageModel {
  body: string;
  createdAt: string;
  id: number;
  isDeleted: boolean;
  isPrimary: boolean;
  isToAll: boolean;
  messageThreadId: number;
  schoolId: number;
  senderId: number;
  updatedAt: string;
      private transform = new TransformKeyNames();
      constructor(primessage?: any) {
    
            // Transform all underscore keynames to camelCase
        if (primessage) {
                // tslint:disable-next-line:max-line-length
          const flattenedPriMessages = this.transform.fromUnderscoreToCamelCase(primessage);
          // console.log('The flattenedEvents object is:', flattenedEvents);
          const flattendedObjectKeys = Object.keys(flattenedPriMessages);
          flattendedObjectKeys.forEach((key) => {
            const object = flattenedPriMessages[key];
            this[key] = object;
          });
          // console.log('The Events is:', this);
    
        }
      }
    public getMessages() {
      return this;
    }
}

export class ReplyModel {
  profile: ProfileModel;
  role: string;
  username: string;
  recipientId?: number;
  unreadCount?: number;
  lastMessage?: MessageModel;
        private transform = new TransformKeyNames();
        constructor(replyTo?: any) {
      
              // Transform all underscore keynames to camelCase
          if (replyTo) {
                  // tslint:disable-next-line:max-line-length
            const flattenedReplyTo = this.transform.fromUnderscoreToCamelCase(replyTo);
            // console.log('The flattenedEvents object is:', flattenedEvents);
            const flattendedObjectKeys = Object.keys(flattenedReplyTo);
            flattendedObjectKeys.forEach((key) => {
              const object = flattenedReplyTo[key];
              this[key] = object;
            });
            // console.log('The Events is:', this);
      
          }
        }
      public getReply() {
        return this;
      }
}
  
export class ProfileModel {
  biometricInfo?: string;
  createdAt: string;
  updatedAt: string;
  email: string;
  fullName: string;
  gender: string;
  id: number;
  profilePhoto: string;
  recipientId: number;
  role: string;
  tagLine: string;
  employeeCategoryName?: string;
  employeeDepartmentName?: string;
  employeeGradeName?: string;
  employeeNumber?: string;
  employeePositionName?: string;
  jobTitle?: string;
  joiningDate?: string;
  qualification?:string;
  reportingManagerFullName?: string;
  status?: boolean;
  totalExperience?:number[];
  admissionDate?: string;
  admissionNo?: string;
  batchCourseName?: string;
  batchName?: string;
  guardianId?: number;
  guardianName?: string;
  studentRollNumber?: string;

  private transform = new TransformKeyNames();
  constructor(replyTo?: any) {
        
                // Transform all underscore keynames to camelCase
    if (replyTo) {
                    // tslint:disable-next-line:max-line-length
      const flattenedReplyTo = this.transform.fromUnderscoreToCamelCase(replyTo);
              // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedReplyTo);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedReplyTo[key];
        this[key] = object;
      });
              // console.log('The Events is:', this);
        
    }
  }
  public getReply() {
    return this;
  }
}

export class MessageThreadModel {
  id: number;  
  isGroup: Boolean;
  lastMessageTime: string;
  subject: string;
  unreadCount?: number;
  recipientCount?: number;
  primaryMessage: PrimaryMessageModel;
  replyTo?: ReplyModel;
  responses?: ReplyModel[];
    private transform = new TransformKeyNames();
    constructor(message?: any) {
  
          // Transform all underscore keynames to camelCase
      if (message) {
              // tslint:disable-next-line:max-line-length
        const flattenedMessages = this.transform.fromUnderscoreToCamelCase(message);
        // console.log('The flattenedEvents object is:', flattenedEvents);
        const flattendedObjectKeys = Object.keys(flattenedMessages);
        flattendedObjectKeys.forEach((key) => {
          const object = flattenedMessages[key];
          if (key === 'responses' && object) {
            const temp = [];
            object.forEach(i => {
              temp.push(new ReplyModel(i));
            });
            this[key] = temp;
          } else this[key] = object;
        });
        // console.log('The Events is:', this);
  
      }
    }
    public getMessages() {
      return this;
    }
}

export class GroupMessageModel {
  messages: MessageThreadModel;
  success: boolean;
  private transform = new TransformKeyNames();
  constructor(replyTo?: any) {

          // Transform all underscore keynames to camelCase
    if (replyTo) {
            // tslint:disable-next-line:max-line-length
      const flattenedReplyTo = this.transform.fromUnderscoreToCamelCase(replyTo);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedReplyTo);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedReplyTo[key];
        if (key === 'messages' && object) {
          this[key] = new MessageThreadModel(object);
        } else this[key] = object;
      });
      // console.log('The Events is:', this);

    }
  }
  public getReply() {
    return this;
  }
}
