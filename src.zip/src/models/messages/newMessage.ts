import { TransformKeyNames } from '../transformKeyNames';
import { ProfileModel } from './messageThreads';
export class AdminModel {
  profile: {
    fullName: string;
    profilePhoto: string;
    recipientId: number;
  };
  role: string;
  username: string;
  private transform = new TransformKeyNames();
  constructor(admin?: any) {

    // Transform all underscore keynames to camelCase
    if (admin) {
      // tslint:disable-next-line:max-line-length
      const flattenedAdmin = this.transform.fromUnderscoreToCamelCase(admin);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedAdmin);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedAdmin[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);
    }
  }
  public getMessages() {
    return this;
  }
}
export class MessagePermissionsModel {
  canMessageEmployees: boolean;
  canMessageParents: boolean;
  canMessageStudents: boolean;
  showFrequent: boolean;
  private transform = new TransformKeyNames();
  constructor(permission?: any) {

    // Transform all underscore keynames to camelCase
    if (permission) {
      // tslint:disable-next-line:max-line-length
      const flattenedPermission = this.transform.fromUnderscoreToCamelCase(permission);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedPermission);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedPermission[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);
    }
  }
  public getPermission() {
    return this;
  }
}
export class StudentRecipientsModel {
  frequent: RecipientListModel[];
  students: RecipientListModel[];
  teachers: RecipientListModel[];
  private transform = new TransformKeyNames();
  constructor(recipient?: any) {

    // Transform all underscore keynames to camelCase
    if (recipient) {
      // tslint:disable-next-line:max-line-length
      const flattenedRecipient = this.transform.fromUnderscoreToCamelCase(recipient);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedRecipient);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedRecipient[key];
        const temp = [];
        object.forEach(i => {
          temp.push(new RecipientListModel(i));
        });
        this[key] = temp;
        
      });
      // console.log('The Events is:', this);
    }
  }
  public getRecipient() {
    return this;
  }
}
export class RecipientListModel {
  profile: ProfileModel;
  role: string;
  username: string;
  recipientType?: string;
  private transform = new TransformKeyNames();
  constructor(recipientList?: any) {

    // Transform all underscore keynames to camelCase
    if (recipientList) {
      // tslint:disable-next-line:max-line-length
      const flattenedRecipientList = this.transform.fromUnderscoreToCamelCase(recipientList);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedRecipientList);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedRecipientList[key];
        if (key === 'profile' && object) {
          this[key] = new ProfileModel(object);
        } else this[key] = object;
      });
      // console.log('The Events is:', this);
    }
  }
  public getRecipientList() {
    return this;
  }
}
export class NewMessageStudentModel {
  admin: AdminModel[];
  messagePermissions: MessagePermissionsModel;
  recipients: StudentRecipientsModel;
  success: boolean;
  private transform = new TransformKeyNames();
  constructor(message?: any) {

    // Transform all underscore keynames to camelCase
    if (message) {
      // tslint:disable-next-line:max-line-length
      const flattenedMessages = this.transform.fromUnderscoreToCamelCase(message);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedMessages);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedMessages[key];
        if (key === 'admin' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new AdminModel(i));
          });
          this[key] = temp;
        }else if (key === 'recipients' && object) {
          this[key] = new StudentRecipientsModel(object);
        } else this[key] = object;
      });
      // console.log('The Events is:', this);
    }
  }
  public getMessages() {
    return this;
  }
}

export class NewMessageEmployeeModel {
  admin: AdminModel[];
  messagePermissions: MessagePermissionsModel;
  recipients: RecipientListModel[];
  success: boolean;
  private transform = new TransformKeyNames();
  constructor(message?: any) {

    // Transform all underscore keynames to camelCase
    if (message) {
      // tslint:disable-next-line:max-line-length
      const flattenedMessages = this.transform.fromUnderscoreToCamelCase(message);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedMessages);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedMessages[key];
        if (key === 'admin' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new AdminModel(i));
          });
          this[key] = temp;
        } else if (key === 'recipients' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new RecipientListModel(i));
          });
          this[key] = temp;
        }else this[key] = object;
      });
      // console.log('The Events is:', this);
    }
  }
  public getMessages() {
    return this;
  }
}
export class EmployeeListModel {
  fullName: string;
  employeeNumber: string;
  id: number;
  firstName: string;
  lastName: string;
  profilePhoto: string;
  recipientId: number;
  role: string;
  tagLine: string;
  private transform = new TransformKeyNames();
  constructor(employeeList?: any) {

    // Transform all underscore keynames to camelCase
    if (employeeList) {
      // tslint:disable-next-line:max-line-length
      const flattenedEmployeeList = this.transform.fromUnderscoreToCamelCase(employeeList);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedEmployeeList);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedEmployeeList[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);
    }
  }
  public getEmployeeList() {
    return this;
  }
}
export class DepartmentListModel {
  id: number;
  code: string;
  name: string;
  private transform = new TransformKeyNames();
  constructor(departmentList?: any) {

    // Transform all underscore keynames to camelCase
    if (departmentList) {
      // tslint:disable-next-line:max-line-length
      const flattenedDepartmentList = this.transform.fromUnderscoreToCamelCase(departmentList);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedDepartmentList);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedDepartmentList[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);
    }
  }
  public getDepartmentList() {
    return this;
  }
}
export class BatchListModel {
  courseId: number;
  courseName: string;
  id: number;
  startDate: string;
  endDate: string;
  fullName: string;
  name: string;
  private transform = new TransformKeyNames();
  constructor(batchList?: any) {

    // Transform all underscore keynames to camelCase
    if (batchList) {
      // tslint:disable-next-line:max-line-length
      const flattenedBatchList = this.transform.fromUnderscoreToCamelCase(batchList);
      // console.log('The flattenedEvents object is:', flattenedEvents);
      const flattendedObjectKeys = Object.keys(flattenedBatchList);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedBatchList[key];
        this[key] = object;
      });
      // console.log('The Events is:', this);
    }
  }
  public getBatchList() {
    return this;
  }
}
