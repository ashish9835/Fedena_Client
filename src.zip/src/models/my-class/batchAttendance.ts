import { TransformKeyNames } from '../transformKeyNames';
export class SubjectModel {
  averageAttendance: number;
  elective: boolean;
  subjectCode: string;
  subjectName: string;
  totalClasses: number;
  totalLeaves: number;

  private transform = new TransformKeyNames();
  constructor(attendance?: any) {

    // Transform all underscore keynames to camelCase
    if (attendance) {
      // tslint:disable-next-line:max-line-length
      const flattenedAttendance = this.transform.fromUnderscoreToCamelCase(attendance);
      // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedAttendance);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedAttendance[key];
        this[key] = object;
      });
      // console.log('The Payload is:', this);

    }
  }
  public getAnnouncementData() {
    return this;
  }
}


export class BatchAttendanceModel {
  attendanceType: string;
  startDate: string;
  endDate: string;
  totalAvgClass: number;
  totalClasses: number;
  totalLeaves: number;
  success: boolean;
  subjects: SubjectModel[];
  private transform = new TransformKeyNames();
  constructor(attendance?: any) {

    // Transform all underscore keynames to camelCase
    if (attendance) {
      // tslint:disable-next-line:max-line-length
      const flattenedAttendance = this.transform.fromUnderscoreToCamelCase(attendance);
      // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedAttendance);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedAttendance[key];
        if (key === 'subjects' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new SubjectModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
      // console.log('The Payload is:', this);

    }
  }
  public getAnnouncementData() {
    return this;
  }
}
export class BatchAttendanceListModel {
  date: string;
  dateName: string;
  totalAbsentees: number;
  private transform = new TransformKeyNames();
  constructor(attendance?: any) {

    // Transform all underscore keynames to camelCase
    if (attendance) {
      // tslint:disable-next-line:max-line-length
      const flattenedAttendance = this.transform.fromUnderscoreToCamelCase(attendance);
      // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedAttendance);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedAttendance[key];
        this[key] = object;
      });
      // console.log('The Payload is:', this);

    }
  }
  public getAnnouncementData() {
    return this;
  }
}

