import { TransformKeyNames } from '../transformKeyNames';

export class EmployeePeriodModel {
  id: number;
  name: string;

  private transform = new TransformKeyNames();
  constructor(emp?: any) {

    // Transform all underscore keynames to camelCase
    if (emp) {
      // tslint:disable-next-line:max-line-length
      const flattenedEmp = this.transform.fromUnderscoreToCamelCase(emp);
      // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedEmp);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedEmp[key];
        this[key] = object;
      });
      // console.log('The Payload is:', this);

    }
  }
  public getPeriod() {
    return this;
  }
}

export class SubjectAttendanceModel {
  id : number;
  name : string;
  noAbsentees: number;
  employees: EmployeePeriodModel[];
  private transform = new TransformKeyNames();
  constructor(subject?: any) {

    // Transform all underscore keynames to camelCase
    if (subject) {
      // tslint:disable-next-line:max-line-length
      const flattenedSubject = this.transform.fromUnderscoreToCamelCase(subject);
      // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedSubject);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedSubject[key];
        if (key === 'employees' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new EmployeePeriodModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
      // console.log('The Payload is:', this);

    }
  }
  public getSubject() {
    return this;
  }
}

export class ClassPeriodModel {
  batchFullName: string;
  classTimingId: number;
  elective: boolean;
  createdAt: string;
  updatedAt: string;
  startTime: string;
  endTime: string;
  noAbsentees?: number;
  subjectId: number;
  subjectName: string;
  subjects?: SubjectAttendanceModel[];
  employees: EmployeePeriodModel[];
  private transform = new TransformKeyNames();
  constructor(period?: any) {

    // Transform all underscore keynames to camelCase
    if (period) {
      // tslint:disable-next-line:max-line-length
      const flattenedPeriod = this.transform.fromUnderscoreToCamelCase(period);
      // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedPeriod);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedPeriod[key];
        if (key === 'employees' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new EmployeePeriodModel(i));
          });
          this[key] = temp;
        } else if (key === 'subjects' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new SubjectAttendanceModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
      // console.log('The Payload is:', this);

    }
  }
  public getPeriod() {
    return this;
  }
}
