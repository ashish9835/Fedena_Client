import { TransformKeyNames } from '../transformKeyNames';
import { PeriodModel } from '../time-table/time-table';
export class AttendanceDataModel {

  noOfStudents: number;
  percentage: number;

  private transform = new TransformKeyNames();
  constructor(attendance?: any) {

    // Transform all underscore keynames to camelCase
    if (attendance) {
      // tslint:disable-next-line:max-line-length
      const flattenedAttendance = this.transform.fromUnderscoreToCamelCase(attendance);
      // console.log('The flattenedPayload object is:', flattenedAttendance);
      const flattendedObjectKeys = Object.keys(flattenedAttendance);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedAttendance[key];
        this[key] = object;
      });
      // console.log('The Payload is:', this);

    }
  }
  public getAnnouncementData() {
    return this;
  }
}
export class TimeTableDataModel {
  total: number;
  timetable: boolean;
  periods: PeriodModel[];


  private transform = new TransformKeyNames();
  constructor(timetable?: any) {

    // Transform all underscore keynames to camelCase
    if (timetable) {
      // tslint:disable-next-line:max-line-length
      const flattenedTimetable = this.transform.fromUnderscoreToCamelCase(timetable);
      // console.log('The flattenedPayload object is:', flattenedAttendance);
      const flattendedObjectKeys = Object.keys(flattenedTimetable);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedTimetable[key];
        if (key === 'periods' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new PeriodModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
      // console.log('The Payload is:', this);

    }
  }
  public getAnnouncementData() {
    return this;
  }
}
export class EmployeeClassModel {
  id: number;
  name: string;
  fullName: string;
  canMarkAttendance: boolean;
  courseId: number;
  courseName: string;
  startDate: string;
  endDate: string;
  totalStudents: number;
  totalSubjects: number;
  tutor: boolean;
  attendanceData: AttendanceDataModel;
  timetableData: TimeTableDataModel;

  private transform = new TransformKeyNames();
  constructor(employeeClass?: any) {

    // Transform all underscore keynames to camelCase
    if (employeeClass) {
      // tslint:disable-next-line:max-line-length
      const flattenedEmployeeClass = this.transform.fromUnderscoreToCamelCase(employeeClass);
      // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedEmployeeClass);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedEmployeeClass[key];
        if (key === 'attendanceData' && object) {
          this[key] = new AttendanceDataModel(object);
        } else if (key === 'timetableData' && object) {
          this[key] = new TimeTableDataModel(object);
        } else this[key] = object;
      });
      // console.log('The Payload is:', this);

    }
  }
  public getAnnouncementData() {
    return this;
  }
}
