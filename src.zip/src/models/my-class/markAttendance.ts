import { TransformKeyNames } from '../transformKeyNames';

export class DaysModel {

  date: string;
  marked: boolean;
        
  private transform = new TransformKeyNames();
  constructor(days?: any) {

            // Transform all underscore keynames to camelCase
    if (days) {
                // tslint:disable-next-line:max-line-length
      const flattenedDays = this.transform.fromUnderscoreToCamelCase(days);
                // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedDays);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedDays[key];
        this[key] = object;
      });
                // console.log('The Payload is:', this);

    }
  }
  public getDays() {
    return this;
  }
}
export class DatesModel {
  monthYear: string;
  days: DaysModel[];
      
  private transform = new TransformKeyNames();
  constructor(dates?: any) {
    
            // Transform all underscore keynames to camelCase
    if (dates) {
                // tslint:disable-next-line:max-line-length
      const flattenedDates = this.transform.fromUnderscoreToCamelCase(dates);
                // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedDates);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedDates[key];
        if (key === 'days' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new DaysModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
                // console.log('The Payload is:', this);
    }
  }
  public getDates() {
    return this;
  }
}
  
export class MarkAttendanceModel {
  attendanceType: string;
  dates: DatesModel[];
    
  private transform = new TransformKeyNames();
  constructor(mark?: any) {
  
          // Transform all underscore keynames to camelCase
    if (mark) {
              // tslint:disable-next-line:max-line-length
      const flattenedMark = this.transform.fromUnderscoreToCamelCase(mark);
              // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedMark);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedMark[key];
        if (key === 'dates' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new DatesModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
              // console.log('The Payload is:', this);
    }
  }
  public getMark() {
    return this;
  }
}
