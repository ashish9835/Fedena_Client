import { Storage } from '@ionic/storage';
import { TransformKeyNames } from '../transformKeyNames';
export class StudentAttendanceModel {
  classTimingId: number;
  createdAt: string;
  updatedAt: string;
  startTime: string;
  endTime: string;
  monthDate: string;
  reason: string;
  studentId: number;
  subjectId: number;

  private transform = new TransformKeyNames();
  constructor(student?: any) {

        // Transform all underscore keynames to camelCase
    if (student) {
            // tslint:disable-next-line:max-line-length
      const flattenedStudent = this.transform.fromUnderscoreToCamelCase(student);
            // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedStudent);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedStudent[key];
        this[key] = object;
      });
            // console.log('The Payload is:', this);

    }
  }
  public getPeriod() {
    return this;
  }
}

export class StudentAbsenteeListModel {

  absent: boolean;
  admissionNo: string;
  rollNumber:string;
  photo: string;
  eligible?: boolean;
  studentId: number;
  studentName: string;
  reason?: string;
  attendance: StudentAttendanceModel;
  private transform = new TransformKeyNames();
  constructor(student?: any) {

        // Transform all underscore keynames to camelCase
    if (student) {
            // tslint:disable-next-line:max-line-length
      const flattenedStudent = this.transform.fromUnderscoreToCamelCase(student);
            // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedStudent);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedStudent[key];
        this[key] = object;
      });
            // console.log('The Payload is:', this);

    }
  }
  public getPeriod() {
    return this;
  }
}
export class ReportStudentAbsenteeListModel {
  batchName: string;
  courseName: string;
  date: string;
  dateName: string;
  totalAbsentees: number;
  totalStudentCount: number;
  students: StudentAbsenteeListModel[];
  success: boolean;
  
  private transform = new TransformKeyNames();
  constructor(student?: any) {

        // Transform all underscore keynames to camelCase
    if (student) {
            // tslint:disable-next-line:max-line-length
      const flattenedStudent = this.transform.fromUnderscoreToCamelCase(student);
            // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedStudent);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedStudent[key];
        if (key === 'students' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new StudentAbsenteeListModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
            // console.log('The Payload is:', this);

    }
  }
  public getPeriod() {
    return this;
  }
}
export  var studentAbsenteeListModelByName = (a:StudentAbsenteeListModel,b:StudentAbsenteeListModel)=>{
  try{ return  a.studentName.toLowerCase()>b.studentName.toLowerCase()?1:-1; }
  catch(e){ return -1; }
}
export  var studentAbsenteeListModelByRollNo = (a:StudentAbsenteeListModel,b:StudentAbsenteeListModel)=>{
  try{ return  a.rollNumber.toLowerCase()>b.rollNumber.toLowerCase()?1:-1; }
  catch(e){ return -1; }
  
}
