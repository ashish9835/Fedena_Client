import { TransformKeyNames } from '../transformKeyNames';
import { EmployeeModel } from '../time-table/time-table';

export class StudentPeriodModel {
  batchFullName: string;
  buildingName: string;
  classTimingId: number;
  classroomName: string;
  createdAt: string;
  updatedAt: string;
  currentClass: boolean;
  startTime: string;
  endTime: string;
  subjectCode: string;
  subjectName: string;
  upcomingClass: boolean;
  employeeData: EmployeeModel[];
  private transform = new TransformKeyNames();
  constructor(period?: any) {
        
                // Transform all underscore keynames to camelCase
    if (period) {
                    // tslint:disable-next-line:max-line-length
      const flattenedPeriod = this.transform.fromUnderscoreToCamelCase(period);
              // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedPeriod);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedPeriod[key];
        if (key === 'employeeData' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new EmployeeModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
                    // console.log('The Payload is:', this);
    }
  }
  public getPeriod() {
    return this;
  }
}
export class StudentTimetableModel {
  total: number;
  periods: StudentPeriodModel[];
      
  private transform = new TransformKeyNames();
  constructor(timetable?: any) {
      
              // Transform all underscore keynames to camelCase
    if (timetable) {
                  // tslint:disable-next-line:max-line-length
      const flattenedTimetable = this.transform.fromUnderscoreToCamelCase(timetable);
            // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedTimetable);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedTimetable[key];
        if (key === 'periods' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new StudentPeriodModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
                  // console.log('The Payload is:', this);
    }
  }
  public getTimetable() {
    return this;
  }
}
  
export class StudentClassModel {
  attendance: {
    percentage: number;
  };
  success: boolean;
  totalSubjects: number;
  timetables: StudentTimetableModel;
    
  private transform = new TransformKeyNames();
  constructor(studentClass?: any) {
    
            // Transform all underscore keynames to camelCase
    if (studentClass) {
                // tslint:disable-next-line:max-line-length
      const flattenedStudentClass = this.transform.fromUnderscoreToCamelCase(studentClass);
          // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedStudentClass);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedStudentClass[key];
        if (key === 'timetables' && object) {
          this[key] = new StudentTimetableModel(object);
        } else this[key] = object;
      });
                // console.log('The Payload is:', this);
    
    }
  }
  public getStudentClass() {
    return this;
  }
}
