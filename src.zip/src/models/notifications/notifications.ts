import { TransformKeyNames } from '../transformKeyNames';
export class PayloadModel {

    target: string;
    targetParam: string;
    targetValue: string;
    linkText: string;

    private transform = new TransformKeyNames();
    constructor(payload?: any) {

        // Transform all underscore keynames to camelCase
        if (payload) {
            // tslint:disable-next-line:max-line-length
            const flattenedPayload = this.transform.fromUnderscoreToCamelCase(payload);
            console.log('The flattenedPayload object is:', flattenedPayload);
            const flattendedObjectKeys = Object.keys(flattenedPayload);
            flattendedObjectKeys.forEach((key) => {
                const object = flattenedPayload[key];
                this[key] = object;
            });
            console.log('The Payload is:', this);

        }
    }
    public getAnnouncementData() {
        return this;
    }
}

export class NotificationModel {
        
    id: number;
    content: string;
    initiator: string;
    createdAt: string;
    payload: PayloadModel;



    private transform = new TransformKeyNames();
    constructor(notifications?: any) {

        // Transform all underscore keynames to camelCase
        if (notifications) {
            // tslint:disable-next-line:max-line-length
            const flattenedNotifications = this.transform.fromUnderscoreToCamelCase(notifications);
            // console.log('The flattenedNotifications object is:', flattenedNotifications);
            const flattendedObjectKeys = Object.keys(flattenedNotifications);
            flattendedObjectKeys.forEach((key) => {
                const object = flattenedNotifications[key];
                this[key] = object;
            });
            // console.log('The Notifications is:', this);

        }
    }
    public getAnnouncementData() {
        return this;
    }
}