// import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

export class AppSettingsCopy {
  public static SCHOOL_LOGO = 'assets/school/logo.png';
  public static SCHOOL_BANNER = 'assets/school/banner.jpg';
  public static SCHOOL_NAME = 'Bonefire Institute of design';
  public static SCHOOL_PLACE = 'Hyderabad India';
  public static SCHOOL_CONTACT = '012345670';
  public static SCHOOL_EMAIL = 'info@school.com';
  public static SCHOOL_WEBSITE = 'www.school.com';
  public static SCHOOL_ADDRESS = 'abcd block, 12th mail <br/> Banglore , India <br/> 12345';

  public static HEADER_LOGO = 'assets/img/header-logo.png';
  public static FEDENA_CONNECT_LOGO = 'assets/img/fedena-connect.png';

  public static GETSTARTED_TOP_IMAGE = 'assets/img/get-started.png';
  public static FEDENA_CONNECT_LOGO_ALT = 'Fedena Connect';
  public static APP_NAME = 'Fedena Connect';
  public static APP_HEADER_TITLE = 'Fedena Connect';
  public static APP_HEADER_LOGO = 'logo.png';
  public static APP_LOGO = 'logo.png';
  public static APP_VERSION = '1.0';
  public static DEVICE_TYPE = 'android';

  public static ADMIN_TOKEN = 'WbkAEqSgUABAnugxDMNg1Wnt';
  public static APP_API_URL = 'http://fconnect.t.foradian.org/';
  public static APP_PROFILE_IMAGE_URL = 'http://fconnect.t.foradian.org/';
    // public static APP_API_URL = 'http://ding.t.foradian.org/';
  public static SCHOOL_IDENTITY = 'kqqZ9BBfATy8Ju3bicgL5kCZ';
  public static SCHOOL_ATTENDANCE_TYPE = 'Daily';


  public static PRINCIPAL_PHOTO = 'assets/img/icon.png';
  public static FOUNDER_PHOTO = 'assets/img/icon.png';

    
  constructor() { }

}

