import { TransformKeyNames } from '../transformKeyNames';

export class BatchStudentListModel {

  id: number;
  admissionNo: string;
  createdAt: string;
  updatedAt: string;
  fullName: string;
  profilePhoto: string;
  studentRollNumber: string;
  batchId: number;
  courseId: number;
  firstName: string;
  lastName: string;
  recipientId:number;

  private transform = new TransformKeyNames();
  constructor(student?: any) {

    if (student) {
      // tslint:disable-next-line:max-line-length
      const flattenedStudent = this.transform.fromUnderscoreToCamelCase(student);
      // console.log('The flattenedStudentProfile object is:', flattenedStudent);
      const flattendedObjectKeys = Object.keys(flattenedStudent);
      flattendedObjectKeys.forEach((key) => {
        this[key] = flattenedStudent[key];
      });
      // console.log('The StudentProfile is:', this);

    }
  }
  public getStudentData() {
    return this;
  }
}
