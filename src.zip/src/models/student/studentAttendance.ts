import { TransformKeyNames } from '../transformKeyNames';
import { SubjectModel } from '../my-class/batchAttendance';
import { EmployeeModel } from '../time-table/time-table';

export class StudentAttendanceOverviewModel { 
      
  attendanceType: string;
  startDate: string;
  endDate: string;
  studentId: number;
  totalLeaves: number;
  totalWorkingHours: number;
  success: boolean;
  subjects: SubjectModel[];

  private transform = new TransformKeyNames();
  constructor(attendance?: any) {

    if (attendance) {
            // tslint:disable-next-line:max-line-length
      const flattenedAttendance = this.transform.fromUnderscoreToCamelCase(attendance);
      // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedAttendance);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedAttendance[key];
        if (key === 'subjects' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new SubjectModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
            // console.log('The Payload is:', this);

    }
  }
  public getAnnouncementData() {
    return this;
  }
}

export class PeriodDataModel { 
      
  subjectName: string;
  subjectCode: string;
  startTime: string;
  endTime: string;
  employeeData: EmployeeModel[];

  private transform = new TransformKeyNames();
  constructor(period?: any) {

    if (period) {
            // tslint:disable-next-line:max-line-length
      const flattenedPeriod = this.transform.fromUnderscoreToCamelCase(period);
      // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedPeriod);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedPeriod[key];
        if (key === 'employeeData' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new EmployeeModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
            // console.log('The Payload is:', this);

    }
  }
  public getPeriodData() {
    return this;
  }
}

export class StudentAttendanceLeaveModel { 
      
  date: string;
  totalLeaves: number;
  totalPeriods: number;
  periodData: PeriodDataModel[];

  private transform = new TransformKeyNames();
  constructor(attendance?: any) {

    if (attendance) {
            // tslint:disable-next-line:max-line-length
      const flattenedAttendance = this.transform.fromUnderscoreToCamelCase(attendance);
      // console.log('The flattenedPayload object is:', flattenedEmployeeClass);
      const flattendedObjectKeys = Object.keys(flattenedAttendance);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedAttendance[key];
        if (key === 'periodData' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new PeriodDataModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
            // console.log('The Payload is:', this);

    }
  }
  public getAttendanceData() {
    return this;
  }
}
