import { TransformKeyNames } from '../transformKeyNames';

export class EmployeesModel {
  id: number;
  employeeNumber: string;
  firstName: string;
  lastName: string;
  fullName: string;
  profilePhoto: string;
  private transform = new TransformKeyNames();
  constructor(employee?: any) {

        // Transform all underscore keynames to camelCase
    if (employee) {
            // tslint:disable-next-line:max-line-length
      const flattenedEmployee = this.transform.fromUnderscoreToCamelCase(employee);
            // console.log('The flattenedEmployee object is:', flattenedEmployee);
      const flattendedObjectKeys = Object.keys(flattenedEmployee);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedEmployee[key];
        this[key] = object;
      });
            // console.log('The Subject is:', this);

    }
  }
  public getSubject() {
    return this;
  }
}

export class SubjectModel {
  id: number;
  name: string;
  maxWeeklyClasses: number;
  batchId: number;
  batchName: string;   
  code: string;
  createdAt: string;
  updatedAt: string;
  electiveGroupId: number;
  electiveGroupName: string;
  employees: EmployeesModel[];

  private transform = new TransformKeyNames();
  constructor(subject?: any) {

        // Transform all underscore keynames to camelCase
    if (subject) {
            // tslint:disable-next-line:max-line-length
      const flattenedSubject = this.transform.fromUnderscoreToCamelCase(subject);
            // console.log('The flattenedSubject object is:', flattenedSubject);
      const flattendedObjectKeys = Object.keys(flattenedSubject);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedSubject[key];
        if (key === 'employees' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new EmployeesModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
            // console.log('The Subject is:', this);

    }
  }
  public getSubject() {
    return this;
  }
}
