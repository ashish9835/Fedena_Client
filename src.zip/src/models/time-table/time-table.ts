import { TransformKeyNames } from '../transformKeyNames';

export class EmployeeModel {
  employeeId: number;
  employeeName: string;

  private transform = new TransformKeyNames();
  constructor(employee?: any) {

    // Transform all underscore keynames to camelCase
    if (employee) {
      // tslint:disable-next-line:max-line-length
      const flattenedEmployee = this.transform.fromUnderscoreToCamelCase(employee);
      // console.log('The flattenedEmployee object is:', flattenedEmployee);
      const flattendedObjectKeys = Object.keys(flattenedEmployee);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedEmployee[key];
        this[key] = object;
      });
      // console.log('The Employee is:', this);

    }
  }
  public getEmployee() {
    return this;
  }
}

export class PeriodModel {
  name?: string;
  batchFullName: string;
  buildingName?: string;
  classTimingId: number;
  classroomName?: string;
  currentClass?: boolean;
  upcomingClass?: boolean;
  createdAt: string;
  updatedAt: string;
  duration?: string;
  startTime: string;
  elective?: boolean;
  endTime: string;
  isBreak?: boolean;
  subjectCode?: string;
  subjectName: string;
  teacherName?: string;
  employeeData?: EmployeeModel[];

  private transform = new TransformKeyNames();
  constructor(period?: any) {

    // Transform all underscore keynames to camelCase
    if (period) {
      // tslint:disable-next-line:max-line-length
      const flattenedPeriod = this.transform.fromUnderscoreToCamelCase(period);
      // console.log('The flattenedPeriod object is:', flattenedPeriod);
      const flattendedObjectKeys = Object.keys(flattenedPeriod);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedPeriod[key];
        if (key === 'employeeData' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new EmployeeModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
      // console.log('The Period is:', this);

    }
  }
  public getPeriod() {
    return this;
  }
}

export class TimetableModel {
  day: string;
  periods: PeriodModel[];

  private transform = new TransformKeyNames();
  constructor(timeTable?: any) {

    // Transform all underscore keynames to camelCase
    if (timeTable) {
      // tslint:disable-next-line:max-line-length
      const flattenedTimeTable = this.transform.fromUnderscoreToCamelCase(timeTable);
      // console.log('The flattenedTimeTable object is:', flattenedTimeTable);
      const flattendedObjectKeys = Object.keys(flattenedTimeTable);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedTimeTable[key];
        if (key === 'periods' && object) {
          let temp = [];
          object.forEach(i => {
            temp.push(new PeriodModel(i));
          });
          temp = temp.sort(function (a, b) {
            console.log(a.startTime)
            return (Date.parse('1970/01/01 ' + a.startTime)) - (Date.parse('1970/01/01 ' + b.startTime));
          });
          this[key] = temp;
        } else this[key] = object;
      });
      // console.log('The Timetable is:', this);

    }
  }
  public getTimetable() {
    return this;
  }
}
