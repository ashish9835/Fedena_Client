import { TransformKeyNames } from '../transformKeyNames';
export class StaticPageModel {
  content: string;
  id: number;
  photoUrl: string;
  title: string;

  private transform = new TransformKeyNames();
  constructor(schoolDetail?: any) {
  
          // Transform all underscore keynames to camelCase
    if (schoolDetail) {
              // tslint:disable-next-line:max-line-length
      const flattenedSchoolDetail = this.transform.fromUnderscoreToCamelCase(schoolDetail);
       
      const flattendedObjectKeys = Object.keys(flattenedSchoolDetail);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedSchoolDetail[key];
        this[key] = object;
      });
        
  
    }
  }
  public getSchoolDetail() {
    return this;
  }
}
