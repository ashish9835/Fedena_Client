import { TransformKeyNames } from '../transformKeyNames';
export class SchoolDetailModel {
  currencyType: string;
  locale: string;
  schoolAddress: string;
  schoolContactNo: string;
  schoolEmail: string;
  schoolName: string;
  schoolWebsite: string;

  private transform = new TransformKeyNames();
  constructor(schoolDetail?: any) {
  
          // Transform all underscore keynames to camelCase
    if (schoolDetail) {
              // tslint:disable-next-line:max-line-length
      const flattenedSchoolDetail = this.transform.fromUnderscoreToCamelCase(schoolDetail);
       
      const flattendedObjectKeys = Object.keys(flattenedSchoolDetail);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedSchoolDetail[key];
        this[key] = object;
      });
        
  
    }
  }
  public getSchoolDetail() {
    return this;
  }
}
export class ContactDetailModel {
  contactEmail: string;
  contactName: string;
  contactNumber: string;
  
  private transform = new TransformKeyNames();
  constructor(contactDetail?: any) {
    
            // Transform all underscore keynames to camelCase
    if (contactDetail) {
                // tslint:disable-next-line:max-line-length
      const flattenedContactDetail = this.transform.fromUnderscoreToCamelCase(contactDetail);
         
      const flattendedObjectKeys = Object.keys(flattenedContactDetail);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedContactDetail[key];
        this[key] = object;
      });
          
    
    }
  }
  public getContactDetail() {
    return this;
  }
}
export class ConnectAppPagesModel {
  id: number;
  title: string;
  photoUrlThumb: string;
    
  private transform = new TransformKeyNames();
  constructor(connectApp?: any) {
      
              // Transform all underscore keynames to camelCase
    if (connectApp) {
                  // tslint:disable-next-line:max-line-length
      const flattenedConnectApp = this.transform.fromUnderscoreToCamelCase(connectApp);
           
      const flattendedObjectKeys = Object.keys(flattenedConnectApp);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedConnectApp[key];
        this[key] = object;
      });
            
      
    }
  }
  public getConnectApp() {
    return this;
  }
}  

export class TutorialModel {
  success: boolean;
  schoolDetails: SchoolDetailModel;
  contactDetails: ContactDetailModel;
  connectAppPages: ConnectAppPagesModel[];

  private transform = new TransformKeyNames();
  constructor(tutorial?: any) {

        // Transform all underscore keynames to camelCase
    if (tutorial) {
            // tslint:disable-next-line:max-line-length
      const flattenedTutorial = this.transform.fromUnderscoreToCamelCase(tutorial);
     
      const flattendedObjectKeys = Object.keys(flattenedTutorial);
      flattendedObjectKeys.forEach((key) => {
        const object = flattenedTutorial[key];
        if (key === 'connectAppPages' && object) {
          const temp = [];
          object.forEach(i => {
            temp.push(new ConnectAppPagesModel(i));
          });
          this[key] = temp;
        } else this[key] = object;
      });
      

    }
  }
  public getTutorial() {
    return this;
  }
}
