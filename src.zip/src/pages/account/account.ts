import { Component, OnInit } from '@angular/core';
import { ActionSheetController, NavController, Platform } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { EmployeeAccountModel } from 'src/models/employeeLeaves/account';
import { Profile } from 'src/providers/profile';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';
import { Router } from '@angular/router';

@Component({
  selector: 'page-account',
  templateUrl: 'account.html',
  styleUrls: ['account.scss']
})
export class AccountPage implements OnInit {
  userData = [];
  employee = false;
  account: any;

  name = '';
  profileTitle = '';
  profileSubTitle = '';
  token = '';
  leavesTaken = '';
  attendance: number;
  leavesLeft = '';
  canApply = false;
  profilePhoto = '';

  constructor(
    private translate: TranslateService,
    public event: EventsService,
    public actionSheetCtrl: ActionSheetController,
    public profileService: Profile,
    private userService: User,
    public platform: Platform,
    public commonService: CommonService,
    public router: Router,
    public navCtrl: NavController
  ) {
    this.init();
    this.event.subscribe('accounts_reload', (data) => {
      this.init();
    });
  }
  private init() {
    this.commonService.presentLoading('Loading profile')
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getRole().then((role) => {
          this.userService.getUser().then((value) => {
            this.commonService.dismissloading();
            this.name = value.fullName;
            if (role === 'employee') {
              this.profileTitle = 'Employee ';
              this.profileSubTitle = value.employeePositionName;
              this.employee = true;
              this.getEmployeeOverview();
            } else {
              this.profileTitle = 'Student';
              this.profileSubTitle = value.batchCourseName;
              this.employee = false;
            }
            if (value.profilePhoto !== '') {
              this.profilePhoto = value.profilePhoto;
            }
          });
        });
      }
    });
  }
  ngOnInit(){
    
  }
  async presentActionSheet() {
    let btnHalfDay = 'Half day';
    let btnFullDay = 'Full day';
    let btnMultipleDays = 'Multiple days';
    let titleTxt = 'Select leave type'
    this.translate.get('button.half_day').subscribe(val => btnHalfDay = val);
    this.translate.get('button.full_day').subscribe(val => btnFullDay = val);
    this.translate.get('button.multiple_days').subscribe(val => btnMultipleDays = val);
    this.translate.get('my_leave.action_sheet_title').subscribe(val => titleTxt = val);
    const actionSheet = await this.actionSheetCtrl.create({
      header: titleTxt,
      buttons: [
        {
          text: btnHalfDay,
          handler: () => {
            this.applyLeaves('half');
            console.log('Selected half day');
          },
        },
        {
          text: btnFullDay,
          handler: () => {
            this.applyLeaves('full');
            console.log('Selected full day');
          },
        },
        {
          text: btnMultipleDays,
          handler: () => {
            this.applyLeaves('multiple');
            console.log('Selected multiple days');
          },
        },
      ],
    });
    this.event.subscribe('dismiss:overlay', () => {
      console.log("this is it")
      actionSheet.dismiss();
    })
    await actionSheet.present();
  }
  ionViewDidLeave() {
    this.event.publish('dismiss:overlay', {})
  }
  getEmployeeOverview() {
    this.profileService.loadEmployeeOverview(this.token).subscribe(
      (response: any) => {
        console.log(response);
        if (response.success === true) {
          this.account = new EmployeeAccountModel(response.employee_leave);
          console.log(this.account);
          this.leavesTaken = this.account.leaveDetails.leavesTaken;
          this.attendance = this.account.leaveDetails.attendance;
          if (!this.attendance) this.attendance = 100;
          this.leavesLeft = this.account.leaveDetails.leavesLeft;
          this.canApply = this.account.leaveDetails.canApply;
          this.name = this.account.fullName;
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  applyLeaves(type) {
    this.router.navigateByUrl('/apply-leave/' + type);
  }
  openFeedbackPage() {
    // this.nav.push(FeedbackPage);
  }
  openMyProfilePage() {
    this.router.navigateByUrl('/my-profile');
  }
  openRateUs() {
    // this.nav.push(MyProfilePage);
  }
  openMyLeave() {
    this.router.navigateByUrl('/my-leave');
  }
  openApplyLeave() {
    this.router.navigateByUrl('/apply-leave');
  }
  loadPage() {
    this.init();
  }
}
