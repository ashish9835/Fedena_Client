import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { AlbumsPage } from './albums';
import { AlbumsPageRoutingModule } from './albums-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AlbumsPageRoutingModule,
    PipesModule
  ],
  declarations: [AlbumsPage]
})
export class AlbumsPageModule { }
