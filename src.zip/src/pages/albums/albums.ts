import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { NavController } from '@ionic/angular';
import { AppSettings } from 'src/models/app-settings';
import { AlbumModel, PhotosModel } from 'src/models/gallery/album';
import { CommonService } from 'src/providers/common/common.service';
import { Gallery } from 'src/providers/gallery';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-albums',
  templateUrl: 'albums.html',
  styleUrls: ['albums.scss']
})
export class AlbumsPage implements OnInit {
  statusbarColour = AppSettings.COLOUR_STATUS_BAR;
  images = [];
  albumId = '';
  albumTitle = '';
  totalImages = '';
  albumData: any;
  page: number = 1;
  token = '';
  constructor(public navCtrl: NavController,
    private statusBar: StatusBar,
    private user: User,
    private galleryService: Gallery,
    private userService: User,
    private commonService: CommonService,
    private route: ActivatedRoute,
    private router: Router) {
    this.albumId = this.route.snapshot.params.id;
    console.log(this.albumId);
    this.commonService.presentLoading('Loading Album');
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.loadPhotos();
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  ngOnInit() { }
  openPhoto(index) {
    this.router.navigateByUrl('/lightbox-image', { state: { 'photo_index': index, 'images': this.images } });
  }
  ionViewDidEnter() {
    this.statusBar.overlaysWebView(false);
    this.statusBar.styleLightContent();
    console.log(this.statusbarColour);
    this.statusBar.backgroundColorByHexString(this.statusbarColour);
  }

  onload(index: number) {
    this.images[index].isLoaded = true;
  }
  loadPhotos() {
    this.galleryService.loadPhotos(this.token, this.albumId, this.page).subscribe(
      (response: any) => {
        console.log(response);
        this.albumData = new AlbumModel(response);
        this.images = this.albumData.photos.map((i: any) => {
          i.isLoaded = false;
          return i;
        });
        console.log(this.albumData);
        this.commonService.dismissloading();
        this.albumTitle = this.albumData.albumName;
        this.totalImages = this.albumData.totalImages;
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err);
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  doInfinite(infiniteScroll) {
    console.log('Loading messages');
    setTimeout(() => {
      // tslint:disable-next-line:no-increment-decrement
      this.page++;
      this.galleryService.loadPhotos(this.token, this.albumId, this.page).subscribe(
        (response: any) => {
          console.log(response.photos);
          this.commonService.dismissloading();
          response.photos.forEach((i) => {
            this.images.push(new PhotosModel(i));
          });
          console.log(this.images);
          infiniteScroll.complete();
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.user.errorHandler();
          }
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        },
      );
    }, 500);
  }
}
