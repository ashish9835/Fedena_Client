import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { AnnouncementsDetailsPage } from './announcements-details';
import { AnnouncementsDetailsPageRoutingModule } from './announcements-details-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        AnnouncementsDetailsPageRoutingModule
    ],
    declarations: [AnnouncementsDetailsPage]
})

export class AnnouncementsDetailsPageModule { }
