import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { NavController, Platform } from '@ionic/angular';
import { AnnouncementModel } from 'src/models/Announcements/announcementModel';
import { CommonService } from 'src/providers/common/common.service';
import { DownloadOptions, DownloadProvider } from 'src/providers/downloader';
import { Announcements } from 'src/providers/announcements';
import { User } from 'src/providers/user';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-announcements-details',
  templateUrl: 'announcements-details.html',
  styleUrls: ['announcements-details.scss']
})

export class AnnouncementsDetailsPage implements OnInit {
  @ViewChild('content') content;
  news: any = {};
  comment: string;
  newsId = 0;
  total = 0;
  token = '';
  test: number;
  userId: number;
  storageDirectory: string;
  showComments: boolean = true;
  constructor(

    private downloader: DownloadProvider,
    private user: User,
    private iab: InAppBrowser,
    private emailComposer: EmailComposer,
    private callNumber: CallNumber,
    private keyboard: Keyboard,
    private storage: Storage,
    public navCtrl: NavController,
    public platform: Platform,
    private announcementsService: Announcements,
    private router: Router,
    private commonService: CommonService
  ) {
    // this.news = navParams.get('news');
    let data = this.router.getCurrentNavigation().extras.state;
    this.newsId = data.newsId;
    this.token = data.token;
    this.news = data.news;
    this.getuser();
    this.loadAnnouncement();
    this.setAsRead();
    platform.ready().then(() => {
      if (this.platform.is('ios')) {
        keyboard.disableScroll(false);

        keyboard.onKeyboardHide().subscribe(() => {
          // keyboard.disableScroll(false);
        });
      }
    });
  }
  ngOnInit() {

  }
  getuser() {
    this.user.getMasterUserId().then((id) => {
      if (id) {
        this.userId = id;
      }
    });
  }
  scrollTo() {

    const dimensions = this.content.getContentDimensions();
    this.content.scrollTo(0, dimensions.scrollHeight + 300, 200);


  }

  setAsRead() {
    this.storage.get('announcements_read').then((readIds) => {
      console.log('Announcements read ', readIds);
      if (readIds == null) {
        // tslint:disable-next-line:no-parameter-reassignment
        readIds = [];
      }
      if (readIds.indexOf(this.userId + 'r' + this.newsId) === -1) {
        readIds.push(this.userId + 'r' + this.newsId);
      }
      this.storage.set('announcements_read', readIds);
    });
  }
  loadAnnouncement() {
    this.announcementsService.loadAnnouncementDetails(
      this.token,
      this.newsId,
    ).subscribe(
      (response: any) => {
        console.log(response);
        if (response.success === true) {
          this.news = new AnnouncementModel(response.news);
          console.log(this.news);
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      },
    );
  }
  postComment() {
    this.announcementsService.addComment(this.token, this.newsId, this.comment)
      .subscribe(
        (response) => {
          const apiResponse: any = response;
          console.log(response);
          if (apiResponse.success === true) {
            console.log('Comment posted');
            this.comment = '';
            this.loadAnnouncement();

          }
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.user.errorHandler();
          }
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true })
          }
        },
      );
  }
  ionViewWillLeave() {
  }
  ionViewDidLeave() {

  }



  deleteComment(id) {
    console.log(id);

    this.announcementsService.deleteComment(this.token, this.newsId, id).subscribe(
      (response) => {
        this.commonService.dismissloading();
        const apiResponse: any = response;
        if (apiResponse.success) {
          console.log('Deleted');

        }
        console.log(response);
        this.loadAnnouncement();
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      },
    );
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AnnouncementsDetails');
    if (this.platform.is('ios')) {
      this.keyboard.disableScroll(false);
    }

  }
  ionViewCanLeave() {
    if (this.platform.is('ios')) {
      this.keyboard.disableScroll(false);
    }
  }

  //this function downloads file from an url 
  download(url, type, name) {

    let options: DownloadOptions = new DownloadOptions();
    options.fileName = name;
    options.mimeType = type;
    options.url = url;
    if (this.platform.is('ios')) this.commonService.presentLoading('Downloading attachment');
    if (this.platform.is('android')) this.commonService.presentToast('toast.downloading', 3000);
    this.downloader.download(options).then(destn => {
      console.log("downloaded")
      if (this.platform.is('ios')) this.commonService.dismissloading();
    }).catch(e => {
      if (this.platform.is('ios')) {
        this.commonService.dismissloading();
        this.commonService.presentToast(e, 3000)
      }
    });
  }


  handleClick(event) {
    const theTargetIs = event.target.getAttribute('target-data');
    if (theTargetIs === 'webulr') {
      // tslint:disable-next-line:max-line-length
      this.iab.create(event.target.href, '_blank', 'location=no,toolbar=yes,fullscreen=no,closebuttoncaption=CLOSE');
      return false;
    }
    if (theTargetIs === 'call') {
      const str = event.target.href;
      const index = str.lastIndexOf('/');
      const mobile = str.substring(index + 1);
      console.log(mobile);
      this.callNumber.callNumber(mobile, true)
        .then(() => console.log('Launched dialer!'))
        .catch(() => console.log('Error launching dialer'));
      return false;
    }
    if (theTargetIs === 'mailopen') {

      this.emailComposer.isAvailable().then((available: boolean) => {
        if (available) {
          // Now we know we can send mail
        }
      });
      const str = event.target.href;
      const index = str.lastIndexOf('/');
      const emailid = str.substring(index + 1);
      console.log(emailid);

      const email = {
        to: emailid,
        subject: ' ',
        body: ' ',
        isHtml: true,
      };
      this.emailComposer.open(email);
      return false;

    }
  }
}

