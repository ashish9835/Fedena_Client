import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { NavController, Platform } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { AnnouncementModel } from 'src/models/Announcements/announcementModel';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Announcements, User } from 'src/providers/providers';

@Component({
  selector: 'page-announcements',
  templateUrl: 'announcements.html',
  styleUrls: ['announcements.scss']
})
export class AnnouncementsPage implements OnInit {
  news: AnnouncementModel;
  announcements = [];
  readIds = [];
  token = '';
  page: number = 1;
  userId: number;

  constructor(
    public platform: Platform,
    private event: EventsService,
    private keyboard: Keyboard,
    private storage: Storage,
    public navCtrl: NavController,
    private announcementsService: Announcements,
    private user: User,
    public commonService: CommonService,
    public router: Router
  ) {
    console.log("this is nav controller")
    console.log(this.announcements);
    this.commonService.presentLoading('Loading Announcements')
    this.getuser();
    this.user.getAccessToken().then((value) => {
      console.log(value);
      if (value) {
        this.token = value;
        announcementsService.loadAnnouncements(value).subscribe(
          (response) => {
            console.log(response);
            const apiResponse: any = response;
            this.commonService.dismissloading();
            if (apiResponse.success === true && apiResponse.news) {

              apiResponse.news.forEach(i => {
                this.announcements.push(new AnnouncementModel(i));
              });
              console.log(this.announcements);

              this.getReadIds();
            }
          },
          (err) => {
            this.commonService.dismissloading();
            console.log(err.status);
            if (err.status === 500) {
              this.user.errorHandler();
            }
            if (err.status === 403) {
              this.navCtrl.setDirection('root');
              this.router.navigateByUrl('/tutorial', { replaceUrl: true })
            }
          },
        );
      } else {
        this.commonService.presentAlert('Session expired')
      }
    });
  }
  ngOnInit(){
    
  }
  getuser() {
    this.user.getMasterUserId().then((id) => {
      if (id) {
        this.userId = id;
      }
    });
  }
  getReadIds() {
    this.storage.get('announcements_read').then((readIds) => {
      if (readIds == null) this.readIds = [];
      else this.readIds = readIds;
      console.log(this.readIds);
    });
  }

  openDetails(news) {
    if (this.readIds == null) this.readIds = [];
    this.readIds.push(this.userId + 'r' + news.id);
    this.router.navigateByUrl('/announcements-details', { state: { news, newsId: news.id, token: this.token } })
  }
  goback() {
    this.router.navigateByUrl('/tabs', { replaceUrl: true })
  }
  ionViewWillEnter() {
    if (this.platform.is('ios')) {
      this.keyboard.disableScroll(false);
    }
  }
  strip(html: string) {
    // html.substring(0,145);
    return html.replace(/<[^>]+>/ig, '').substring(0, 145);


  }
  img2nl(html: string) {
    return html.replace(/<img( \/|\/|)>/gm, '\r\n');
  }
  doInfinite(infiniteScroll) {
    console.log('Loading messages');
    setTimeout(() => {
      // tslint:disable-next-line:no-increment-decrement
      this.page++;
      this.announcementsService.loadAnnouncements(this.token, this.page).subscribe(
        (response) => {
          const apiResponse: any = response;
          this.commonService.dismissloading();
          apiResponse.news.forEach(i => {
            this.announcements.push(new AnnouncementModel(i));
          });
          // this.announcements = this.announcements.concat(apiResponse.news);
          console.log(apiResponse);
          console.log(this.announcements);
          infiniteScroll.target.complete();
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.user.errorHandler();
          }
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true })
          }
        },
      );
    }, 500);
  }

}
