import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssignmentCreatePage } from './assignment-create';


const routes: Routes = [
  {
    path: '',
    component: AssignmentCreatePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AssignmentCreatePageRoutingModule { }
