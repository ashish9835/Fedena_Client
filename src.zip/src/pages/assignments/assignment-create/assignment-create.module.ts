import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { ComponentsModule } from 'src/components/components.module';
import { DirectivesModule } from 'src/directives/directives.module';
import { AssignmentCreatePage } from './assignment-create';
import { AssignmentCreatePageRoutingModule } from './assignment-create-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssignmentCreatePageRoutingModule,
    PipesModule,
    ComponentsModule,
    DirectivesModule,
    ReactiveFormsModule
  ],
  declarations: [AssignmentCreatePage]
})
export class AssignmentCreatePageModule { }
