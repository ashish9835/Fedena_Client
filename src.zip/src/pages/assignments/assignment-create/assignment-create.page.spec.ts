import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { AssignmentCreatePage } from './assignment-create';

describe('AssignmentCreatePage', () => {
  let component: AssignmentCreatePage;
  let fixture: ComponentFixture<AssignmentCreatePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AssignmentCreatePage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AssignmentCreatePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
