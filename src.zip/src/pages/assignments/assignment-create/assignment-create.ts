import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ModalController, NavController } from '@ionic/angular';
import { AssignmentProvider } from 'src/providers/assignment/assignment';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { FileProvider } from 'src/providers/file';
import { UploadProvider } from 'src/providers/uploader';
import { AttendeesSelectionComponent } from '../attendees-selection/attendees-selection';

/**
 * Generated class for the AssignmentCreatePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-assignment-create',
  templateUrl: 'assignment-create.html',
  styleUrls: ['assignment-create.scss']
})
export class AssignmentCreatePage implements OnInit {
  totalCompleted: number = 0;
  // totalAttachmentUploadProgress:number = 0;
  files: any[] = [];
  formSchema: any;
  isLoading: boolean = true;
  assignmentForm: FormGroup
  subject: any;
  isEditMode: boolean = true;
  editConfigs: any;
  chooserConfigs: { allowedSize: number; allowedTypes: String[]; };
  maxAttachments: number;
  today: string = (new Date()).toISOString().split('T')[0];

  constructor(
    public events: EventsService,
    private modalCtrl: ModalController,
    public uploadProvider: UploadProvider,
    public fileProvider: FileProvider,
    public formBuilder: FormBuilder, public navCtrl: NavController,
    public assignmentProvider: AssignmentProvider,
    public commonService: CommonService,
    public router: Router,
    // public nav: IonNav
    ) {
    console.log((new Date()).toISOString().split('T')[0])
    this.subject = this.router.getCurrentNavigation().extras.state.subject;
    this.isEditMode = this.router.getCurrentNavigation().extras.state.enableEditMode || false;
    this.assignmentForm = this.formBuilder.group({});
    this.commonService.presentLoading('loading');
    if (this.isEditMode) {
      this.assignmentProvider.getEditConfigs(this.router.getCurrentNavigation().extras.state.assignmentId).subscribe(
        config => {
          this.editConfigs = config;
          this.subject = config.subject;
          this.formSchema = config.schema;
          this.isLoading = false;
          this.createFormUsingSchema().then((form: FormGroup) => {
            this.commonService.dismissloading();
            form.setValue(this.editConfigs.assignmentData)
            console.log(this.editConfigs.subject)
          })
        }
      )

    } else
      this.assignmentProvider.getSchema(this.subject.id).subscribe(schema => {
        console.log(schema)
        this.formSchema = schema;
        this.isLoading = false;
        this.createFormUsingSchema().then((form: FormGroup) => {
          this.commonService.dismissloading();
        }
        );
      })
  }
  ngOnInit() {

  }
  get title() {
    return this.assignmentForm.get('title');
  }
  get content() {
    return this.assignmentForm.get('content');
  }
  get duedate() {
    return this.assignmentForm.get('duedate');
  }
  get attachments() {
    return this.assignmentForm.get('attachments') as FormArray;
  }
  get student_ids() {
    return this.assignmentForm.get('student_ids') as FormArray;
  }
  createFormUsingSchema() {
    return new Promise((resolve, reject) => {
      for (let key in this.formSchema) {
        console.log(this.formSchema[key])
        let validators: ValidatorFn[] = [];
        let default_value: any;
        for (let key1 in this.formSchema[key]) {
          if (!this.formSchema[key].optional) validators.push(Validators.required);
          if (key1 === 'type' && this.formSchema[key][key1] === "integer") {
            if (key === "subject_id") {
              default_value = this.subject.id;
              continue;
            }
            validators.push(Validators.min(this.formSchema[key]['min']))
            validators.push(Validators.max(this.formSchema[key]['max']))
            default_value = 0;
          }
          if (key1 === 'type' && this.formSchema[key][key1] === "text") {
            validators.push(whitespaveValidator());
            validators.push(Validators.minLength(this.formSchema[key]['min']))
            validators.push(Validators.maxLength(this.formSchema[key]['max']))
            default_value = "";
          }
          if (key1 === 'type' && this.formSchema[key][key1] === "array") {
            if (key === 'attachments') {
              this.maxAttachments = this.formSchema[key].count;
              this.chooserConfigs = {
                allowedTypes: this.formSchema[key].items.attachment.mime_types,
                allowedSize: this.formSchema[key].items.attachment.max
              }
              if (this.isEditMode && this.formSchema[key] && this.editConfigs.assignmentData.attachments) {
                this.files = this.editConfigs.assignmentData.attachments.map(val => {
                  return {
                    id: val.attachment.id,
                    name: val.attachment.attachment_name,
                    uploadComplete: true
                  }
                })
                this.totalCompleted = this.files.length;
              }
              this.assignmentForm.addControl(key, this.formBuilder.array([], Validators.maxLength(this.formSchema[key].count)));
            } else
              this.assignmentForm.addControl(key, this.formBuilder.array([], Validators.required));

            if (this.isEditMode && this.editConfigs.assignmentData[key]) {
              for (let i = 0; i < this.editConfigs.assignmentData[key].length; i++) {
                (this.assignmentForm.get(key) as FormArray).push(
                  this.formBuilder.control(null)
                )
              }
            }
            continue;
          }


        }

        this.assignmentForm.addControl(key, this.formBuilder.control(default_value, validators));

      }
      this.assignmentForm.valueChanges.subscribe((val) => {

      })
      resolve(this.assignmentForm);

    })
  }
  createAssignment() {
    console.log(this.assignmentForm)
    this.markFormGroupTouched(this.assignmentForm)
    if (this.assignmentForm.status !== 'INVALID') {
      this.commonService.presentLoading('loading');
      this.assignmentProvider.createAssignment(this.assignmentForm.value)
        .subscribe((res: any) => {
          this.commonService.dismissloading();
          if (res.sucess) {
            this.router.navigateByUrl('/assignment-details', { state: { 'assignmentId': res.assignment.id } });
          }
        });
    }

  }
  updateAssignment() {
    this.markFormGroupTouched(this.assignmentForm)
    console.log(this.assignmentForm)
    if (this.assignmentForm.status !== 'INVALID') {
      this.commonService.presentLoading('loading');
      this.assignmentProvider.updateAssignment(this.editConfigs.assignmentId, this.assignmentForm.value)
        .subscribe((res: any) => {
          if (res.sucess) {
            this.commonService.dismissloading();
            this.router.navigateByUrl('/assignment-details', { state: { 'assignmentId': res.assignment.id }, replaceUrl: true });
          }
        });
    }
  }
  async openAttendeeSelectionPage() {
    let modal = await this.modalCtrl.create(
      {
        component: AttendeesSelectionComponent,
        componentProps: {
          selectedAttendees: this.student_ids.value,
          subject: this.subject
        }
      });
    modal.present();
    modal.onDidDismiss().then((selectedAttendees: any) => {
      if (selectedAttendees) {
        this.assignmentForm.removeControl('student_ids');
        this.assignmentForm.addControl('student_ids', this.formBuilder.array([], Validators.required));
        selectedAttendees.data.forEach((val) => {
          this.student_ids.push(this.formBuilder.control(val))
        })
      }
      this.student_ids.markAsTouched();
    })
  }
  openFileChooser() {

    this.fileProvider.chooseFile(this.chooserConfigs).then((fileInfo: any) => {
      console.log(fileInfo);
      if (this.files.length !== 0) {
        this.files.shift();
        this.totalCompleted = this.totalCompleted - 1;
      }
      this.files.push(fileInfo)
      console.log(this.attachments.validator)
      this.uploadAttachment(fileInfo);
    }).catch(err => {
      console.log(err);
      if (err === FileProvider.FILE_IS_TOO_LARGE) this.commonService.presentToast('errors.file_size', 2000);
      if (err === FileProvider.UNSUPPORTED_FILE) this.commonService.presentToast('errors.unsupported_file', 2000);
      if (err === FileProvider.ERROR) this.commonService.presentToast('errors.error', 2000);
      // pressed back button without selecting a file.
    });


  }
  removeAttachment(file) {
    console.log(file)
    if (file.uploadComplete) {
      this.totalCompleted--;
    }
    this.files = this.files.filter(item => {
      if (item.id !== file.id) return true;
    })
    let attcmnts = this.attachments.value;
    this.assignmentForm.removeControl('attachments')
    this.assignmentForm.addControl('attachments', this.formBuilder.array([], attachmentsLengthValidator(this.maxAttachments)))
    attcmnts.forEach(item => {
      if (item && item.attachment.id !== file.id)
        this.attachments.push(this.formBuilder.control(item, attachmentValidator()))
      else if (item && item.isPreviousAttachment) {
        if (this.files.length === 0) {
          item._destroy = true;
          this.attachments.push(this.formBuilder.control(item, attachmentValidator()))
        }
      }
    });
  }
  uploadAttachment(fileInfo: any) {

    this.uploadProvider.upload2(fileInfo).then(status => {
      if (status === "completed" && this.files.find(function (val) { return val.id === fileInfo.id })) {
        this.totalCompleted++;
        this.attachments.removeAt(0);
        this.attachments.push(this.formBuilder.control({
          attachment: {
            id: fileInfo.id,
            attachment_name: fileInfo.name,
            attachment_type: fileInfo.type,
            attachment_size: fileInfo.size,
            attachment_path: decodeURIComponent(fileInfo.path.split('.com/')[1]).replace(/%2F/g, (math) => {
              return "/"
            })
          }
        }, attachmentValidator()))
        console.log("progesse totale.");
        // console.log(this.calculateTotalProgress())
      }
    }).catch(err => {

      if (err === "abort") {
        console.log("do not worry.")
      }

    });;
  }
  get totalAttachmentUploadProgress() {
    let progress = ((this.files.length === 0 ? 1 : this.totalCompleted) / (this.files.length || 1)) * 100;
    return progress;
  }
  /**
   * Marks all controls in a form group as touched
   * @param formGroup - The form group to touch
   */
  private markFormGroupTouched(formGroup: FormGroup) {
    (<any>Object).keys(formGroup.controls).map(key => formGroup.controls[key]).forEach(control => {
      control.markAsTouched();

      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }
  goback() {
    this.navCtrl.back();
  }
}
interface Attachment {
  attachment_name: string;
  attachment_type: string;
  attachment_size: number;
  attachment_path: string;
}
function attachmentValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    let error: boolean = false;
    // if((control.value.attachment as Attachment).attachment_size > 770)error = true;
    return error ? { 'size error': { value: control.value } } : null;
  };
}
function whitespaveValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
  };
}
function attachmentsLengthValidator(maxAttachments): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    let count = 0;
    control.value.forEach(item => {
      if (!item._destroy) count++
    });
    return count <= maxAttachments ? null : { 'maxLength': 'reached max length' };
  };
}

