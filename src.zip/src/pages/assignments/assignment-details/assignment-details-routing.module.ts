import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssignmentDetailsPage } from './assignment-details';


const routes: Routes = [
  {
    path: '',
    component: AssignmentDetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AssignmentDetailsPageRoutingModule { }
