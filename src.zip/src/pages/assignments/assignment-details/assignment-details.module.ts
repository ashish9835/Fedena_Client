import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { AssignmentDetailsPage } from './assignment-details';
import { AssignmentDetailsPageRoutingModule } from './assignment-details-routing.module';
import { AssignmentsPageModule } from '../assignments.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssignmentDetailsPageRoutingModule,
    PipesModule,
    AssignmentsPageModule
  ],
  declarations: [AssignmentDetailsPage],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AssignmentDetailsPageModule { }
