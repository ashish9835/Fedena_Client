import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, NavController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { map } from 'rxjs/operators';
import { AssignmentProvider } from 'src/providers/assignment/assignment';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

/**
 * Generated class for the AssignmentDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-assignment-details',
  templateUrl: 'assignment-details.html',
  styleUrls: ['assignment-details.scss']
})
export class AssignmentDetailsPage {
  assignmentId: number;
  role: string = "employee";
  tab: string = 'overview';
  ALERT_TITLE = "Are you sure ?";
  ALERT_SUBTITLE = "This will delete the assignment permanently.";
  ALERT_BTN_OK = "OK";
  ALERT_BTN_CANCEL = "CANCEL";

  constructor(
    public events: EventsService,
    public navCtrl: NavController,
    public user: User,
    public assignmentProvider: AssignmentProvider,
    public aletCtrl: AlertController,
    private translation: TranslateService,
    private router: Router,
    private commonService: CommonService
  ) {
    this.initTranslation()
    this.user.getRole().then(role => this.role = role);
    this.tab = this.router.getCurrentNavigation().extras.state.tab || 'overview';
    this.assignmentId = this.router.getCurrentNavigation().extras.state.assignmentId;
    console.log(this.assignmentId, 'this.assignmentId');
    this.showLoading();

  }
  async initTranslation() {
    this.ALERT_TITLE = await this.translation.get('assignments.are_you_sure').toPromise();
    this.ALERT_SUBTITLE = await this.translation.get('assignments.will_delete_permanently').toPromise();
    this.ALERT_BTN_OK = await this.translation.get('button.ok').toPromise();
    this.ALERT_BTN_CANCEL = await this.translation.get('button.cancel').toPromise();
  }
  openResponseCreatePage() {
    this.router.navigateByUrl('/assignment-response-create', { state: { assignmentId: this.assignmentId } });
  }
  showLoading() {
    this.commonService.presentLoading('loading');
  }
  dismissLoading() {
    this.commonService.dismissloading();
  }
  editAssignment() {
    this.router.navigateByUrl('/assignment-create', { state: { assignmentId: this.assignmentId, enableEditMode: true }, replaceUrl:true })
  }
  goback() {
    this.router.navigateByUrl('/assignments', { replaceUrl: true })
  }
  async deleteItem() {
    console.log(this.assignmentId)
    let alert = await this.aletCtrl.create({
      header: this.ALERT_TITLE,
      subHeader: this.ALERT_SUBTITLE,
      buttons: [
        {
          text: this.ALERT_BTN_CANCEL
        },
        {
          text: this.ALERT_BTN_OK,
          handler: () => {
            this.commonService.presentLoading('loading');
            this.assignmentProvider.deleteAssignment(this.assignmentId)
              .subscribe(
                (val: any) => {
                  this.commonService.dismissloading();
                  console.log(val)
                  if (val.success) {
                    this.router.navigateByUrl('/assignments', { replaceUrl: true });
                  }
                }
              )
          }
        }
      ]
    })
    alert.present()
  }

}
