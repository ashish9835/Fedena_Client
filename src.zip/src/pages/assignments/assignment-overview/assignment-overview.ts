import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AssignmentProvider } from 'src/providers/assignment/assignment';
/**
 * Generated class for the AssignmentOverviewComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'assignment-overview',
  templateUrl: 'assignment-overview.html',
  styleUrls: ['assignment-overview.scss']
})
export class AssignmentOverviewComponent implements OnInit {
  @Input() id: any;
  assignment: any
  @Output() didLoad: EventEmitter<boolean> = new EventEmitter<boolean>()

  constructor(
    public assignmentProvider: AssignmentProvider
  ) {
  }
  ngOnInit() {
    this.loadAssignment();
  }
  openLink(link) {
    window.open(link, '_system', 'location=yes');
    return false;
  }
  loadAssignment() {
    this.assignmentProvider.getAssignment(this.id).subscribe((res: any) => {
      console.log(res, 'res');
      this.assignment = res;
      this.didLoad.emit(true);
    })
  }


}
