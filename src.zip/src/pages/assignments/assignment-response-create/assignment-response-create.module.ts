import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { AssignmentResponseCreatePage } from './assignment-response-create';
import { AssignmentResponseCreatePageRoutingModule } from './assignment-response-create-routing.module';
import { DirectivesModule } from 'src/directives/directives.module';
import { ComponentsModule } from 'src/components/components.module';
import { AssignmentsPageModule } from '../assignments.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipesModule,
    DirectivesModule,
    ComponentsModule,
    ReactiveFormsModule,
    AssignmentResponseCreatePageRoutingModule,
    AssignmentsPageModule
  ],
  declarations: [AssignmentResponseCreatePage],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AssignmentResponseCreatePageModule { }
