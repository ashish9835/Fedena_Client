import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { AssignmentResponseCreatePage } from './assignment-response-create';

describe('AssignmentResponseCreatePage', () => {
  let component: AssignmentResponseCreatePage;
  let fixture: ComponentFixture<AssignmentResponseCreatePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AssignmentResponseCreatePage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AssignmentResponseCreatePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
