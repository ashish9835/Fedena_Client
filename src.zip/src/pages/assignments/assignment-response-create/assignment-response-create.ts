import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { map } from 'rxjs/operators';
import { AssignmentProvider } from 'src/providers/assignment/assignment';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { FileProvider } from 'src/providers/file';
import { UploadProvider } from 'src/providers/uploader';

/**
 * Generated class for the AssignmentResponseCreatePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-assignment-response-create',
  templateUrl: 'assignment-response-create.html',
  styleUrls: ['assignment-response-create.scss']
})
export class AssignmentResponseCreatePage implements OnInit {
  totalCompleted: number = 0;
  // totalAttachmentUploadProgress:number = 0;
  files: any[] = [];
  formSchema: any;
  isLoading: boolean = false;
  assignmentResponseForm: FormGroup;
  assignmentId: number;
  chooserConfigs: { allowedSize: number; allowedTypes: String[]; };
  maxAttachments: number;
  maxAttachmentsTotalSize: number;
  editConfigs: any;
  isEditMode: boolean = false;
  assignmentOverviewLoaded: boolean = false;
  formCreated: boolean = false;
  constructor(public navCtrl: NavController,
    public events: EventsService,
    public formBuilder: FormBuilder,
    public fileProvider: FileProvider,
    public uploadProvider: UploadProvider,
    public assignmentProvider: AssignmentProvider,
    public commonService: CommonService,
    public router: Router) {
    this.assignmentId = this.router.getCurrentNavigation().extras.state.assignmentId;
    this.isEditMode = this.router.getCurrentNavigation().extras.state.enableEditMode || false;
    //  this.isEditMode = false;
    this.showLoading();
    this.assignmentResponseForm = this.formBuilder.group({});

    if (this.isEditMode) {
      this.assignmentProvider.getResponseEditConfigs(this.router.getCurrentNavigation().extras.state.responseId).subscribe(
        config => {
          console.log(config)
          this.editConfigs = config;
          this.assignmentId = config.assignmentId;
          this.formSchema = config.schema;
          this.isLoading = false;
          this.createFormUsingSchema().then((form: FormGroup) => {
            this.formCreated = true;
            this.dismissLoading();
            form.setValue(this.editConfigs.assignmentResponseData)
            // console.log(this.editConfigs.subject)
          })
        }
      )

    } else
      this.assignmentProvider.getNewAssignmentResponseSchema(this.assignmentId).subscribe(schema => {
        console.log(schema)
        this.formSchema = schema;
        this.isLoading = false;
        this.createFormUsingSchema().then(form => {
          this.formCreated = true;
          this.dismissLoading();
        });
      })
  }
  ngOnInit() { }
  showLoading() {
    this.commonService.presentLoading('loading');
  }
  dismissLoading() {
    console.log('called')
    this.commonService.dismissloading();
  }
  get pageDataLoaded() {
    return this.assignmentOverviewLoaded && this.formCreated;
  }
  get title() {
    return this.assignmentResponseForm.get('title');
  }
  get content() {
    return this.assignmentResponseForm.get('content');
  }
  get attachments() {
    return this.assignmentResponseForm.get('attachments') as FormArray;
  }
  submitResponse() {
    this.markFormGroupTouched(this.assignmentResponseForm)
    if (!this.assignmentResponseForm.invalid) {
      console.log(this.assignmentResponseForm.value);
      this.commonService.presentLoading('loading');
      if (!this.isEditMode)
        this.assignmentProvider.submitAssignmentResponse(this.assignmentId, this.assignmentResponseForm.value)
          .subscribe(
            (res: any) => {
              this.commonService.dismissloading();
              this.router.navigateByUrl('/assignment-response-details/' + res.assignment_answer.id)
            }
          );
      else
        this.assignmentProvider.updateAssignmentResponse(this.editConfigs.responseId, this.assignmentResponseForm.value)
          .subscribe((res: any) => {
            this.commonService.dismissloading();
            this.router.navigateByUrl('/assignment-response-details/' + res.assignment_answer.id)
          })
    }
  }
  createFormUsingSchema() {
    return new Promise((resolve, reject) => {
      for (let key in this.formSchema) {
        console.log(this.formSchema[key])
        let validators: ValidatorFn[] = [];
        let default_value: any;
        for (let key1 in this.formSchema[key]) {
          if (key1 === 'type' && this.formSchema[key][key1] === "integer") {
            validators.push(Validators.min(this.formSchema[key]['min']))
            validators.push(Validators.max(this.formSchema[key]['max']))
            default_value = 0;
          }
          if (key1 === 'type' && this.formSchema[key][key1] === "text") {
            validators.push(Validators.minLength(this.formSchema[key]['min']))
            validators.push(Validators.maxLength(this.formSchema[key]['max']))
            validators.push(whitespaveValidator());
            default_value = "";
          }
          if (key1 === 'type' && this.formSchema[key][key1] === "array") {
            if (key === 'attachments') {
              this.maxAttachments = this.formSchema[key].count;
              this.maxAttachmentsTotalSize = this.formSchema[key].max;
              this.chooserConfigs = {
                allowedTypes: this.formSchema[key].items.attachment.mime_types,
                allowedSize: this.formSchema[key].items.attachment.max
              }
              if (this.isEditMode && this.formSchema[key] && this.editConfigs.assignmentResponseData.attachments) {
                this.files = this.editConfigs.assignmentResponseData.attachments.map(val => {
                  return {
                    id: val.attachment.id,
                    name: val.attachment.attachment_name,
                    uploadComplete: true,
                    size: val.attachment.attachment_size
                  }
                })
                this.totalCompleted = this.files.length;
              }
              this.assignmentResponseForm.addControl(key, this.formBuilder.array([], attachmentsValidator(this.maxAttachments, this.maxAttachmentsTotalSize)));
            } else
              this.assignmentResponseForm.addControl(key, this.formBuilder.array([]));

            if (this.isEditMode && this.editConfigs.assignmentResponseData[key]) {
              for (let i = 0; i < this.editConfigs.assignmentResponseData[key].length; i++) {
                (this.assignmentResponseForm.get(key) as FormArray).push(
                  this.formBuilder.control(null)
                )
              }
            }
            continue;
          }
          if (!this.formSchema[key].optional) validators.push(Validators.required);


        }

        this.assignmentResponseForm.addControl(key, this.formBuilder.control(default_value, validators));

      }
      this.assignmentResponseForm.valueChanges.subscribe((val) => {
        console.log(val)
      })
      resolve(this.assignmentResponseForm);
    })
  }
  get totalAttachmentUploadProgress() {
    let progress = ((this.files.length === 0 ? 1 : this.totalCompleted) / (this.files.length || 1)) * 100;
    return progress;
  }
  openFileChooser() {

    this.fileProvider.chooseFile(this.chooserConfigs).then((fileInfo: any) => {
      console.log(fileInfo);
      this.files.push(fileInfo)
      this.uploadAttachment(fileInfo);
    }).catch(err => {
      console.log(err);
      if (err === FileProvider.FILE_IS_TOO_LARGE) this.commonService.presentToast('errors.file_size', 2000);
      if (err === FileProvider.UNSUPPORTED_FILE) this.commonService.presentToast('errors.unsupported_file', 2000);
      if (err === FileProvider.ERROR) this.commonService.presentToast('errors.error', 2000);
      // pressed back button without selecting a file.
    });


  }
  addAttachment() {
    this.fileProvider.chooseFile().then(
      (file) => {

      }
    )
    this.attachments.push(this.formBuilder.control({
      attachment_name: 'string',
      attachment_type: 'string',
      attachment_size: 120,
      attachment_path: 'string'
    }, attachmentValidator()))
  }
  removeAttachment(file) {
    console.log(file)
    if (file.uploadComplete) {
      this.totalCompleted--;
    }
    this.files = this.files.filter(item => {
      if (item.id !== file.id) return true;
    })
    let attcmnts = this.attachments.value;
    this.assignmentResponseForm.removeControl('attachments')
    this.assignmentResponseForm.addControl('attachments', this.formBuilder.array([], attachmentsValidator(this.maxAttachments, this.maxAttachmentsTotalSize)))
    attcmnts.forEach(item => {
      if (item.attachment.id !== file.id)
        this.attachments.push(this.formBuilder.control(item, attachmentValidator()))
      else if (item.isPreviousAttachment) {
        item._destroy = true;
        this.attachments.push(this.formBuilder.control(item, attachmentValidator()))
      }
    });

  }
  uploadAttachment(fileInfo: any) {

    this.uploadProvider.upload2(fileInfo).then(status => {
      if (status === "completed" && this.files.find(function (val) { return val.id === fileInfo.id })) {
        this.totalCompleted++;
        console.log("progesse totale.", this.attachments);
        this.attachments.push(this.formBuilder.control({
          attachment: {
            id: fileInfo.id,
            attachment_name: fileInfo.name,
            attachment_type: fileInfo.type,
            attachment_size: fileInfo.size,
            attachment_path: decodeURIComponent(fileInfo.path.split('.com/')[1]).replace(/%2F/g, (math) => {
              return "/"
            })
          }
        }, attachmentValidator()))
        this.attachments.markAsTouched();
        console.log('this is attachments', this.attachments);
      }
    }).catch(err => {

      if (err === "abort") {
        console.log("do not worry.")
      }

    });;
  }
  calculateTotalProgress() {
    let progress = ((this.attachments.length === 0 ? 1 : this.totalCompleted) / (this.attachments.length || 1)) * 100;
    return progress;
  }
  /**
   * Marks all controls in a form group as touched
   * @param formGroup - The form group to touch
   */
  private markFormGroupTouched(formGroup: FormGroup) {
    (<any>Object).keys(formGroup.controls).map(key => formGroup.controls[key]).forEach(control => {
      control.markAsTouched();

      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }
  formatBytes(a, b = 2) { if (0 === a) return "0 Bytes"; const c = 0 > b ? 0 : b, d = Math.floor(Math.log(a) / Math.log(1024)); return parseFloat((a / Math.pow(1024, d)).toFixed(c)) + " " + ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"][d] }

}

interface Attachment {
  attachment_name: string;
  attachment_type: string;
  attachment_size: number;
  attachment_path: string;
}
function attachmentValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    let error: boolean = false;
    // if((control.value.attachment as Attachment).attachment_size > 770)error = true;
    return error ? { 'size error': { value: control.value } } : null;
  };
}
function whitespaveValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
  };
}
function attachmentsValidator(maxAttachments, maxAttachmentsTotalSize): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    let count = 0;
    let totalSize = 0;
    let errors = {}
    console.log(control.value)
    control.value.forEach((item: any) => {
      if (item && !item._destroy) {
        totalSize = totalSize + item.attachment.attachment_size;
        count++
      }
    });
    if (count > maxAttachments) {
      errors['maxLength'] = 'reached max length';
    }
    if (totalSize > maxAttachmentsTotalSize) {
      errors['maxSize'] = 'reached max total size';
    }
    console.log(errors)
    return (Object.keys(errors).length === 0 && errors.constructor === Object) ? null : errors;
  };

}

