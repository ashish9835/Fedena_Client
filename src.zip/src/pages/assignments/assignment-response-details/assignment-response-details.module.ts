import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { AssignmentsPageModule } from '../assignments.module';
import { AssignmentResponseDetailsPageRoutingModule } from './assignment-response-details-routing.module';
import { AssignmentResponseDetailsPage } from './assignment-response-details';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipesModule,
    AssignmentResponseDetailsPageRoutingModule,
    AssignmentsPageModule
  ],
  declarations: [AssignmentResponseDetailsPage],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AssignmentResponseDetailsPageModule { }
