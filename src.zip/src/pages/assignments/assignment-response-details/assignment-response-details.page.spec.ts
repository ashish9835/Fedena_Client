import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { AssignmentResponseDetailsPage } from './assignment-response-details';

describe('AssignmentResponseDetailsPage', () => {
  let component: AssignmentResponseDetailsPage;
  let fixture: ComponentFixture<AssignmentResponseDetailsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AssignmentResponseDetailsPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AssignmentResponseDetailsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
