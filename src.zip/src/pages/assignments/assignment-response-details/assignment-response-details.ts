import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController, Platform } from '@ionic/angular';
import { AssignmentProvider } from 'src/providers/assignment/assignment';
import { CommonService } from 'src/providers/common/common.service';
import { DownloadOptions, DownloadProvider } from 'src/providers/downloader';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

/**
 * Generated class for the AssignmentResponseDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-assignment-response-details',
  templateUrl: 'assignment-response-details.html',
  styleUrls: ['assignment-response-details.scss']
})
export class AssignmentResponseDetailsPage implements OnInit {
  response: any;
  role: String;
  assignmentResponseDidLoad: boolean = false;
  assignmentOverviewDidLoad: boolean = false;
  constructor(
    public navCtrl: NavController,
    public assignmentProvider: AssignmentProvider,
    public user: User,
    public downloader: DownloadProvider,
    public platform: Platform,
    public events: EventsService,
    public commonService: CommonService,
    public router: Router,
    public route: ActivatedRoute
  ) { }
  ngOnInit() {
    this.commonService.presentLoading('loading');
    this.user.getRole().then(role => {
      this.role = role
      this.loadAssignmentResponse(this.route.snapshot.params.id);
    });
  }
  dismissLoading() {
    console.log('is loaded -- ', this.pageDataLoaded)
    if (this.pageDataLoaded)
      this.commonService.dismissloading();
  }
  get pageDataLoaded(): boolean {
    return ((this.role !== 'employee' ? this.assignmentOverviewDidLoad : true)
      && this.assignmentResponseDidLoad);
  }
  loadAssignmentResponse(responseId) {
    this.assignmentProvider.getAssignmentResponse(responseId)
      .subscribe((v: any) => {
        this.assignmentResponseDidLoad = true;
        this.dismissLoading();
        this.response = v.assignment_answer;
      });
  }
  editAssignmentResponse(responseId) {
    this.router.navigateByUrl('/assignment-response-create', { state: { responseId: responseId, enableEditMode: true } })
  }
  acceptResponse() {
    this.assignmentProvider.acceptAssignmentResponse(this.response.id).subscribe((res: any) => {
      if (res.success) {
        console.log('assignment response accepted.')
        this.router.navigateByUrl('/assignment-details', { state: { assignmentId: this.response.assignment_id } });
      }
    })
  }
  rejectResponse() {
    this.assignmentProvider.rejectAssignmentResponse(this.response.id).subscribe((res: any) => {
      if (res.success) {
        this.router.navigateByUrl('/assignment-details', { state: { assignmentId: this.response.assignment_id } });
      }
    })
  }
  goback() {
    this.router.navigateByUrl('/assignments', { replaceUrl: true });
  }
  openLink(link) {
    window.open(link, '_system', 'location=yes');
    return false;
  }
  //this function downloads file from an url 
  download(attachment, openFile) {
    let options: DownloadOptions = new DownloadOptions();
    options.fileName = attachment.attachment_name;
    options.mimeType = attachment.attachment_type;
    options.url = attachment.attachment_url;
    options.openFile = openFile;
    if (this.platform.is('ios')) this.commonService.presentLoading('Downloading attachment');
    if (this.platform.is('android')) this.commonService.presentToast('toast.downloading', 2000);
    this.downloader.download(options).then(destn => {
      console.log("downloaded")
      if (this.platform.is('ios')) this.commonService.dismissloading();
    }).catch(e => {
      if (this.platform.is('ios')) {
        this.commonService.dismissloading();
        this.commonService.presentToast(e, 2000);
      }
    });

  }
  formatBytes(a, b = 2) { if (0 === a) return "0 Bytes"; const c = 0 > b ? 0 : b, d = Math.floor(Math.log(a) / Math.log(1024)); return parseFloat((a / Math.pow(1024, d)).toFixed(c)) + " " + ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"][d] }

}
