import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { Observable } from 'rxjs';
import { finalize, map } from 'rxjs/operators';
import { AssignmentProvider } from 'src/providers/assignment/assignment';

/**
 * Generated class for the AssignmentResponseListComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'assignment-response-list',
  templateUrl: 'assignment-response-list.html',
  styleUrls: ['assignment-response-list.scss']
})
export class AssignmentResponseListComponent implements OnInit {
  @Input('id') assignmentId: number;
  responses$: Observable<any>;
  @Output() didLoad: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(
    public assignmentProvider: AssignmentProvider,
    public navCtrl: NavController,
    public router: Router
  ) {
  }
  ngOnInit() {
    this.responses$ = this.assignmentProvider.getAssignmentResponseList(this.assignmentId)
      .pipe(
        finalize(() => {
          this.didLoad.emit(true);
        }),
        map((v: any) => {
          return v.assignment_answers
        })
      )
  }
  openAssignmentResponseDetails(responseId) {
    this.router.navigateByUrl('/assignment-response-details/' + responseId)
  }

}
