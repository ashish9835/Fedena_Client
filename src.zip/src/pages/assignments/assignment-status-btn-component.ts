import { Component } from "@angular/core";

@Component({
    selector: 'assignment-status-btn',
    inputs:['statusCode'],
    template: `<div [ngSwitch]="statusCode">
    <div *ngSwitchCase="null" class="assignment-status pending">
        {{ 'assignments.pending' | translator }}
    </div>
    <div *ngSwitchCase="'ACCEPTED'" class="assignment-status accepted">
        {{ 'assignments.accepted' | translator }}
    </div>
    <div *ngSwitchCase="'REJECTED'" class="assignment-status rejected" rejected>
        {{ 'assignments.rejected' | translator }}
    </div>
    <div *ngSwitchCase="0" class="assignment-status">
        {{ 'assignments.attended' | translator }}
    </div>
  </div>`,
  styles:[`
   .assignment-status{
    //    transform: scale(0.85);
       min-width:68px;
       text-align:center;
       border-radius: 50px;
       background-color: transparent;
       padding: 6px 0px; 
       font-size: 12px;
       border:1px solid #50c8ff;
       color: #36abe0;
       margin-top: 8%;
    }
  `,
   `.accepted{
    color: #28ba62;
    border: 1px solid #2dd36f;
   }`,
   `.rejected{
    color: #cf3c4f;
    border: 1px solid #ed576b;
   }`,
   `.pending{
    color: #e0ac08;
    border: 1px solid #ffca22;
   }`
  ]

})
export class AssignmentStatusBtnComponent{
    statusCode:String;

}