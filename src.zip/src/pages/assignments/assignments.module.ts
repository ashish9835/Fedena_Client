import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { AssignmentsPageRoutingModule } from './assignments-routing.module';
import { EmptyStateComponent } from './empty-state-component';
import { AssignmentStatusBtnComponent } from './assignment-status-btn-component';
import { SelectSubjectDirective } from './subject-selection-directive';
import { AssignmentsPage } from './assignments';
import { AssignmentOverviewComponent } from './assignment-overview/assignment-overview';
import { ComponentsModule } from 'src/components/components.module';
import { AssignmentResponseListComponent } from './assignment-response-list/assignment-response-list';
import { AttendeesListComponent } from './attendees-list/attendees-list';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssignmentsPageRoutingModule,
    PipesModule,
    ComponentsModule
  ],
  declarations: [EmptyStateComponent,
    AssignmentStatusBtnComponent, SelectSubjectDirective, AssignmentsPage, AssignmentOverviewComponent, AssignmentResponseListComponent, AttendeesListComponent
  ],
  exports: [AssignmentStatusBtnComponent, AssignmentOverviewComponent, AssignmentResponseListComponent, AttendeesListComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AssignmentsPageModule { }

