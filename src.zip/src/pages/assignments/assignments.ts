import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { finalize, map } from 'rxjs/operators';
import { AssignmentProvider } from 'src/providers/assignment/assignment';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

/**
 * Generated class for the AssignmentsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-assignments',
  templateUrl: 'assignments.html',
  styleUrls: ['assignments.scss']
})
export class AssignmentsPage implements OnInit {
  tab: any = "all";
  assignments: any[] = [];
  role: string;
  page: number = 1;
  perpageCount: number;
  loader = { isShowing: true };
  subjectFilterOptions: any[];
  selectedFilterSubjectID: number = -1;

  constructor(
    public navCtrl: NavController,
    public user: User,
    public events: EventsService,
    public assignmentProvider: AssignmentProvider,
    public commonService: CommonService,
    public router: Router) {
    this.user.getRole().then(r => this.role = r)
    // this.loadAssignments()

  }
  ngOnInit() { }
  goback() {
    this.navCtrl.setDirection('root');
    this.router.navigateByUrl('/tabs', { replaceUrl: true })
  }
  onFilterSubjectSelect(subjectId) {
    this.selectedFilterSubjectID = subjectId;
    console.log("-----", this.selectedFilterSubjectID)
    this.loadAssignments();
  }
  loadAssignments(page?) {
    return new Promise((resolve, reject) => {
      if (!page)//checks if the method is called for the initial page load.
      {
        //  this.assignments = [];
        while (this.assignments.pop()) { }
        this.page = 1;
        this.commonService.presentLoading('loading');
      }
      this.loader.isShowing = true;
      this.assignmentProvider.getAssignments(
        this.tab !== 'all' ? this.tab : null,
        page,
        this.selectedFilterSubjectID != -1 ? this.selectedFilterSubjectID : null
      ).pipe(
        finalize(() => {
          this.commonService.dismissloading();
          this.loader.isShowing = false;
          resolve();
        }),
        map((res: any) => {
          if (res.success) {
            this.perpageCount = res.per_page;
            // this.assignments = this.assignments || [];//initialize the array if null.
            this.assignments.push(...res.assignments);
          }
          else {
            this.user.errorHandler();
            this.navCtrl.pop()
          }
          return res;
        }
        )).subscribe();
    })
  }
  openAssignmentDetails(assignment) {
    if (this.role !== 'employee' && assignment.status !== null) {
      this.assignmentProvider.getAssignment(assignment.id).subscribe(val => {
        this.router.navigateByUrl('/assignment-response-details/' + val.assignment_answers[0].id)
      })
      return;
    }
    this.router.navigateByUrl('/assignment-details', { state: { assignmentId: assignment.id } })
  }
  openAssignmentCreatePage(subject) {
    if (subject)
      this.router.navigateByUrl('/assignment-create', { state: { subject: subject } })
  }
  deleteItem(assignmentId) {
    console.log(assignmentId)
    this.assignmentProvider.deleteAssignment(assignmentId)
      .subscribe(
        (val) => {
          console.log(val);
          this.loadAssignments()
        }
      )
  }
  doInfinite(infiniteScroll: any) {
    this.page++;
    if (this.assignments.length % this.perpageCount !== 0) {//checks if the previous page loaded was the last page.
      infiniteScroll.target.complete()
      return;
    };
    //load assignments in next page and then stop the loader.
    this.loadAssignments(this.page).then(() => {
      infiniteScroll.target.complete()
    });
  }
  ionViewDidEnter() {
    this.loadAssignments()
    this.subjectFilterOptions = [{ name: 'All', value: -1 }];
    this.user.getRole().then(
      role => {
        this.assignmentProvider.getSubjects().subscribe(
          (res: any) => {
            if (res.success && res.subjects && res.subjects.length > 0) {
              res.subjects.forEach(subject => {
                let option = { value: subject.id, name: subject.name, ...(role === 'employee') ? { subtext: subject.batch_name } : {} };
                this.subjectFilterOptions.push(option)
              });
            }
          }
        )
      }
    )
  }
}
