import { Component, Input, EventEmitter, Output, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { map, finalize } from 'rxjs/operators';
import { AssignmentProvider } from 'src/providers/assignment/assignment';

/**
 * Generated class for the AttendeesListComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'attendees-list',
  templateUrl: 'attendees-list.html',
  styleUrls:['attendees-list.scss']
})
export class AttendeesListComponent implements OnInit {
  @Input('id') assignmentId: number;
  attendees: Observable<any>;
  @Output() didLoad: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(
    public assignmentProvider: AssignmentProvider
  ) {
  }
  ngOnInit() {
    this.attendees = this.assignmentProvider.getAssignment(this.assignmentId)
      .pipe(
        finalize(() => {
          this.didLoad.emit(true);
        }),
        map(v => {
          return v.students
        })
      )

  }

}
