import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AttendeesSelectionComponent } from './attendees-selection';


const routes: Routes = [
  {
    path: '',
    component: AttendeesSelectionComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AttendeesSelectionComponentRoutingModule { }
