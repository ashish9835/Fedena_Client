import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { AttendeesSelectionComponentRoutingModule } from './attendees-selection-routing.module';
import { AttendeesSelectionComponent } from './attendees-selection';
import { PipesModule } from 'src/pipes/pipes.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipesModule,
    AttendeesSelectionComponentRoutingModule
  ],
  declarations: [AttendeesSelectionComponent]
})
export class AttendeesSelectionComponentModule { }
