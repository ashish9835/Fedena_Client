import { Component, Input, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { AssignmentProvider } from 'src/providers/assignment/assignment';

/**
 * Generated class for the AttendeesSelectionComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'attendees-selection',
  templateUrl: 'attendees-selection.html',
  styleUrls: ['attendees-selection.scss']
})
export class AttendeesSelectionComponent implements OnInit {
  isSelectedAll: boolean;
  attendees: any[];
  @Input() subject: any;
  @Input() selectedAttendees: any;

  constructor(
    private _viewCtrler: ModalController,
    public assignmentProvider: AssignmentProvider,
  ) {
  }
  ngOnInit() {
    this.assignmentProvider.getStudents(this.subject.id).subscribe((students: any) => {
      this.attendees = [];
      students.forEach(student => {
        this.attendees.push({
          isSelected: (this.selectedAttendees as Array<number>).indexOf(student.id) == -1 ? false : true,
          value: student
        });
      })
      this.isSelectedAll = this.getIsSelectedAll();
    })
  }
  onSelect(attendee) {
    if (!attendee.isSelected) {
      this.isSelectedAll = false;
    } else {
      this.isSelectedAll = this.getIsSelectedAll()
    }
  }
  getIsSelectedAll() {
    return !this.attendees.some(val => !val.isSelected);
  }
  onChangeSelectAll() {
    this.attendees.forEach((attendee) => {
      attendee.isSelected = this.isSelectedAll;
    })
  }
  returnSelection() {
    let selectedAttendees = this.attendees.filter(val => {
      return val.isSelected;
    }).map((item) => {
      return item.value.id;
    })
    this._viewCtrler.dismiss(selectedAttendees)
  }
  goback() {
    this._viewCtrler.dismiss();
  }
}
