import { Component } from "@angular/core";

@Component({
    selector: 'empty-state',
    inputs:['message'],
    template:`
    <div class="empty-state">
       <h3>{{message}}</h3>
    </div>
    `,
    styles:[`
    .empty-state{
        padding-top: unset;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        min-height: 500px;
        // height: -webkit-fill-available;
        // padding-bottom: 100px;
    }
    `,`
    h3{
        color: grey;
    }
    `

    ]
})
export class EmptyStateComponent{
    message: String = 'Empty';

}