import { Directive, HostListener, Output, EventEmitter } from "@angular/core";
import { AssignmentProvider } from "../../providers/assignment/assignment";
import { TranslateService } from "@ngx-translate/core";
import { AlertController, LoadingController } from '@ionic/angular';
@Directive({
    selector: '[select-subject]'
})
export class SelectSubjectDirective {
    LOADER_TEXT: string = "Loading subjects...";
    ALERT_TITLE_TEXT: string = "Select a subject:";
    ALERT_CANCEL_TEXT: string = "Cancel";
    ALERT_NEXT_TEXT: string = "Next";
    ALERT_OK_TEXT: string = "Ok";
    ALERT_NO_SUBJECT_TEXT: string = "There are no assigned subjects.";


    @Output() onSubjectSelect: EventEmitter<number> = new EventEmitter<number>();
    constructor(
        public alertCtrl: AlertController,
        public loadingCtrl: LoadingController,
        public assignmentProvider: AssignmentProvider,
        public translator: TranslateService
    ) {
        this.initTranslation();
    }
    @HostListener('click') async selectSubject() {

        let loadingIndicator = await this.loadingCtrl.create({
            message: this.LOADER_TEXT
        })
        loadingIndicator.present()
        this.assignmentProvider.getSubjects().subscribe(
            async (res: any) => {
                loadingIndicator.dismiss();
                if (res.success && res.subjects && res.subjects.length > 0) {
                    let alert = await this.alertCtrl.create({
                        header: this.ALERT_TITLE_TEXT,
                        inputs: this.addInput(res),
                        buttons: [
                            {
                                text: this.ALERT_CANCEL_TEXT
                            },
                            {
                                text: this.ALERT_NEXT_TEXT,
                                handler: (subject) => {
                                    this.onSubjectSelect.emit(subject);
                                }
                            }
                        ]
                    });
                    alert.present();
                } else {
                    let alert = await this.alertCtrl.create({
                        subHeader: this.ALERT_NO_SUBJECT_TEXT,
                        buttons: [
                            {
                                text: this.ALERT_OK_TEXT
                            }
                        ]
                    });
                    alert.present()

                }
            }
        )
    }
    addInput(res) {
        let inputs = []
        if (res.success) {
            res.subjects.forEach(subject => {
                console.log(subject);
                inputs.push({
                    type: 'radio',
                    label: subject.name + ` ( ${subject.batch_name} )`,
                    value: subject
                });
            });
            return inputs;
        }
    }
    async initTranslation() {
        this.ALERT_OK_TEXT = await this.translator.get('alert.btn_ok').toPromise();
        this.ALERT_CANCEL_TEXT = await this.translator.get('alert.btn_cancel').toPromise();
        this.ALERT_NEXT_TEXT = await this.translator.get('alert.btn_next').toPromise();
        this.ALERT_TITLE_TEXT = await this.translator.get('assignments.select_subject').toPromise();
        this.ALERT_NO_SUBJECT_TEXT = await this.translator.get('assignments.no_subjects').toPromise();
        this.LOADER_TEXT = await this.translator.get('loader.loading_subjects').toPromise();
    }
}