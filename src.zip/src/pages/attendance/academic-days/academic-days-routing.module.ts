import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AcademicDaysPage } from './academic-days';


const routes: Routes = [
  {
    path: '',
    component: AcademicDaysPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AcademicDaysPageRoutingModule { }
