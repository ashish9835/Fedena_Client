import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { MarkAttendanceModel } from 'src/models/my-class/markAttendance';
import { Attendance } from 'src/providers/attendance';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-academic-days',
  templateUrl: 'academic-days.html',
  styleUrls: ['academic-days.scss']
})
export class AcademicDaysPage implements OnInit {
  batch: any;
  attendanceType = '';
  token = '';
  userid = '';
  academicDays: any = [];
  academicMonths: any[];
  first: any = [];
  second: any = [];
  page: number = 1;
  startDate = new Date();
  endDate = new Date();
  currentDate = new Date();
  month: number;
  year: number;
  constructor(
    private event: EventsService,
    public navCtrl: NavController,
    public attendance: Attendance,
    public userService: User,
    public commonService: CommonService,
    public router: Router
  ) {
    this.batch = this.router.getCurrentNavigation().extras.state.batch;
    console.log(this.batch);
  }
  ngOnInit() {
  }
  ionViewDidEnter() {
    this.getData();
  }
  getData() {
    this.commonService.presentLoading('Loading Academic days');
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          if (id) {
            this.userid = id;
            this.loadWorkingDays();
          } else {
            this.commonService.presentAlert('Account not found')
          }
        });

      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  showReport() {
    this.router.navigateByUrl('/attendance-report', { state: { batch: this.batch } })
  }
  goback() {
    // this.navCtrl.setRoot('TabsPage', { tabIndex: 2 });
    // this.navCtrl.popToRoot();
  }
  editAbsentees(batch, date) {
    if (this.attendanceType === 'Daily') {
      this.router.navigateByUrl('/students-list', { state: { batch: batch, date: date } });
    } else {
      this.router.navigateByUrl('/subjects-list', { state: { batch: batch, date: date } });
    }
  }

  loadWorkingDays() {
    const startDate = this.currentDate;
    this.startDate.setDate(startDate.getDate() - 90);
    console.log(this.startDate);
    this.attendance.loadWorkingDays(this.token, this.batch.id, this.startDate, this.endDate).subscribe(
      (response) => {
        this.commonService.dismissloading();
        console.log(response);
        const apiResponse: any = response;
        if (apiResponse.success === true) {
          this.academicDays = new MarkAttendanceModel(apiResponse.academic_days);
          console.log(this.academicDays);
          this.academicMonths = this.academicDays.dates;
          this.attendanceType = this.academicDays.attendanceType;
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        } else
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          } else this.commonService.presentAlert('Session expired');
      },
    );
  }

  doInfinite(infiniteScroll) {
    const lastDates = this.academicMonths[this.academicMonths.length - 1].days;
    const lastDate = lastDates[lastDates.length - 1].date;
    this.endDate = new Date(new Date(lastDate).setDate(new Date(lastDate).getDate() - 1));
    this.startDate = new Date(new Date(this.endDate).setDate(new Date(lastDate).getDate() - 90));

    /*const endDate = this.startDate;
    console.log(endDate);
    this.endDate.setDate(endDate.getDate() - 91);*/
    console.log(this.endDate);
    /*const startDate = this.startDate;
    this.startDate.setDate(this.endDate.getDate() - 90);*/
    console.log(this.startDate);

    console.log('Loading academic days');
    setTimeout(() => {
      this.attendance.loadWorkingDays(
        this.token,
        this.batch.id,
        this.startDate,
        this.endDate,
      ).subscribe(
        (response) => {
          const apiResponse: any = response;
          this.commonService.dismissloading();
          this.academicDays = new MarkAttendanceModel(apiResponse.academic_days);
          this.academicMonths = this.academicMonths.concat(this.academicDays.dates);
          console.log(this.academicDays);
          infiniteScroll.target.complete();
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.userService.errorHandler();
          }
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        },
      );
    }, 500);
  }
  showDay(date) {
    const currentDate = new Date(date);
    const weekday = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return weekday[currentDate.getDay()];
  }
  //this method is used to get a valid date string for a string containing only 'month name' and 'year'. i.e. 'march 2019'.
  getDate(str: string) {
    let months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];

    let month = str.split(' ')[0];
    let year = str.split(' ')[1];
    let date = new Date();
    date.setMonth(months.indexOf(month.toLocaleLowerCase()));
    date.setFullYear(Number.parseInt(year));
    return date.toDateString();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AcademicDays');
  }

}
