import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ChartsModule } from 'ng2-charts';
import { PipesModule } from 'src/pipes/pipes.module';
import { AttendanceReportPage } from './attendance-report';
import { AttendanceReportPageRoutingModule } from './attendance-report-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        AttendanceReportPageRoutingModule,
        ChartsModule
    ],
    declarations: [AttendanceReportPage]
})



export class AttendanceReportPageModule { }
