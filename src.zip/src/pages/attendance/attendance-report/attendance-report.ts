import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { BatchAttendanceListModel, BatchAttendanceModel } from 'src/models/my-class/batchAttendance';
import { Batch } from 'src/providers/batch';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';


@Component({
  selector: 'page-attendance-report',
  templateUrl: 'attendance-report.html',
  styleUrls: ['attendance-report.scss']
})
export class AttendanceReportPage implements OnInit {
  doughnutChartLabels: string[] = ['', ''];
  doughnutChartColours: any[] = [{ backgroundColor: ['#2E4C6F', '#C24587'] }];
  doughnutChartData: number[] = [0, 100];
  doughnutChartType: string = 'doughnut';
  attendanceType = 'Daily';
  today = new Date();
  filterdate = this.today.toISOString();
  batchAttendance: any;
  month = 10;
  year = 2017;
  totalDay;
  doughnutChart: any;
  type: string;
  attendances: any = [];
  batchid = '0';
  batchName = '';
  token = '';
  userid = '';
  batch = [];
  totalWorking = 0;
  totalAttendace = 0;
  overall: any;
  last10Days = 0;
  last1Months = 0;
  last3Months = 0;
  first: any = [];
  second: any = [];
  subjects: any = [];
  totalAverage: number;
  dates = [];
  pet: string = 'kittens';
  constructor(
    private translate: TranslateService,
    private event: EventsService,
    public navCtrl: NavController,
    private batchService: Batch,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.month = this.today.getMonth() + 1;
    this.year = this.today.getFullYear();
    this.commonService.presentLoading('Loading report');
    this.batch = this.router.getCurrentNavigation().extras.state.batch;
    console.log(this.batch);
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.batchid = this.batch['id'];
        this.batchName = this.batch['fullName'];
        this.loadOverview();
        this.loadAttendanceInMonth();

      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  ngOnInit() {

  }
  viewDetails(data) {
    this.router.navigateByUrl('/report-students-list', {
      state: {
        data: data,
        batch: this.batch,
        day: data.date,
        totalAbsentees: data.total_absentees
      }
    })
  }
  viewSubjectsList(data) {
    this.router.navigateByUrl('/report-subjects-list', {
      state: {
        batch: this.batch,
        date: data.date,
      }
    })
  }
  updateChart(type) {
    if (type === 'overviews') {

    }
  }

  async loadOverview() {
    this.type = 'overviews';
    let strTotalAttendance = await this.translate.get('attendance_report.total_attendance').toPromise();
    let strPresence = await this.translate.get('attendance_report.presence').toPromise();
    let strPresent = await this.translate.get('attendance_report.present').toPromise();
    let strAbsent = await this.translate.get('attendance_report.absent').toPromise();

    this.batchService.loadBatchAttendanceOverview(this.token, this.batchid).subscribe(
      (response) => {
        this.commonService.dismissloading();
        console.log(response);
        const apiResponse: any = response;
        if (apiResponse.success === true) {
          this.batchAttendance = new BatchAttendanceModel(apiResponse);
          console.log(this.batchAttendance);
          this.attendanceType = this.batchAttendance.attendanceType;
          if (this.attendanceType === 'SubjectWise') {

            this.totalAverage = Number.parseFloat(this.batchAttendance.totalAvgClass);
            this.subjects = this.batchAttendance.subjects;

            this.totalWorking = this.batchAttendance.totalClasses;
            if (this.batchAttendance.totalAvgClass == null) this.totalAverage = 0;
            this.doughnutChartLabels[0] = strPresent;
            this.doughnutChartLabels[1] = strAbsent;
            this.doughnutChartData = [this.totalAverage, Number.parseFloat((100.00 - this.totalAverage).toFixed(2))];
          } else {
            console.log('load test');
            this.totalWorking = apiResponse.total_no_working_days;
            this.overall = apiResponse.attendances['overall'];
            this.last10Days = apiResponse.attendances['last_10_days'];
            this.last1Months = apiResponse.attendances['last_1_month'];
            this.last3Months = apiResponse.attendances['last_3_months'];
            this.doughnutChartLabels[0] = strPresent;
            this.doughnutChartLabels[1] = strAbsent;
            this.doughnutChartData = [this.overall, (100 - this.overall).toFixed(2)];
          }
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        } else this.commonService.presentAlert('Session expired');
      },
    );

  }
  showDay(date) {
    const currentDate = new Date(date);
    const weekday = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return weekday[currentDate.getDay()];
  }
  compare(date1, date2) {
    const tempDate1 = new Date(date1);
    const tempDate2 = new Date(date2);
    // tslint:disable-next-line:max-line-length
    if (tempDate1.getMonth() === tempDate2.getMonth() && tempDate1.getFullYear() === tempDate2.getFullYear())
      return true;
    // tslint:disable-next-line:no-else-after-return
    else return false;
  }
  changeDate() {
    const selectedDate = new Date(this.filterdate);
    this.month = selectedDate.getMonth() + 1;
    this.year = selectedDate.getFullYear();

    this.loadAttendanceInMonth();
  }

  loadAttendanceInMonth() {
    this.batchService.loadBatchAttendance(
      this.token,
      this.batchid,
      this.batch['startDate'],
      this.batch['endDate'],
    ).subscribe(
      (response) => {
        console.log(response);
        this.attendances = [];
        this.commonService.dismissloading();
        const apiResponse: any = response;
        if (apiResponse.success === true) {
          apiResponse.dates.forEach(i => {
            this.attendances.push(new BatchAttendanceListModel(i));
          });

          this.dates = this.attendances;
          console.log(this.attendances);
        }

      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
    // this.content.scrollToTop();

  }

  overview() {
    this.commonService.presentLoading('Loading report');
    this.loadOverview();
  }
  attendanceList() {
    this.commonService.presentLoading('Loading report');
    this.loadAttendanceInMonth();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AttendanceReportPage');
  }
  changed() {
    // this.content.scrollToTop();
  }

}
