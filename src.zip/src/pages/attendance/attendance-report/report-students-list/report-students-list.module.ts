import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ChartsModule } from 'ng2-charts';
import { ComponentsModule } from 'src/components/components.module';
import { PipesModule } from 'src/pipes/pipes.module';
import { ReportStudentsListPage } from './report-students-list';
import { ReportStudentsListPageRoutingModule } from './report-students-list-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        ReportStudentsListPageRoutingModule,
        ChartsModule,
        ComponentsModule
    ],
    declarations: [ReportStudentsListPage]
})



export class ReportStudentsListPageModule { }
