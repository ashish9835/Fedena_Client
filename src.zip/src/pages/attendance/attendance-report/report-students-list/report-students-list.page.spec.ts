import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { ReportStudentsListPage } from './report-students-list';

describe('ReportStudentsListPage', () => {
  let component: ReportStudentsListPage;
  let fixture: ComponentFixture<ReportStudentsListPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ReportStudentsListPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ReportStudentsListPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
