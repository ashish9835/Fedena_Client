import { Storage } from '@ionic/storage';
import { Component, OnInit } from '@angular/core';
import { EventsService } from 'src/providers/events/events.service';
import { NavController } from '@ionic/angular';
import { Batch } from 'src/providers/batch';
import { User } from 'src/providers/user';
import { CommonService } from 'src/providers/common/common.service';
import { ReportStudentAbsenteeListModel, studentAbsenteeListModelByName, studentAbsenteeListModelByRollNo } from 'src/models/my-class/studentAbsenteeList';
import { Router } from '@angular/router';

@Component({
  selector: 'page-report-students-list',
  templateUrl: 'report-students-list.html',
  styleUrls: ['report-students-list.scss']
})
export class ReportStudentsListPage implements OnInit {
  day = '';
  students: any = [];
  fullstudents: any = [];
  studentAttendance: any;
  batchid = '0';
  batch: any;
  batchName = '';
  token = '';
  userid = '';
  showFull = false;
  totalStudentCount = 0;
  totalAbsentees = 0;
  average = 0;
  direct: boolean = true;
  sortType: any = { name: 'Name', value: 0 }
  constructor(
    private event: EventsService,
    public navCtrl: NavController,
    private batchService: Batch,
    private userService: User,
    private storage: Storage,
    private commonService: CommonService,
    private router: Router
  ) {
    this.storage.get('attendance_sort_type').then(val => {
      if (val)
        this.sortType = val
    })
    this.commonService.presentLoading('Loading absentees');
    this.router.getCurrentNavigation().extras.state.data
    if (this.router.getCurrentNavigation().extras.state.route === true) this.direct = false;
    this.batch = this.router.getCurrentNavigation().extras.state.batch;
    this.batchName = this.batch.name;
    this.batchid = this.batch.id;
    this.day = this.router.getCurrentNavigation().extras.state.day;
    this.totalAbsentees = this.router.getCurrentNavigation().extras.state.totalAbsentees;

    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.loadBatchStudentsAttendanceListDay();
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });

  }
  ngOnInit() {

  }
  ionViewWillLeave() {
    this.storage.set('attendance_sort_type', this.sortType);
  }
  sortStudentsBy(option) {
    console.log(option)
    this.sortType = option;
    if (option.value === 0) {
      this.students.sort(studentAbsenteeListModelByName);
    }
    else {
      this.students.sort(studentAbsenteeListModelByRollNo)
    }
  }
  goback() {
    this.router.navigateByUrl('/academic-days', { state: { 'batch': this.batch } });
  }
  loadBatchStudentsAttendanceListDay() {
    this.batchService.loadBatchStudentsAttendanceListDay(
      this.token,
      this.batchid,
      this.day,
      this.showFull,
    ).subscribe(
      (response: any) => {
        console.log(response);
        this.commonService.dismissloading();
        if (response.success === true) {
          this.studentAttendance = new ReportStudentAbsenteeListModel(response);
          console.log(this.studentAttendance);
          this.totalStudentCount = this.studentAttendance.totalStudentCount;
          this.day = this.studentAttendance.date;
          this.batchName = this.studentAttendance.batchName;
          this.totalAbsentees = this.studentAttendance.totalAbsentees;
          // tslint:disable-next-line:max-line-length
          this.average = ((this.totalStudentCount - this.totalAbsentees) / this.totalStudentCount) * 100;
          this.average = Math.round(this.average);
          this.fullstudents = this.studentAttendance.students;
          this.students = this.fullstudents;
          this.sortStudentsBy(this.sortType);
        } else this.commonService.presentAlert('No data');

      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        } else
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          } else this.commonService.presentAlert('No data');
      },
    );

  }
  showAll() {
    this.showFull = true;
    this.loadBatchStudentsAttendanceListDay();
  }


  filterItems(ev: any) {
    const val = ev.target.value;
    if (val && val.trim() !== '') {
      this.students = this.fullstudents.filter((data) => {
        return (data.studentName.toLowerCase().indexOf(val.toLowerCase()) > -1);
      });
    } else {
      this.students = this.fullstudents;
    }
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ReportStudentListPage');
  }

}
