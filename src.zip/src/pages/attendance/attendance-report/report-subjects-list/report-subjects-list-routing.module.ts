import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReportSubjectsListPage } from './report-subjects-list';


const routes: Routes = [
  {
    path: '',
    component: ReportSubjectsListPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReportSubjectsListPageRoutingModule { }
