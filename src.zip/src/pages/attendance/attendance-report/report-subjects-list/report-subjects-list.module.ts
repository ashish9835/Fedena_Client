import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ChartsModule } from 'ng2-charts';
import { ComponentsModule } from 'src/components/components.module';
import { PipesModule } from 'src/pipes/pipes.module';
import { ReportSubjectsListPage } from './report-subjects-list';
import { ReportSubjectsListPageRoutingModule } from './report-subjects-list-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipesModule,
    ReportSubjectsListPageRoutingModule,
    ChartsModule
  ],
  declarations: [ReportSubjectsListPage]
})



export class ReportSubjectsListPageModule { }
