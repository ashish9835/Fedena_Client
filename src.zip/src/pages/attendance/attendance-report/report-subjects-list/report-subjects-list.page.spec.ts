import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { ReportSubjectsListPage } from './report-subjects-list';

describe('ReportSubjectsListPage', () => {
  let component: ReportSubjectsListPage;
  let fixture: ComponentFixture<ReportSubjectsListPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ReportSubjectsListPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ReportSubjectsListPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
