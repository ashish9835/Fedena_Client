import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { ClassPeriodModel } from 'src/models/my-class/classPeriod';
import { Attendance } from 'src/providers/attendance';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-report-subjects-list',
  templateUrl: 'report-subjects-list.html',
  styleUrls: ['report-subjects-list.scss']
})
export class ReportSubjectsListPage implements OnInit {
  token = '';
  userid = '';
  periods: any = [];
  batch: any;
  date: any;
  dateLabel = '';
  totalStudentCount = 0;
  totalAbsentees = 0;
  average = 0;
  noAbsentee = [];
  electiveTimingId: any;
  constructor(
    public event: EventsService,
    public navCtrl: NavController,
    public attendance: Attendance,
    public userService: User,
    public commonService: CommonService,
    public router: Router
  ) {
    this.commonService.presentLoading('Loading subjects')
    this.batch = this.router.getCurrentNavigation().extras.state.batch;
    console.log(this.batch);
    this.date = this.router.getCurrentNavigation().extras.state.date;
    console.log(this.date);
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          if (id) {
            this.userid = id;
            this.loadPeriods();
          } else {
            this.commonService.presentAlert('Account not found');
          }
        });

      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }

  ngOnInit() {

  }
  viewDetails(batchId, subjectId, date, classTimingId) {
    this.router.navigateByUrl('/report-subject-students-list', { state: { batch: this.batch, date: date, subjectId: subjectId, classTimingId: classTimingId } });
  }
  loadPeriods() {
    this.attendance.loadPeriodsOn(this.token, this.batch.id, this.date).subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        console.log(response);
        const apiResponse: any = response;
        if (apiResponse.success === true) {
          apiResponse.periods.forEach(i => {
            this.periods.push(new ClassPeriodModel(i));
          });
          // this.periods = apiResponse.periods;
          console.log(this.periods);
          this.dateLabel = apiResponse.date;
          this.totalAbsentees = apiResponse.totalAbsentees;
          this.electiveTimingId = this.periods[0].classTimingId;

          for (const key in response.periods[0].subjects) {
            this.noAbsentee[key] = this.periods[0].subjects[key].noAbsentees;
            console.log(key);
            console.log(this.noAbsentee[0]);
          }
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ReportSubjectsListPage');
  }
}
