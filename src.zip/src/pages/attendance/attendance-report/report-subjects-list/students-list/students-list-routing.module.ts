import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReportSubjectStudentsListPage } from './students-list';


const routes: Routes = [
  {
    path: '',
    component: ReportSubjectStudentsListPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReportSubjectStudentsListPageRoutingModule { }
