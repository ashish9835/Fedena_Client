import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { ReportSubjectStudentsListPage } from './students-list';
import { ReportSubjectStudentsListPageRoutingModule } from './students-list-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReportSubjectStudentsListPageRoutingModule,
    PipesModule
  ],
  declarations: [ReportSubjectStudentsListPage]
})



export class ReportSubjectStudentsListPageModule { }
