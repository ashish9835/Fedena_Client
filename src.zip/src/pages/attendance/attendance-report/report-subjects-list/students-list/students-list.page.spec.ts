import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { ReportSubjectStudentsListPage } from './students-list';

describe('ReportSubjectStudentsListPage', () => {
  let component: ReportSubjectStudentsListPage;
  let fixture: ComponentFixture<ReportSubjectStudentsListPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ReportSubjectStudentsListPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ReportSubjectStudentsListPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
