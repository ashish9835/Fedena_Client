import { Storage } from '@ionic/storage';
import { Component, OnInit } from '@angular/core';
import { EventsService } from 'src/providers/events/events.service';
import { NavController } from '@ionic/angular';
import { Batch } from 'src/providers/batch';
import { User } from 'src/providers/user';
import { CommonService } from 'src/providers/common/common.service';
import { StudentAbsenteeListModel, studentAbsenteeListModelByName, studentAbsenteeListModelByRollNo } from 'src/models/my-class/studentAbsenteeList';
import { Router } from '@angular/router';
@Component({
  selector: 'page-report-subject-students-list',
  templateUrl: 'students-list.html',
  styleUrls: ['./students-list.scss']
})
export class ReportSubjectStudentsListPage implements OnInit {
  day = '';
  students: any = [];
  fullstudents: any = [];
  batchid = '0';
  batch: any;
  batchName = '';
  token = '';
  userid = '';
  showFull = false;
  totalStudentCount = 0;
  totalAbsentees = 0;
  average = 0;
  subjectId = '';
  classTimingId: number;
  direct: boolean = true;
  sortType: any = { name: 'Name', value: 0 };
  constructor(
    private event: EventsService,
    public navCtrl: NavController,
    private batchService: Batch,
    private userService: User,
    private storage: Storage,
    private commonService: CommonService,
    private router: Router
  ) {
    this.storage.get('attendance_sort_type').then(val => {
      if (val)
        this.sortType = val
    })
    this.commonService.presentLoading('Loading students');
    if (this.router.getCurrentNavigation().extras.state.route === true) this.direct = false;
    this.batch = this.router.getCurrentNavigation().extras.state.batch;
    console.log(this.batch);
    this.batchid = this.batch.id;
    this.subjectId = this.router.getCurrentNavigation().extras.state.subjectId;
    this.classTimingId = this.router.getCurrentNavigation().extras.state.classTimingId;
    this.day = this.router.getCurrentNavigation().extras.state.date;

    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.loadBatchStudentsAttendanceListSubject(this.subjectId);
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });

  }
  ngOnInit() {

  }
  sortStudentsBy(option) {
    console.log(option)
    this.sortType = option;
    if (option.value === 0) {
      this.students.sort(studentAbsenteeListModelByName)
    }
    else {
      this.students.sort(studentAbsenteeListModelByRollNo)

    }
  }
  ionViewWillLeave() {
    this.storage.set('attendance_sort_type', this.sortType);
  }
  goback() {
    this.router.navigateByUrl('/academic-days', { state: { 'batch': this.batch } });

  }
  loadBatchStudentsAttendanceListSubject(subjectId) {
    this.batchService.loadBatchStudentsAttendanceListSubjects(
      this.token, this.batchid, this.day, subjectId, this.showFull, this.classTimingId,
    ).subscribe(
      (response: any) => {
        console.log(response);
        this.commonService.dismissloading();
        if (response.success === true) {
          this.totalStudentCount = response.total_student_count;
          this.day = response.date;
          this.batchName = response.batch_name;
          this.totalAbsentees = response.total_absentees;
          // tslint:disable-next-line:max-line-length
          this.average = ((this.totalStudentCount - this.totalAbsentees) / this.totalStudentCount) * 100;
          this.average = Math.round(this.average);
          response.students.forEach(i => {
            this.fullstudents.push(new StudentAbsenteeListModel(i));
          });
          // this.fullstudents = response.students;
          this.students = this.fullstudents;
          console.log(this.students);
          this.sortStudentsBy(this.sortType);
        } else this.commonService.presentAlert('No Data');

      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );

  }
  showAll() {
    this.showFull = true;
    this.loadBatchStudentsAttendanceListSubject(this.subjectId);
  }

  filterItems(ev: any) {
    const val = ev.target.value;
    if (val && val.trim() !== '') {
      this.students = this.fullstudents.filter((data) => {
        return (data.studentName.toLowerCase().indexOf(val.toLowerCase()) > -1);
      });
    } else {
      this.students = this.fullstudents;
    }
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ReportStudentListPage');
  }


}
