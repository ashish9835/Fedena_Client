import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ComponentsModule } from 'src/components/components.module';
import { PipesModule } from 'src/pipes/pipes.module';
import { StudentsListPage } from './students-list';
import { StudentsListPageRoutingModule } from './students-list-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        StudentsListPageRoutingModule,
        ComponentsModule
    ],
    declarations: [StudentsListPage]
})



export class StudentsListPageModule { }
