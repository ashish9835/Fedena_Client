import { Storage } from '@ionic/storage';
import { Component, OnInit } from '@angular/core';
import { ReportStudentAbsenteeListModel, studentAbsenteeListModelByName, studentAbsenteeListModelByRollNo } from 'src/models/my-class/studentAbsenteeList';
import { EventsService } from 'src/providers/events/events.service';
import { NavController } from '@ionic/angular';
import { Attendance } from 'src/providers/attendance';
import { User } from 'src/providers/user';
import { CommonService } from 'src/providers/common/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'page-students-list',
  templateUrl: 'students-list.html',
  styleUrls: ['students-list.scss']
})
export class StudentsListPage implements OnInit {
  token = '';
  batch: any;
  date: any;
  student: any = [
    { absentee: false, attendance: { forenoon: false, afternoon: false, reason: '' } },
  ];
  students: any = [];
  studentsList: any = [];
  studentRecords: any[] = [];
  absentCount = 0;
  count = 0;
  key: string;
  completelyEligible: boolean = true;
  isSaveInProgress: boolean = false;
  sortType: any = { name: 'Name', value: 0 }
  constructor(
    private event: EventsService,
    public navCtrl: NavController,
    public attendance: Attendance,
    public userService: User,
    private storage: Storage,
    private commonService: CommonService,
    private router: Router
  ) {
    this.storage.get('attendance_sort_type').then(val => {
      if (val)
        this.sortType = val
    })
    this.commonService.presentLoading('Loading students');
    this.batch = this.router.getCurrentNavigation().extras.state.batch;
    this.date = this.router.getCurrentNavigation().extras.state.date;
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          if (id) {
            this.loadAttendance();
          } else {
            this.commonService.presentAlert('No data');
          }
        });

      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  ngOnInit() {

  }
  ionViewWillLeave() {
    this.storage.set('attendance_sort_type', this.sortType);
  }
  sortStudentsBy(option) {
    console.log(option)
    this.sortType = option;
    if (option.value === 0) {
      this.students.sort(studentAbsenteeListModelByName);
    }
    else {
      this.students.sort(studentAbsenteeListModelByRollNo)
    }
  }
  loadAttendance() {
    this.attendance.loadAttendanceOn(this.token, this.batch.id, this.date).subscribe(
      (response) => {
        this.commonService.dismissloading();
        const apiResponse: any = response;
        if (apiResponse.success === true) {
          const temp = new ReportStudentAbsenteeListModel(apiResponse);
          console.log(apiResponse);
          console.log(temp);
          this.students = temp.students;
          for (this.student of this.students) {
            if (this.student.eligible) this.completelyEligible = false;
            if (this.student.absent === true) {
              this.absentCount = this.absentCount + 1;
            } else {
              this.student.attendance = { forenoon: false, afternoon: false, reason: '' };
            }
          }
          this.studentsList = this.students;
          this.sortStudentsBy(this.sortType);
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  markAbsence(student) {
    console.log(student);
    student.absent = true;
    student.attendance = { forenoon: true, afternoon: true, reason: '' };
    this.absentCount = this.absentCount + 1;
  }
  markPresent(student) {
    console.log(student);
    student.absent = false;
    student.attendance = { forenoon: false, afternoon: false, reason: '' };
    this.absentCount = this.absentCount - 1;
  }
  saveAttendance() {
    if (this.isSaveInProgress) return;
    this.commonService.presentLoading('saving');
    this.isSaveInProgress = true;
    const attendanceRecorded = { attendance: [], batch_id: '', date: '' };
    for (this.student of this.students) {
      if (this.student.absent === true) {
        if (
          this.student.attendance.forenoon === false && this.student.attendance.afternoon === false
        ) {
          const studentRecord = { student_id: this.student.studentId, absent: false };
          attendanceRecorded.attendance.push(studentRecord);
        } else {
          const studentRecord = {
            student_id: this.student.studentId,
            reason: this.student.attendance.reason,
            forenoon: this.student.attendance.forenoon,
            afternoon: this.student.attendance.afternoon,
          };
          attendanceRecorded.attendance.push(studentRecord);
        }
      } else {
        const studentRecord = { student_id: this.student.studentId, absent: false };
        attendanceRecorded.attendance.push(studentRecord);
      }
    }
    attendanceRecorded.batch_id = this.batch.id;
    attendanceRecorded.date = this.date;
    this.attendance.markAttendance(this.token, attendanceRecorded).subscribe(
      (response) => {
        const apiResponse: any = response;
        if (apiResponse.success === true) {
          this.isSaveInProgress = false;
          this.router.navigateByUrl('/report-students-list', {
            state: {
              route: true,
              batch: this.batch,
              day: this.date,
              totalAbsentees: this.absentCount
            }
          })
        }
        this.commonService.dismissloading();
      },
      (err) => {
        this.isSaveInProgress = false;
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }

  removeAbsence(student) {
    student.present = true;
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad DailyAbsenteesDetails');
  }

  getItems(ev: any) {
    // Reset items back to all of the items
    // this.initializeItems();
    this.key = ev.target.value;
    // set val to the value of the searchbar
    const val = ev.target.value;
    console.log(val);
    // if the value is an empty string don't filter the items
    if (val && val.trim() !== '') {
      this.students = this.students.filter((data) => {
        return (data.studentName.toLowerCase().indexOf(val.toLowerCase()) > -1);
      });
    } else {
      this.students = this.studentsList;
    }
  }


}
