import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ComponentsModule } from 'src/components/components.module';
import { PipesModule } from 'src/pipes/pipes.module';
import { SubjectAbsenteesListPage } from './subject-absentees-list';
import { SubjectAbsenteesListPageRoutingModule } from './subject-absentees-list-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        SubjectAbsenteesListPageRoutingModule,
        ComponentsModule
    ],
    declarations: [SubjectAbsenteesListPage]
})



export class SubjectAbsenteesListPageModule { }
