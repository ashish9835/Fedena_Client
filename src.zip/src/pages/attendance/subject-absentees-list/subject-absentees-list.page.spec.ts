import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { SubjectAbsenteesListPage } from './subject-absentees-list';

describe('SubjectAbsenteesListPage', () => {
  let component: SubjectAbsenteesListPage;
  let fixture: ComponentFixture<SubjectAbsenteesListPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SubjectAbsenteesListPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SubjectAbsenteesListPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
