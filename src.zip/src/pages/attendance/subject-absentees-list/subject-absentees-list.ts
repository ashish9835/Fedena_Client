import { Storage } from '@ionic/storage';
import { Component, OnInit } from '@angular/core';
import { StudentAbsenteeListModel, studentAbsenteeListModelByName, studentAbsenteeListModelByRollNo } from 'src/models/my-class/studentAbsenteeList';
import { EventsService } from 'src/providers/events/events.service';
import { NavController, PopoverController } from '@ionic/angular';
import { Attendance } from 'src/providers/attendance';
import { User } from 'src/providers/user';
import { CommonService } from 'src/providers/common/common.service';
import { Router } from '@angular/router';


@Component({
  selector: 'page-subject-absentees-list',
  templateUrl: 'subject-absentees-list.html',
  styleUrls: ['subject-absentees-list.scss']
})
export class SubjectAbsenteesListPage implements OnInit {
  token: any;
  classTimingId: any;
  subjectId: any;
  batch: any;
  batchId: any;
  batchname: any;
  // datename:any
  userId: any;
  student: any = [{ absent: false, reason: '' }];
  students: StudentAbsenteeListModel[] = [];
  date: any;
  data: any;
  absentCount = 0;
  studentsList: any = [];
  key: string;
  completelyEligible: boolean = true;
  isSaveInProgress: boolean = false;
  sortType: any = { name: 'Name', value: 0 }
  constructor(
    private event: EventsService,
    public navCtrl: NavController,
    public attendance: Attendance,
    public userService: User,
    public popover: PopoverController,
    public storage: Storage,
    public commonService: CommonService,
    public router: Router
  ) {
    this.storage.get('attendance_sort_type').then(val => {
      console.log("this was save .dd")
      console.log(val)
      if (val)
        this.sortType = val;
    })
    this.commonService.presentLoading('Loading students');
    this.batch = this.router.getCurrentNavigation().extras.state.batch;
    this.batchId = this.batch.id;
    this.batchname = this.batch.name;
    // this.datename= this.date.name
    this.subjectId = this.router.getCurrentNavigation().extras.state.subjectId;
    this.classTimingId = this.router.getCurrentNavigation().extras.state.classTimingId;
    console.log(this.subjectId);
    this.date = this.router.getCurrentNavigation().extras.state.date;
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          if (id) {
            this.userId = id;
            this.getStudentAttendance();
          } else {
            this.commonService.presentAlert('Account not found');
          }
        });

      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  ngOnInit() {

  }
  sortStudentsBy(option) {
    console.log(option)
    this.sortType = option;
    if (option.value === 0) {
      this.students.sort(studentAbsenteeListModelByName);
    }
    else {
      this.students.sort(studentAbsenteeListModelByRollNo)
    }
  }
  ionViewWillLeave() {
    this.storage.set('attendance_sort_type', this.sortType)
    this.event.publish('dismiss:overlay', {})
  }
  presentOptions(myEvent) {
    // const popover = this.popover.create('MessageOptions', { id: '34', recipient_id: 324, token: this.token, messageType: 324 });
    // popover.present({
    //   ev: myEvent,
    // });
    // this.event.subscribe('dismiss:overlay', () => {
    //   if (popover)
    //     popover.dismiss();
    // })
  }
  getStudentAttendance() {
    this.attendance.loadPeriodAttendanceOn(
      this.token,
      this.batchId,
      this.date,
      this.subjectId,
      this.classTimingId,
    ).subscribe(
      (response) => {
        this.commonService.dismissloading();
        const apiResponse: any = response;
        console.log(response);
        if (apiResponse.success === true) {
          apiResponse.students.forEach(i => {
            this.students.push(new StudentAbsenteeListModel(i));
          });
          // this.students = apiResponse.students;
          this.batchname = apiResponse.batch_name;
          for (this.student of this.students) {
            if (this.student.eligible) this.completelyEligible = false;
            if (this.student.absent) {
              this.student.reason = this.student.attendance.reason;
              this.absentCount = this.absentCount + 1;
            }
          }
          this.studentsList = this.students;
          console.log(this.students);
          this.sortStudentsBy(this.sortType);

        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      },
    );
  }
  markAbsence(student) {
    console.log(student);
    student.absent = true;
    student.reason = '';
    this.absentCount = this.absentCount + 1;
  }
  markPresent(student) {
    console.log(student);
    student.absent = false;
    student.reason = '';
    this.absentCount = this.absentCount - 1;
  }
  saveAttendance() {
    if (this.isSaveInProgress) return;
    this.commonService.presentLoading('saving');
    this.isSaveInProgress = true;
    const attendanceRecorded = {
      attendance: [], employee_id: '', class_timing_id: '', subject_id: '', batch_id: '', date: '',
    };
    for (this.student of this.students) {
      if (this.student.absent === true) {
        const studentRecord = { student_id: this.student.studentId, reason: this.student.reason };
        attendanceRecorded.attendance.push(studentRecord);
      } else {
        const studentRecord = { student_id: this.student.studentId, absent: false };
        attendanceRecorded.attendance.push(studentRecord);
      }
    }
    attendanceRecorded.employee_id = this.userId;
    attendanceRecorded.class_timing_id = this.classTimingId;
    attendanceRecorded.subject_id = this.subjectId;
    attendanceRecorded.batch_id = this.batchId;
    attendanceRecorded.date = this.date;
    this.attendance.markAttendance(this.token, attendanceRecorded).subscribe(
      (response) => {
        const apiResponse: any = response;
        if (apiResponse.success === true) {
          this.router.navigateByUrl('/report-subject-students-list', {
            state: {
              route: true,
              batch: this.batch,
              subjectId: this.subjectId,
              classTimingId: this.classTimingId,
              date: this.date,
            }
          });
          this.isSaveInProgress = false;
          console.log(apiResponse);
        }
        this.commonService.dismissloading();
      },
      (err) => {
        this.isSaveInProgress = false;
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      },
    );
  }
  getItems(ev: any) {
    // Reset items back to all of the items
    // this.initializeItems();
    this.key = ev.target.value;
    // set val to the value of the searchbar
    const val = ev.target.value;
    console.log(val);
    // if the value is an empty string don't filter the items
    if (val && val.trim() !== '') {
      this.students = this.students.filter((data) => {
        console.log
        return (data.studentName.toLowerCase().indexOf(val.toLowerCase()) > -1);
      });
    } else {
      this.students = this.studentsList;
    }
  }


}
