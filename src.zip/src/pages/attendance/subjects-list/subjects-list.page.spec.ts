import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { SubjectsListPage } from './subjects-list';

describe('SubjectsListPage', () => {
  let component: SubjectsListPage;
  let fixture: ComponentFixture<SubjectsListPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SubjectsListPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SubjectsListPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
