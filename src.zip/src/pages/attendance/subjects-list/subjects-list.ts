import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { ClassPeriodModel } from 'src/models/my-class/classPeriod';
import { Attendance } from 'src/providers/attendance';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-subjects-list',
  templateUrl: 'subjects-list.html',
  styleUrls: ['subjects-list.scss']
})
export class SubjectsListPage implements OnInit {
  token = '';
  userid = '';
  periods: any = [];
  batch: any;
  date: any;
  employeeId: any;
  constructor(
    private event: EventsService,
    public navCtrl: NavController,
    public attendance: Attendance,
    public userService: User,
    public commonService: CommonService,
    public router: Router
  ) {
    this.commonService.presentLoading('Loading subjects');
    this.batch = this.router.getCurrentNavigation().extras.state.batch;
    this.date = this.router.getCurrentNavigation().extras.state.date;
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          if (id) {
            this.userid = id;
            this.loadPeriods();
          } else {
            this.commonService.presentAlert('Account not found');
          }
        });
        this.userService.getUser().then((profile) => {
          if (profile) {
            this.employeeId = profile.id;
            console.log('The Current Employee Id is:', this.employeeId);
          } else {
            this.commonService.presentAlert('Account not found');
          }
        });
      } else {
        this.commonService.presentAlert('Session expired');
      }

    });
  }
  ngOnInit() {

  }
  viewDetails(batchId, subjectId, classTimingId, date) {
    this.router.navigateByUrl('/subject-absentees-list', {
      state: {
        'subjectId': subjectId,
        'classTimingId': classTimingId,
        'date': date,
        'batch': this.batch,
      }
    })
  }
  loadPeriods() {
    this.attendance.loadPeriodsOnDate(this.token, this.batch.id, this.date).subscribe(
      (response) => {
        this.commonService.dismissloading();
        console.log(response);
        const apiResponse: any = response;
        if (apiResponse.success === true) {
          apiResponse.periods.forEach(i => {
            this.periods.push(new ClassPeriodModel(i));
          });
          console.log(this.periods);
          this.date = apiResponse.date;
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad SubjectsListPage');
  }

}
