import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BatchSubjectsPage } from './batch-subjects';


const routes: Routes = [
  {
    path: '',
    component: BatchSubjectsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BatchSubjectsPageRoutingModule { }
