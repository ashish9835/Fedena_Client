import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { BatchSubjectsPage } from './batch-subjects';
import { BatchSubjectsPageRoutingModule } from './batch-subjects-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        BatchSubjectsPageRoutingModule
    ],
    declarations: [BatchSubjectsPage]
})



export class BatchSubjectsPageModule { }
