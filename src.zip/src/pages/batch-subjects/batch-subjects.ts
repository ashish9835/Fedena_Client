import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { SubjectModel } from 'src/models/my-class/batchAttendance';
import { Batch } from 'src/providers/batch';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-batch-subjects',
  templateUrl: 'batch-subjects.html',
  styleUrls: ['batch-subjects.scss']
})
export class BatchSubjectsPage implements OnInit {

  batch = [];
  subjects = [];
  batchid = '0';
  // tslint:disable-next-line:prefer-array-literal
  data: Array<{ name: string, class: string, img: string, attendance: string }> = [];
  token = '';
  userid = '';
  constructor(
    private event: EventsService,
    public navCtrl: NavController,
    private batchService: Batch,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.commonService.presentLoading('Loading subjects');
    this.batch = this.router.getCurrentNavigation().extras.state.batch;
    console.log(this.batch);
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.batchid = this.batch['id'];
        this.loadSubjects();

      } else {
        this.commonService.presentAlert('Session expired');
      }
    });

  }
  ngOnInit() {

  }
  loadSubjects() {
    this.batchService.loadBatchSubjects(this.token, this.batchid).subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        console.log(response);
        if (response.success === true) {
          response.subjects.forEach(i => {
            this.subjects.push(new SubjectModel(i));
          });
          console.log(this.subjects);
          // this.subjects = response.subjects;
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );

  }
}
