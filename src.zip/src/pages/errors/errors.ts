import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'page-errors',
  templateUrl: 'errors.html',
  styleUrls: ['errors.scss']
})
export class ErrorsPage implements OnInit {

  constructor(private menu: MenuController) { }
  ngOnInit() { }
  ionViewDidEnter() {
    // the root left menu should be disabled on the tutorial page
    this.menu.enable(false);
  }

  ionViewWillLeave() {
    // enable the root left menu when leaving the tutorial page
    this.menu.enable(true);
  }
}

