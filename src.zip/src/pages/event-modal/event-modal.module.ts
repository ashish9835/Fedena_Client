import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { EventModalPage } from './event-modal';
import { EventModalPageRoutingModule } from './event-modal-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        EventModalPageRoutingModule
    ],
    declarations: [EventModalPage]
})



export class EventModalPageModule { }
