import { Component, Input, OnInit } from '@angular/core';
import { ModalController, NavController } from '@ionic/angular';

@Component({
  selector: 'page-event-modal',
  templateUrl: 'event-modal.html',
  styleUrls: ['event-modal.scss']
})
export class EventModalPage implements OnInit {
  startDate: any = '';
  endDate: any = '';
  @Input() event: any;
  constructor(public navCtrl: NavController,
    public modalctrl: ModalController) {
  }
  ngOnInit() {

  }
  ionViewDidEnter() {
    console.log(this.event, 'event');
    this.startDate = this.event.event.data.startDate;
    console.log(this.startDate);
    this.startDate = this.startDate.substring(0, this.startDate.indexOf('T'));
    console.log(this.startDate);
    this.endDate = this.event.event.data.endDate;
    this.endDate = this.endDate.substring(0, this.endDate.indexOf('T'));
    console.log('ionViewDidLoad EventModal');
  }
  dismiss() {
    this.modalctrl.dismiss();
  }

}
