import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavController, Platform } from '@ionic/angular';
import { EventsModel } from 'src/models/events/events';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { MyEvents } from 'src/providers/my-events';
import { User } from 'src/providers/user';
import { EventModalPage } from '../event-modal/event-modal';

class DateRange {
  pastDate: any;
  futureDate: any;
  constructor(pastDate, futureDate) {
    this.pastDate = pastDate;
    this.futureDate = futureDate;
  }
}
@Component({
  selector: 'page-events',
  templateUrl: 'events.html',
  styleUrls: ['events.scss']
})
export class EventsPage implements OnInit {
  type: string = 'all';
  today = new Date();
  filterdate = this.today.toISOString();
  month = 10;
  year = 2017;
  allevents = [];
  alleventsBackup = [];
  events: any = [];
  examEvents: any = [];
  holidayEvents: any = [];
  feesEvents: any = [];
  holidayevents = [];
  examevents = [];
  feesevents = [];
  token = '';
  disableInfiniteScroll: boolean = true;
  employee = true;
  previousMonth: number = 0;
  previousYear: number = 0;
  nextMonth: number = 0;
  nextYear: number = 0;
  selected: string = 'all';
  examEventsStatus: boolean;
  feesEventsStatus: boolean;
  holidayEventsStatus: boolean;
  pastDate: any;
  futureDate: any;
  AllEventDateRange: DateRange;
  ExamsEventDateRange: DateRange;
  FeesEventDateRange: DateRange;
  HolidaysEventDateRange: DateRange;
  direct: boolean = true;
  // app: any;
  constructor(
    public platform: Platform,
    private event: EventsService,
    public navCtrl: NavController,
    private modalCtrl: ModalController,
    private eventService: MyEvents,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.init();
    this.event.subscribe('events_reload', (data) => {
      this.init();
    });
  }
  ngOnInit() {

  }
  private init() {
    this.allevents = [];
    this.examevents = [];
    this.feesevents = [];
    this.holidayevents = [];
    this.selected = 'all';
    this.type = 'all';
    this.month = this.today.getMonth() + 1;
    this.year = this.today.getFullYear();
    this.previousMonth = this.month;
    this.previousYear = this.year;
    this.nextMonth = this.month;
    this.nextYear = this.year;
    if (this.router.getCurrentNavigation().extras.state) this.direct = (this.router.getCurrentNavigation().extras.state.route === true) ? false : true;
    this.commonService.presentLoading('Loading events')
    this.userService.getAccessToken().then((value) => {
      console.log(value);
      if (value) {
        this.token = value;
        this.userService.getRole().then((role) => {
          console.log(role);
          if (role === 'employee') this.employee = true;
          else this.employee = false;
          this.loadEvents('all');
          this.loadEvents('exams');
          this.loadEvents('holidays');
          this.loadEvents('fees');
        });
      } else {
        this.commonService.presentAlert('Session expired')
      }
    });
  }

  compare(date1, date2) {
    const tempDate1 = new Date(date1);
    const tempDate2 = new Date(date2);
    if (tempDate1.getMonth() === tempDate2.getMonth() && tempDate1.getFullYear() === tempDate2.getFullYear()) return true;
    else return false;
  }
  doInfinitePrev(infiniteScroll) {
    const fetch = true;
    if (fetch) {
      console.log('Fetching past events');
      setTimeout(() => {
        this.AllEventDateRange.pastDate.setDate(this.AllEventDateRange.pastDate.getDate() - 1);
        this.ExamsEventDateRange.pastDate.setDate(this.ExamsEventDateRange.pastDate.getDate() - 1);
        this.FeesEventDateRange.pastDate.setDate(this.FeesEventDateRange.pastDate.getDate() - 1);
        this.HolidaysEventDateRange.pastDate.setDate(this.HolidaysEventDateRange.pastDate.getDate() - 1);

        this.eventService.loadEvents(this.token, 'all', this.AllEventDateRange.pastDate.getFullYear() + '-' + (this.AllEventDateRange.pastDate.getMonth() + 1) + '-' + this.AllEventDateRange.pastDate.getDate(), 'past',).subscribe(eventResponseHandler.bind(this), errorHandler.bind(this));
        this.eventService.loadEvents(this.token, 'exams', this.ExamsEventDateRange.pastDate.getFullYear() + '-' + (this.ExamsEventDateRange.pastDate.getMonth() + 1) + '-' + this.ExamsEventDateRange.pastDate.getDate(), 'past',).subscribe(eventResponseHandler.bind(this), errorHandler.bind(this));
        this.eventService.loadEvents(this.token, 'holidays', this.HolidaysEventDateRange.pastDate.getFullYear() + '-' + (this.HolidaysEventDateRange.pastDate.getMonth() + 1) + '-' + this.HolidaysEventDateRange.pastDate.getDate(), 'past',).subscribe(eventResponseHandler.bind(this), errorHandler.bind(this));
        this.eventService.loadEvents(this.token, 'fees', this.FeesEventDateRange.pastDate.getFullYear() + '-' + (this.FeesEventDateRange.pastDate.getMonth() + 1) + '-' + this.FeesEventDateRange.pastDate.getDate(), 'past',).subscribe(eventResponseHandler.bind(this), errorHandler.bind(this));

        infiniteScroll.target.complete();
      }, 3000);
    } else {
      infiniteScroll.target.complete();
    }

    let errorHandler = (err) => {
      this.commonService.dismissloading();
      console.log(err.status);
      if (err.status === 500) {
        this.userService.errorHandler();
      }
      if (err.status === 403) {
        this.navCtrl.setDirection('root');
        this.router.navigateByUrl('/tutorial', { replaceUrl: true });
      }
    }
    let eventResponseHandler = (response: any) => {
      console.log("entered the handler.. . .. . ")
      console.log(this)
      if (response.success === true) {
        if (response.event_type === 'all') {
          this.allevents = [];
          response.events.forEach((i) => {
            this.allevents.push(new EventsModel(i));
          });
          this.events = this.allevents.concat(this.events);
          console.log(this.events);
        }
        if (response.event_type === 'exams') {
          this.examevents = [];
          response.events.forEach((i) => {
            this.examevents.push(new EventsModel(i));
          });
          this.examEvents = this.examevents.concat(this.examEvents);
          console.log(this.examEvents);
        }
        if (response.event_type === 'holidays') {
          this.holidayevents = [];
          response.events.forEach((i) => {

            this.holidayevents.push(new EventsModel(i));
          });
          this.holidayEvents = this.holidayevents.concat(this.holidayEvents);
          console.log(this.holidayEvents);
        }
        if (response.event_type === 'fees') {
          this.feesevents = [];
          response.events.forEach((i) => {
            this.feesevents.push(new EventsModel(i));
          });
          this.feesEvents = this.feesevents.concat(this.feesEvents);
          console.log(this.feesEvents);
        }
        (this[this.selected.replace(/^./g, (v) => { return v.toUpperCase() }) + 'EventDateRange'] as DateRange) = new DateRange(new Date(response.start_date), new Date(response.last_date));


      }
    }
  }
  doInfinite(infiniteScroll) {
    console.log('Fetching future events');
    this.selected = this.type;
    setTimeout(() => {
      infiniteScroll.target.complete();
      let eventtype = this.selected.replace(/^./g, (v) => { return v.toUpperCase() });
      this.futureDate = (this[eventtype + 'EventDateRange'] as DateRange).futureDate;
      console.log(this.futureDate)
      this.futureDate.setDate(this.futureDate.getDate() + 1);
      this.eventService.loadEvents(
        this.token,
        this.selected,
        // tslint:disable-next-line:max-line-length
        this.futureDate.getFullYear() + '-' + (this.futureDate.getMonth() + 1) + '-' + this.futureDate.getDate(),
        'future')
        .subscribe(
          (response: any) => {
            if (response.success === true) {
              if (this.selected === 'all') {
                this.allevents = [];
                response.events.forEach((i) => {
                  this.allevents.push(new EventsModel(i));
                });
                this.events = this.events.concat(this.allevents);
                console.log(this.events);
              }
              if (this.selected === 'exams') {
                this.examevents = [];
                response.events.forEach((i) => {
                  this.examevents.push(new EventsModel(i));
                });
                this.examEvents = this.examEvents.concat(this.examevents);
                console.log(this.examEvents);
              }
              if (this.selected === 'holidays') {
                this.holidayevents = [];
                response.events.forEach((i) => {
                  this.holidayevents.push(new EventsModel(i));
                });
                this.holidayEvents = this.holidayEvents.concat(this.holidayevents);
                console.log(this.holidayEvents);
              }
              if (this.selected === 'fees') {
                this.feesevents = [];
                response.events.forEach((i) => {
                  this.feesevents.push(new EventsModel(i));
                });
                this.feesEvents = this.feesEvents.concat(this.feesevents);
                console.log(this.feesEvents);
              }
              (this[eventtype + 'EventDateRange'] as DateRange) = new DateRange(new Date(response.start_date), new Date(response.last_date));
            }
          },
          (err) => {
            this.commonService.dismissloading();
            console.log(err.status);
            if (err.status === 500) {
              this.userService.errorHandler();
            }
            if (err.status === 403) {
              this.navCtrl.setDirection('root');
              this.router.navigateByUrl('/tutorial', { replaceUrl: true });
            }
          },
        );
    }, 3000);
  }
  loadEvents(type: string) {
    this.selected = type;
    this.eventService.loadEvents(this.token, type, '', '').subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        if (response.success === true) {

          if (type === 'all') {
            this.events = [];
            response.events.forEach((i) => {
              this.events.push(new EventsModel(i));
            });
            console.log(this.events);
          }
          if (type === 'exams') {
            this.examEvents = [];
            response.events.forEach((i) => {
              this.examEvents.push(new EventsModel(i));
            });
            console.log(this.examEvents);
          }
          if (type === 'holidays') {
            this.holidayEvents = [];
            response.events.forEach((i) => {
              this.holidayEvents.push(new EventsModel(i));
            });
            console.log(this.holidayEvents);
          }
          if (type === 'fees') {
            this.feesEvents = [];
            response.events.forEach((i) => {
              this.feesEvents.push(new EventsModel(i));
            });
            console.log(this.feesEvents);
          }
          if (response.events.length > 0) this.disableInfiniteScroll = false;

          let eventtype = type.replace(/^./g, (v) => { return v.toUpperCase() });
          (this[eventtype + 'EventDateRange'] as DateRange) = new DateRange(new Date(response.start_date), new Date(response.last_date));

          // this.pastDate = new Date(response.start_date);
          // this.futureDate = new Date(response.last_date);
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  loadAllEvents(type) {
    this.eventService.loadEvents(this.token, type, '', '').subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        if (response.success === true) {
          response.events.forEach((i) => {
            this.events.push(new EventsModel(i));
          });
          console.log(this.events);
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );

  }
  loadPrevEvents(month, year) {

  }
  loadNextEvents(month, year) {

  }
  changeDate() {
    const selectedDate = new Date(this.filterdate);
    this.month = selectedDate.getMonth() + 1;
    this.year = selectedDate.getFullYear();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad Events');

  }

  async viewEventsDetails(event) {
    const modal = await this.modalCtrl.create({
      component: EventModalPage,
      componentProps: {
        event: { event }
      }
    });
    return await modal.present();
  }

  loadPage() {
    this.init();
  }
}
