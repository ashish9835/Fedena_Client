import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExamReportsPage } from './exam-reports';


const routes: Routes = [
  {
    path: '',
    component: ExamReportsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ExamReportsPageRoutingModule {}
