import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { ExamReportsPage } from './exam-reports';
import { ExamReportsPageRoutingModule } from './exam-reports-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ExamReportsPageRoutingModule,
    PipesModule
  ],
  declarations: [ExamReportsPage]
})
export class ExamReportsPageModule { }
