import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActionSheetController, NavController, Platform, ToastController } from '@ionic/angular';
import { CommonService } from 'src/providers/common/common.service';
import { DownloadOptions, DownloadProvider } from 'src/providers/downloader';
import { EventsService } from 'src/providers/events/events.service';
import { ExamReports } from 'src/providers/exam-reports';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-exam-reports',
  templateUrl: 'exam-reports.html',
  styleUrls: ['exam-reports.scss']
})
export class ExamReportsPage implements OnInit {
  token = '';
  studentId = '';
  currentBatch = '';
  filename = '';
  name = '';
  currentBatchId: number;
  batches = [];
  reports = [];
  overAllReport = [];
  testString: string;
  constructor(public actionSheetCtrl: ActionSheetController,
    private downloader: DownloadProvider,
    private toastCtrl: ToastController,
    private examService: ExamReports,
    public navCtrl: NavController,
    public platform: Platform,
    private event: EventsService,
    private userService: User,
    private router: Router,
    private commonService: CommonService) {
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then(
          (id) => {
            this.studentId = id;
            this.userService.getUser().then((value) => {
              this.name = value.fullName;
            });
          });
      }
      this.loadPage();
    });
  }
  ngOnInit() { }
  async presentActionSheet() {
    const actionSheet = await this.actionSheetCtrl.create({
      header: 'Select Batch',
      buttons: this.createButtons(),
    });

    actionSheet.present();
  }
  loadBatch(type) {
    console.log(type);
    this.currentBatchId = type;
    this.batches.forEach((i) => {
      if (i.id === this.currentBatchId) {
        this.currentBatch = i.full_name;
      }
    });
    this.loadReport(this.currentBatchId);
  }
  loadPage() {
    this.examService.loadBatches(this.token).subscribe(
      (response: any) => {
        console.log(response);
        this.currentBatch = response.current_batch;
        this.batches = response.student_batches;
        this.currentBatchId = response.current_batch_id;
        this.loadReport(this.currentBatchId);
      },
      (err) => {
        console.log(err);
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      });
  }
  createButtons() {
    const buttons = [];
    this.batches.forEach((i) => {
      const button = {
        text: i.full_name,
        handler: () => {
          this.loadBatch(i.id);
          return true;
        },
      };
      buttons.push(button);
    });
    return buttons;
  }

  loadReport(batchId) {
    this.examService.loadReports(this.token, batchId).subscribe(
      (response: any) => {
        console.log(response);
        this.reports = response.exam_reports;
        this.overAllReport = response.overall_reports;
      },
      (err) => {
        console.log(err);
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      });
  }
  openPDF(pdf, filename) {
    let options: DownloadOptions = new DownloadOptions();
    options.fileName = filename + '.pdf';
    options.mimeType = 'application/pdf';
    options.url = pdf.url;
    options.headers = {
      Cookie: '_fedena_session_=' + pdf.session_id,
    };
    if (this.platform.is('ios')) this.commonService.presentLoading('Downloading report');
    if (this.platform.is('android')) this.commonService.presentToast('toast.downloading', 3000);
    this.downloader.download(options).then(destn => {
      console.log("downloaded")
      if (this.platform.is('ios')) this.commonService.dismissloading();
    }).catch(e => {
      if (this.platform.is('ios')) {
        this.commonService.dismissloading();
        this.presentToast(e)
      }
    });
  }

  async presentToast(notification) {
    const toast = await this.toastCtrl.create({
      message: notification,
      duration: 2000,
      position: 'top',
    });
    toast.present();
  }
}
