import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { FeesDetailsPage } from './fees-details';
import { FeesDetailsPageRoutingModule } from './fees-details-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FeesDetailsPageRoutingModule,
    PipesModule
  ],
  declarations: [FeesDetailsPage]
})
export class FeesDetailsPageModule { }
