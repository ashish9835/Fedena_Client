import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { NavController, Platform, ToastController } from '@ionic/angular';
import { DownloadOptions, DownloadProvider } from 'src/providers/downloader';
import { School } from 'src/providers/school';
import { EventsService } from 'src/providers/events/events.service';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser/ngx';
import { Fees } from 'src/providers/fees';
import { User } from 'src/providers/user';
import { CommonService } from 'src/providers/common/common.service';
import { Router } from '@angular/router';
import { File } from '@ionic-native/file/ngx';
import { FeeDetailModel } from 'src/models/fees/feeDetail';
@Component({
  selector: 'page-fees-details',
  templateUrl: 'fees-details.html',
  styleUrls: ['fees-details.scss']
})
export class FeesDetailsPage implements OnInit {

  data = [];
  discounts = [];
  details: any = [];
  fees: any = {};
  name = '';
  paid = true;
  totalAmountPaid = '';
  totalAmountToPay = '';
  totalDiscount: number;
  totalFees = '';
  totalFine: number;
  totalTax: number;
  particulars = [];
  paymentReceipts = [];
  fines = [];
  token = '';
  dueAmount = 0;
  dueDate = '';
  dueDays = '';
  currency: any;
  feesType = 'general';
  collectionId = '0';
  payLink = '';
  paymentDetails: any;
  paymentEnabled: boolean;
  studentId: any;
  redirectUrl = 'null';
  hideFines: boolean = true;
  hideDiscounts: boolean = true;
  hideTax: boolean = true;
  studentName: string;
  testString: string;
  action: string;
  summary: any;
  taxes = [];
  amountToPay: number = 0;
  partialPaymentEnabled: boolean;
  ERROR_PAYMENT_AMOUNT_LIMIT: string = "Please enter amount less than or equal to the required amount.";
  ERROR_EMPTY_INPUT: string = "Please enter an amount.";
  ALERT_NO_PAYMENT_REQUIRED: string = 'no payment required';
  ALERT_NOT_AVAILABLE: string = 'not available';

  constructor(
    private toastCtrl: ToastController,
    private downloader: DownloadProvider,
    private school: School,
    private event: EventsService,
    private fileOpener: FileOpener,
    private file: File,
    private transfer: FileTransfer,
    public navCtrl: NavController,
    private iab: InAppBrowser,
    public platform: Platform,
    private feesService: Fees,
    private userService: User,
    private translate: TranslateService,
    private commonService: CommonService,
    private router: Router
  ) {
    this.getTranslations();
    this.data = this.router.getCurrentNavigation().extras.state.data;
    this.school.getSchool('currency').then((value) => { this.currency = value; });
    this.action = this.router.getCurrentNavigation().extras.state.action;
    this.collectionId = this.data['collectionId'];
    this.feesType = this.data['type'];
    this.commonService.presentLoading('Loading fee');
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.loadFeeDetails();
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  ngOnInit() {

  }
  //get all the strings translated.
  getTranslations() {
    let keys = [
      'errors.payment_amount_limit',
      'errors.empty_input',
      'alert.no_payment_required',
      'alert.not_available'
    ]
    this.translate.get(keys).subscribe(val => {
      console.log(val)
      this.ERROR_PAYMENT_AMOUNT_LIMIT = val[keys[0]]
      this.ERROR_EMPTY_INPUT = val[keys[1]]
      this.ALERT_NO_PAYMENT_REQUIRED = val[keys[2]]
      this.ALERT_NOT_AVAILABLE = val[keys[3]]
    })
  }

  download(link, filename) {
    let url = encodeURI(link.url);
    const sessionId = link.sessionId;
    this.commonService.presentAlert('Downloading receipt');
    const fileTransfer: FileTransferObject = this.transfer.create();

    if (this.platform.is('ios')) {
      fileTransfer.download(url, this.file.documentsDirectory + filename + '.pdf',
        false,
        {
          headers: {
            Cookie: '_fedena_session_=' + sessionId,
          },
        },
      ).then((entry) => {
        this.testString = entry.toURL();
        url = entry.toURL();
        this.commonService.dismissloading();
        this.fileOpener.open(entry.toURL(), 'application/pdf')
          .then(() => console.log('File is opened'))
          .catch(e => console.log('Error openening file', e));
        console.log('download complete: ' + entry.toURL());
      }, (error) => {
        this.commonService.presentAlert('Download failed');
        this.commonService.dismissloading();
      });

    } else if (this.platform.is('android')) {

      fileTransfer.download(url, this.file.externalDataDirectory + filename + '.pdf',
        false,
        {
          headers: {
            Cookie: '_fedena_session_=' + sessionId,
          },
        },
      ).then((entry) => {
        this.testString = entry.toURL();
        url = entry.toURL();
        this.commonService.dismissloading();
        this.fileOpener.open(entry.toURL(), 'application/pdf')
          .then(() => console.log('File is opened'))
          .catch(e => console.log('Error openening file', e));
        console.log('download complete: ' + entry.toURL());
      }, (error) => {
        this.commonService.presentAlert('Download failed');
        this.commonService.dismissloading();
      });

    }
  }
  openPDF(pdf, filename) {

    let options: DownloadOptions = new DownloadOptions();
    options.fileName = filename + '.pdf';
    options.mimeType = 'application/pdf';
    options.url = pdf.url;
    options.headers = {
      Cookie: '_fedena_session_=' + pdf.sessionId,
    };
    if (this.platform.is('ios')) this.commonService.presentLoading('Downloading report');
    if (this.platform.is('android')) this.commonService.presentToast('toast.downloading', 3000);
    this.downloader.download(options).then(destn => {
      console.log("downloaded")
      if (this.platform.is('ios')) this.commonService.dismissloading();
    }).catch(e => {
      if (this.platform.is('ios')) {
        this.commonService.dismissloading();
        this.presentToast(e)
      }
    });
  }

  async presentToast(notification) {
    const toast = await this.toastCtrl.create({
      message: notification,
      duration: 2000,
      position: 'top',
    });
    await toast.present();
  }
  ionViewDidLeave() {

  }
  onPaymentAmountChange(value) {
    console.log("value is :");
    console.log(value);
    console.log(value === undefined);
    console.log(value === '');
    console.log(Number.isNaN(value));
    value = Number.parseFloat(value);
    this.amountToPay = Number.isNaN(value) ? 0 : value;
  }
  loadFeeDetails() {
    this.feesService.loadFeeDetails(this.token, this.collectionId, this.feesType).subscribe(
      (response: any) => {
        console.log(response);
        if (response.success === true) {
          this.fees = new FeeDetailModel(response.fees);
          console.log(this.fees);
          this.details = this.fees.feeDetails;
          this.name = this.fees.feeDetails.name;
          this.paid = this.fees.feeDetails.paid;
          this.totalAmountPaid = this.fees.feeDetails.totalAmountPaid;
          this.dueAmount = this.fees.feeDetails.dueAmount;
          this.dueDate = this.fees.feeDetails.dueDate;
          this.dueDays = this.fees.feeDetails.dueDays;
          this.totalAmountToPay = this.fees.feeDetails.totalAmountToPay;
          this.discounts = this.fees.feeDetails.discounts;
          this.particulars = this.fees.feeDetails.particulars;
          this.taxes = this.fees.feeDetails.taxes;
          this.fines = this.fees.feeDetails.fine;
          this.paymentReceipts = this.fees.feeDetails.paymentReceipts;
          this.totalDiscount = this.fees.feeDetails.summary.totalDiscount;
          this.totalFees = this.fees.feeDetails.summary.totalFees;
          this.totalFine = this.fees.feeDetails.summary.totalFine;
          this.totalTax = this.fees.feeDetails.summary.totalTax;
          this.payLink = this.fees.feeDetails.payLink;
          this.paymentDetails = this.fees.onlinePaymentDetails;
          this.summary = this.fees.feeDetails.summaryLink;
          this.paymentEnabled = this.fees.onlinePaymentDetails.paymentEnabled;
          this.partialPaymentEnabled = this.fees.onlinePaymentDetails.partialPaymentEnabled;
          this.currency = this.fees.currencyType;
          this.amountToPay = this.dueAmount;

          this.school.setSchool('currency', this.currency);
          if (this.totalDiscount) {
            this.hideDiscounts = false;
            if (this.totalDiscount === 0) this.hideDiscounts = true;
          }
          if (this.fees.feeDetails.taxEnabled) {
            this.hideTax = false;
          }
          if (this.totalFine) {
            this.hideFines = false;
            if (this.totalFine === 0) this.hideFines = true;
          }
          console.log(this.details);
          this.commonService.dismissloading();
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      },
    );
  }

  launch() {
    this.feesService.loadFeeDetails(this.token, this.collectionId, this.feesType).subscribe(
      async (response: any) => {
        console.log(response);
        if (response.success === true) {
          this.fees = new FeeDetailModel(response.fees);
          this.studentName = this.fees.fullName;
          this.details = this.fees.feeDetails;
          this.name = this.fees.feeDetails.name;
          this.paid = this.fees.feeDetails.paid;
          this.totalAmountPaid = this.fees.feeDetails.totalAmountPaid;
          this.dueAmount = this.fees.feeDetails.dueAmount;
          this.dueDate = this.fees.feeDetails.dueDate;
          this.dueDays = this.fees.feeDetails.dueDays;
          this.totalAmountToPay = this.fees.feeDetails.totalAmountToPay;
          this.discounts = this.fees.feeDetails.discounts;
          this.particulars = this.fees.feeDetails.particulars;
          this.taxes = this.fees.feeDetails.taxes;
          this.fines = this.fees.feeDetails.fine;
          this.paymentReceipts = this.fees.feeDetails.paymentReceipts;
          this.totalDiscount = this.fees.feeDetails.summary.totalDiscount;
          this.totalFees = this.fees.feeDetails.summary.totalFees;
          this.totalFine = this.fees.feeDetails.summary.totalFine;
          this.totalTax = this.fees.feeDetails.summary.totalTax;
          this.payLink = this.fees.feeDetails.payLink;
          this.paymentDetails = this.fees.onlinePaymentDetails;
          this.currency = this.fees.currencyType;
          this.school.setSchool('currency', this.currency);
          if (this.totalDiscount) {
            this.hideDiscounts = false;
            if (this.totalDiscount === 0) this.hideDiscounts = true;
          }
          if (this.totalFine) {
            this.hideFines = false;
            if (this.totalFine === 0) this.hideFines = true;
          }
          if (this.fees.feeDetails.taxEnabled) {
            this.hideTax = false;
          }
          console.log(this.details);
          console.log(this.paymentDetails);
          if (this.paymentDetails.paymentEnabled) {
            if (this.paymentDetails.paymentEnabled) {
              console.log(this.partialPaymentEnabled)
              console.log(this.amountToPay)
              console.log(this.dueAmount)
              console.log(this.partialPaymentEnabled && (this.amountToPay > this.dueAmount))
              if (this.partialPaymentEnabled && (this.amountToPay > this.dueAmount)) {
                alert(this.ERROR_PAYMENT_AMOUNT_LIMIT)
                this.amountToPay = this.dueAmount;
                return;
              }
              if (this.partialPaymentEnabled && this.amountToPay == 0) {
                alert(this.ERROR_EMPTY_INPUT)
                return;
              }
              console.log(this.paymentDetails.paymentUrl)
              if (this.partialPaymentEnabled)
                this.paymentDetails.paymentUrl = this.paymentDetails.paymentUrl
                  .replace(/(\%255Bamount\%255D\%3D)([\.|0-9]+)(\%26)/,
                    (matche, $1, $2, $3) => {
                      console.log($1 + '56' + $3);
                      return $1 + this.amountToPay + $3;
                    })
              console.log(this.paymentDetails.paymentUrl)
              let iosIabOptions: InAppBrowserOptions = {
                usewkwebview: 'yes',
                location: 'no',
                clearcache: 'yes',
                clearsessioncache: 'yes',
                toolbar: 'yes'
              }
              let androidIabOptions: InAppBrowserOptions = {
                location: 'no',
                clearcache: 'yes',
                clearsessioncache: 'yes'
              }
              let options = this.platform.is('ios') ? iosIabOptions : androidIabOptions;
              const browser = this.iab.create(
                this.paymentDetails.paymentUrl, '_blank', options,
              );
              browser.on('loadstart').subscribe((data: any) => {
                const substring = '/online_payments/complete_payment';
                this.redirectUrl = data.url;
                if (data.url.includes(substring)) {
                  browser.close();
                  this.router.navigateByUrl('/transaction-details', {
                    state: {
                      'url': data.url, 'studentName': this.studentName, 'feeName': this.name, 'feeAmount': this.amountToPay,
                    }
                  })

                }
                console.log(`The payment response is:`, data);
              });
            } else {
              alert(this.ALERT_NO_PAYMENT_REQUIRED);
            }
          } else {
            alert(this.ALERT_NOT_AVAILABLE);
          }
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      },
    );

  }
}
