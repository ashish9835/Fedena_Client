import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { NavController, Platform } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-transaction-details',
  templateUrl: 'transaction-details.html',
  styleUrls: ['transaction-details.scss']
})
export class TransactionDetailsPage implements OnInit {
  token = '';
  url: any;
  collectionType: any;
  feeCollectionId: any;
  studentId: any;
  transactionId: any;
  transactionStatus: any;
  reason: any;
  studentName: any;
  feeName: any;
  feeAmount: any;
  constructor(
    private translate: TranslateService,
    private event: EventsService,
    public navCtrl: NavController,
    private iab: InAppBrowser,
    public platform: Platform,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.url = this.router.getCurrentNavigation().extras.state.url;
        this.studentName = this.router.getCurrentNavigation().extras.state.studentName;
        this.feeName = this.router.getCurrentNavigation().extras.state.feeName;
        this.feeAmount = this.router.getCurrentNavigation().extras.state.feeAmount;
        this.collectionType = this.getParameterByName('collection_type', this.url);
        this.feeCollectionId = this.getParameterByName('fee_collection_id', this.url);
        this.studentId = this.getParameterByName('student_id', this.url);
        this.transactionId = this.getParameterByName('transaction_id', this.url);
        this.transactionStatus = this.getParameterByName('transaction_status', this.url);
        this.reason = this.getParameterByName('reason', this.url);
        if (this.reason === "Bank failed to authenticate the customer")
          this.translate.get("transaction_details.reason_text").subscribe(val => this.reason = val);
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  ngOnInit() { }
  getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
      results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  }
  gotofees() {
    if (this.transactionStatus === 'failure') {
      this.navCtrl.pop()
    } else {
      this.navCtrl.setDirection('root');
      this.router.navigateByUrl('/fees', { replaceUrl: true });
    }
  }

}
