import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { IonContent, NavController } from '@ionic/angular';
import { FeesModel } from 'src/models/fees/fees';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Fees } from 'src/providers/fees';
import { School } from 'src/providers/school';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-fees',
  templateUrl: 'fees.html',
  styleUrls: ['fees.scss']
})
export class FeesPage implements OnInit {
  @ViewChild(IonContent) content: IonContent;
  type: string = 'dues';
  fees: any;
  token = '';
  studentId = '';
  hideEmpty: boolean = true;
  duesLoaded: boolean = false;
  paidFeesLoaded: boolean = false;
  feesDueLists = [];
  totalFeeDue: number = 0;
  feesPaidLists = [];
  currency: any;
  allPaymentEnabled: boolean = false;
  constructor(
    private school: School,
    private event: EventsService,
    public navCtrl: NavController,
    private feesService: Fees,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    // this.init();
  }
  ngOnInit() {

  }
  private init() {

    this.school.getSchool('currency').then((value) => { this.currency = value; });
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.commonService.presentLoading('Loading fees');
        this.loadDueFees();
        this.loadPaidFees();

      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  goback() {
    this.navCtrl.setDirection('root')
    this.router.navigateByUrl('/tabs', { replaceUrl: true });
  }
  loadDueFees() {
    this.duesLoaded = false;
    this.hideEmpty = true;
    console.log(this.type);
    this.feesService.loadFeeDueList(this.token).subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        console.log(response);

        if (response.success === true) {
          this.fees = new FeesModel(response.fees);
          console.log(this.fees);
          this.feesDueLists = this.fees.feesDetails;
          if (this.feesDueLists.length === 0) {
            this.hideEmpty = false;
          }
          this.totalFeeDue = this.fees.totalFeeDue;
          this.allPaymentEnabled = this.fees.allPaymentEnabled;
          this.currency = this.fees.currencyType;
          this.school.setSchool('currency', this.currency);

        }
        this.duesLoaded = true;
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
        this.duesLoaded = true;
      },
    );
    this.content.scrollToTop();

  }
  loadPaidFees() {
    console.log(this.type);
    this.paidFeesLoaded = true;
    this.feesService.loadFeePaidList(this.token).subscribe(
      (response: any) => {
        console.log(response);
        if (response.success === true) {
          this.fees = new FeesModel(response.fees);
          console.log(this.fees);
          this.feesPaidLists = this.fees.feesDetails;
          // if(this.feesPaidLists.length == 0){
          //   this.hideEmpty = false;
          // }
          this.currency = this.fees.currencyType;
          this.school.setSchool('currency', this.currency);


        }
        this.paidFeesLoaded = true;
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
        this.paidFeesLoaded = true;
      },
    );
    this.content.scrollToTop();
  }

  ionViewWillEnter() {
    // this.init();
  }
  ionViewDidEnter() {
    this.init();
    console.log('enetered init')

  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad Fees');
    this.content.scrollToTop();
  }
  openPayAllFeesPage() {
    this.router.navigateByUrl('/pay-all-fees');
    this.content.scrollToTop();
  }
  payFees(data) {
    this.router.navigateByUrl('/fees-details', { state: { 'data': data } });
    this.content.scrollToTop();
  }
  viewFees(data, action) {
    this.router.navigateByUrl('/fees-details', { state: { 'data': data, 'action': action } });
    this.content.scrollToTop();
  }
}
