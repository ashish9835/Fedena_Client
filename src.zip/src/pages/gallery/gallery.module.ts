import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { GalleryPage } from './gallery';
import { GalleryPageRoutingModule } from './gallery-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GalleryPageRoutingModule,
    PipesModule
  ],
  declarations: [GalleryPage]
})
export class GalleryPageModule { }
