import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { AlbumModel } from 'src/models/gallery/album';
import { GalleryModel } from 'src/models/gallery/gallery';
import { CommonService } from 'src/providers/common/common.service';
import { Gallery } from 'src/providers/gallery';
import { User } from 'src/providers/user';


@Component({
  selector: 'page-gallery',
  templateUrl: 'gallery.html',
  styleUrls: ['gallery.scss']
})
export class GalleryPage implements OnInit {
  token = '';
  albums = [];
  userId: any;
  studentId: any = '';
  tokenInfo: any;
  albumData: any;
  page: number = 1;
  galleryLastAccessedAt: any;
  constructor(public navCtrl: NavController,
    private galleryService: Gallery,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getRole().then((role) => {
          this.userService.getUserId().then((id) => {
            if (role === 'guardian') {
              this.userService.getAccounts().then((value) => {
                this.userId = value[0].userId;
                this.userId = this.userId + '_' + id;
                console.log(this.userId);
                this.loadAlbums();
              });
            } else {
              this.userId = id;
              this.loadAlbums();
            }
          });
        });
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  ngOnInit() { }
  openAlbum(id) {
    console.log(id);
    this.router.navigateByUrl('/albums/' + id)
  }
  loadAlbums() {
    this.galleryService.loadAlbums(this.token, this.page).subscribe(
      (response: any) => {
        console.log(response.albums);
        this.albumData = new GalleryModel(response);
        console.log(this.albumData);
        this.albums = this.albumData.albums;
        this.galleryLastAccessedAt = new Date();
        this.galleryLastAccessedAt = this.galleryLastAccessedAt.toString().replace(/UTC\s/, '');
        this.galleryLastAccessedAt = this.galleryLastAccessedAt.replace(/GMT.+/, '');
        localStorage.setItem('lastAccessedValue_' + this.userId, JSON.stringify(this.galleryLastAccessedAt));
        console.log(this.galleryLastAccessedAt);
      },
      (err) => {
        console.log(err);
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  doInfinite(infiniteScroll) {
    console.log('Loading messages');
    setTimeout(() => {
      this.page++;
      this.galleryService.loadAlbums(this.token, this.page).subscribe(
        (response: any) => {
          console.log(response.albums);
          this.commonService.dismissloading();
          response.albums.forEach((i) => {
            this.albums.push(Object.assign(new AlbumModel(i), {
              isLoaded: false,
            }));
          });
          console.log(this.albums);
          infiniteScroll.target.complete();
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.userService.errorHandler();
          }
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        },
      );
    }, 500);
  }
  doRefresh(refresher) {
    setTimeout(() => {
      this.page = 1;
      this.loadAlbums();
      refresher.complete();
    }, 2000);
  }
  onload(index: number) {
    this.albums[index].isLoaded = true;
  }
}
