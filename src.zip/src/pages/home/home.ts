import { Component, OnInit } from '@angular/core';
import { Storage } from '@ionic/storage';
import { LoadingController, NavController, Platform } from '@ionic/angular';
import { Router } from '@angular/router';
import { EventsService } from 'src/providers/events/events.service';
import { Notifications } from 'src/providers/notifications';
import { CommonService } from 'src/providers/common/common.service';
import { Announcements } from 'src/providers/announcements';
import { Profile } from 'src/providers/profile';
import { User } from 'src/providers/user';
import { EmployeeProfileDetailsModel } from 'src/models/Profile/employeeProfileDetails';
import { StudentProfileDetailsModel } from 'src/models/Profile/studentProfileDetails';
import { StudentDashboardModel } from 'src/models/dashboard/studentDashboard';
import { EmployeeDashboardModel } from 'src/models/dashboard/employeeDashboard';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  styleUrls: ['home.scss'],
})
export class HomePage implements OnInit {
  loading: any;
  param = this;
  dummyno = 10000;
  // actionSheet: ActionSheet;
  userrole = 'employee';
  profile = [];
  name = '';
  profileTitle = '';
  profileSubTitle = '';
  token = '';
  studentId = '';
  employeeData: any;
  studentData: any;
  employee = true;
  dashboard: any;
  showToDo = false;
  pendingTasks = 0;
  showMyBatch = false;
  showLeaveRequests = false;
  pendingLeaveRequests = 0;
  showTimetables = true;
  todayClasses = 0;
  showEvents = false;
  events = [];
  periods = [];
  totalEvents = 0;
  newAlbums = 0;
  showAttendance = false;
  totalAttendance = 0;
  showFees = false;
  showAnnouncements = false;
  showTransport = false;
  showSubjects = false;
  showGallery = false;
  showLeaves = false;
  showReports = false;
  unreadAnnouncements = 0;
  deviceId = '11124411';
  deviceType: any;
  totalDues = 'no';
  profilePhoto = 'assets/img/appicon.png';
  exitApp: boolean;
  showLater = false;
  unreadCount = 0;
  userId: any;
  public unregisterBackButtonAction: any;
  employeeNumber: string;
  constructor(
    private event: EventsService,
    public storage: Storage,
    private loadingCtrl: LoadingController,
    private translate: TranslateService,
    private announcementsService: Announcements,
    public navCtrl: NavController,
    public notification: Notifications,
    private profileService: Profile,
    private userService: User,
    public platform: Platform,
    private commonService: CommonService,
    private router: Router
  ) {
    this.userService.getUser().then(user => { this.employeeNumber = user.employeeNumber });
    this.event.subscribe('home_reload', (data) => {
      console.log('home load event invoked..')
      this.loadData();
    });
  }

  ngOnInit() {
  }
  ionViewWillEnter() {
    console.log('ho ho')
    this.loadData();
  }


  loadData() {
    // this.event.publish('alert:event', 'dismiss_loading','homepageinda');
    // this.event.publish('alert:event', 'show_loading', 'Loading dashboard');
    this.showLoading('Loading dashboard');
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        // this.addDevice();
        this.userService.getDevice().then((device) => {
          console.log('ddecisd dsflkd')
          console.log(device)
          if (device) {
            this.deviceId = device.device_id;
            this.deviceType = device.device_type;
            console.log('Adding Device:', device);
            this.addDevice();
          }
        });
        this.userService.getRole().then((role) => {
          if (role === 'employee') {
            this.userService.getUserId().then((value) => {
              this.userId = value;
            });
            this.profileService.loadEmployeeProfile(this.token).subscribe(
              (response) => {
                const apiResponse: any = response;
                // console.log(apiResponse);
                if (!apiResponse.success) {
                  this.loading.dismiss()
                  this.event.publish('user:logout', {});
                }
                this.employeeData = new EmployeeProfileDetailsModel(apiResponse.employee);
                // console.log(this.employeeData);
                this.userService.setUser(this.employeeData);
                console.log('refreshed employee profile');
                // this.event.publish('alert:event', 'dismiss_loading','homepageinda');
                this.profileTitle = 'Employee';
                this.profileSubTitle = this.employeeData.employeeDepartmentName;
                if (this.employeeData.profilePhoto !== '') {
                  this.profilePhoto = this.employeeData.profilePhoto;
                }
                this.event.publish('alert:event', 'user:refresh');
                this.employee = true;
                this.getEmployeeDashboard();
              },
              (err) => {
                this.loading.dismiss()
                // this.event.publish('alert:event', 'dismiss_loading','homepageinda');
                console.log(err.status);
                if (err.status === 500) {
                  this.userService.errorHandler();
                }
                if (err.status === 403) {
                  this.navCtrl.setDirection('root');
                  this.router.navigateByUrl('/tutorials', { replaceUrl: true });
                }
              },
            );
          } else {
            this.userService.getUserId().then((value) => {
              if (role === 'guardian') {
                this.userService.getAccounts().then((data) => {
                  console.log(data[0].userId);
                  this.userId = data[0].userId;
                  this.userId = this.userId + '_' + value;
                  console.log(this.userId);
                });

              } else this.userId = value;
              this.studentId = value;
              this.profileService.loadStudnetProfile(this.token, this.studentId).subscribe(
                (response) => {
                  const apiResponse: any = response;
                  if (!apiResponse.success) {
                    this.loading.dismiss()
                    this.event.publish('user:logout', {});
                  }
                  this.studentData = new StudentProfileDetailsModel(apiResponse.student);
                  this.name = this.studentData.fullName;
                  this.userService.setUser(this.studentData);
                  console.log('loaded student profile');
                  // console.log(this.studentData);
                  this.profileTitle = 'Student';
                  // tslint:disable-next-line:max-line-length
                  this.profileSubTitle = this.studentData.batchCourseName + ' - ' + this.studentData.batchName;
                  if (this.studentData.profilePhoto !== '') {
                    this.profilePhoto = this.studentData.profilePhoto;
                  }
                  this.event.publish('alert:event', 'user:refresh');
                  this.employee = false;
                  this.getStudentDashboard();
                },
                (err) => {
                  this.loading.dismiss()
                  // this.event.publish('alert:event', 'dismiss_loading','homepageinda');
                  console.log(err.status);
                  if (err.status === 500) {
                    this.userService.errorHandler();
                  }
                  if (err.status === 403) {
                    this.navCtrl.setDirection('root');
                    this.router.navigateByUrl('/tutorials', { replaceUrl: true });
                  }
                },
              );
            });
          }
          if (role === 'guardian') {
            this.employee = false;
            this.userService.getAccounts().then((value) => {
              // console.log(value);
              this.studentId = value.id;
              this.getStudentDashboard();
            });
          }
        });
        this.notification.loadUnreadCount(this.token).subscribe(
          (response) => {
            // this.loading.dismiss()
            // if(this.chats!=response.message_threads)
            // { 
            const apiResponse: any = response;
            this.unreadCount = apiResponse.count;
            console.log(response);
            // }
          },
          (err) => {
            this.loading.dismiss()
            console.log(err.status);
            if (err.status === 500) {
              this.userService.errorHandler();
            }
            if (err.status === 403) {
              this.navCtrl.setDirection('root');
              this.router.navigateByUrl('/tutorials', { replaceUrl: true });
            }
          },
        );
        this.announcementsService.loadAnnouncements(this.token).subscribe(
          (response) => {
            console.log(response);
            // const apiResponse:any = response;
            // this.loading.dismiss()
            const apiResponse: any = response;
            if (apiResponse.success === true) {
              this.unreadAnnouncements = apiResponse.news.length;
              this.getUnreadAnnouncementsCount();
            }
          },
          (err) => {
            // this.event.publish('alert:event', 'dismiss_loading','homepageinda');
            console.log(err.status);
            if (err.status === 500) {
              this.userService.errorHandler();
            }
            if (err.status === 403) {
              this.navCtrl.setDirection('root');
              this.router.navigateByUrl('/tutorials', { replaceUrl: true });
            }
          },
        );
        // this.event.publish('alert:event', 'dismiss_loading','homepageinda');

      } else {
        this.commonService.presentAlert('Logged out')
        this.event.publish('user:logout', {});
      }
    });
  }
  getUnreadAnnouncementsCount() {
    this.storage.get('announcements_read').then((val) => {
      if (val) this.unreadAnnouncements = this.unreadAnnouncements - val.length;
      if (this.unreadAnnouncements < 0) this.unreadAnnouncements = 0;
    });
  }
  getEmployeeDashboard() {
    this.profileService.loadEmployeeDashboard(this.token, this.userId).subscribe(
      (response) => {
        // console.log(response);
        const apiResponse: any = response;
        if (apiResponse.success === true) {
          this.dashboard = new EmployeeDashboardModel(apiResponse);
          // console.log(this.dashboard);
          this.name = this.dashboard.fullName;
          this.showToDo = false;
          this.pendingTasks = 0;
          if (this.dashboard.events) {
            this.showEvents = true;
            this.totalEvents = this.dashboard.events.total;
            // this.totalEvents = 3;
            this.events = this.dashboard.events.events;
          }
          if (this.dashboard.myBatch) {
            this.showMyBatch = false;
          }
          if (this.dashboard.leaveRequests) {
            this.showLeaveRequests = true;
            this.pendingLeaveRequests = this.dashboard.leaveRequests.pendingCount;
          }
          if (this.dashboard.news) {
            this.showAnnouncements = true;
          }
          if (this.dashboard.timetables) {
            this.showTimetables = true;
            this.todayClasses = this.dashboard.timetables.total;
            this.periods = this.dashboard.timetables.periods;
          }
          if (this.dashboard.gallery) {
            this.showGallery = true;
            this.newAlbums = this.dashboard.gallery;
          } else {
            this.showGallery = false;
          }
          if (this.dashboard.transport === true) {
            this.showTransport = true;
          }
          setTimeout(() => {
            this.showLater = true;
            console.log("ebterdi tgus sdjfarea aif t hue ")
            //  this.event.publish('alert:event', 'dismiss_loading','homepageinda');


          }, 2000);
          this.showFees = false;
          this.showReports = false;
          this.showSubjects = false;
          this.showLeaves = true;
        }
        console.log(this.loading)
        // this.loading.dismissAll();
        this.loading.dismiss();




      },
      (err) => {
        this.loading.dismiss()
        // this.event.publish('alert:event', 'dismiss_loading','homepageinda');
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorials', { replaceUrl: true });
        }
      },
    );
  }
  getStudentDashboard() {
    this.profileService.getStudentDashboard(this.token, this.userId)
      .then((data) => {
        console.log('Student dashboard data received');
        // console.log(data);
        const apiResponse: any = data;
        this.dashboard = new StudentDashboardModel(apiResponse);
        // console.log(this.dashboard);
        this.totalDues = this.dashboard.fees;
        if (this.dashboard.attendances) {
          this.showAttendance = true;
          this.totalAttendance = this.dashboard.attendances.percentage;
        }
        if (this.dashboard.events) {
          this.showEvents = true;
          this.totalEvents = this.dashboard.events.total;
          // this.totalEvents = 3;
          this.events = this.dashboard.events.events;
          console.log(`Events are:`, this.events);
        }
        if (this.dashboard.news) {
          this.showAnnouncements = true;
        }
        if (this.dashboard.timetables) {
          this.showTimetables = true;
          this.todayClasses = this.dashboard.timetables.total;
          this.periods = this.dashboard.timetables.periods;
        }
        if (this.dashboard.fees) {
          this.showFees = true;
        }
        if (this.dashboard.mySubjects) {
          this.showSubjects = true;
        }
        if (this.dashboard.gallery) {
          this.showGallery = true;
          this.newAlbums = this.dashboard.gallery;
        } else {
          this.showGallery = false;
        }
        if (this.dashboard.transport) {
          this.showTransport = true;
        }
        setTimeout(() => {
          this.showLater = true;
        }, 2000);
        this.showReports = true;
        this.showLeaves = false;
        this.loading.dismiss()
        // this.event.publish('alert:event', 'dismiss_loading','homepageinda');
      })
      .catch((err) => {
        this.loading.dismiss()
        // this.event.publish('alert:event', 'dismiss_loading','homepageinda');
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorials', { replaceUrl: true });
        }
      });
  }
  loadNotifications() {
    this.router.navigateByUrl('/notification/' + this.unreadCount)
  }
  addDevice() {
    this.profileService.addDevice(this.token, this.deviceId, this.deviceType).subscribe(
      (response: any) => {
        // console.log(response);
        if (response.success === true) {
        }
      },
      (err) => {
        this.loading.dismiss()
        // this.event.publish('alert:event', 'dismiss_loading','homepageinda');
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();

        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorials', { replaceUrl: true });
        }
      },
    );
  }
  gotoProfile() {
    this.router.navigateByUrl('/my-profile');
  }
  gotoFees() {
    this.router.navigateByUrl('/fees');
  }
  gotoTimetable() {
    this.router.navigateByUrl('/timetable');
  }
  gotoEvents() {
    this.router.navigateByUrl('/events', { state: { route: true } });
  }
  gotoAnnouncements() {
    this.router.navigateByUrl('/announcements');
  }
  gotoMyLeaves() {
    this.router.navigateByUrl('/my-leave');
  }
  gotoLeaveRequests() {
    this.router.navigateByUrl('/leave-requests');
  }
  gotoMyBatchAttendance() {
    this.router.navigateByUrl('/class');
  }
  gotoMyMarkBatchAttendance() {
    this.router.navigateByUrl('/class');
  }
  gotoMyAttendance() {
    this.router.navigateByUrl('/student-attendance');
  }
  gotoMySubjects() {
    this.router.navigateByUrl('/subjects');
  }
  gotoGallery() {
    this.router.navigateByUrl('/gallery');
  }
  gotoExamReports() {
    this.router.navigateByUrl('/exam-reports');
  }
  gotoAssignments() {
    this.router.navigateByUrl('/assignments');
  }
  gotoTransport() {
    this.router.navigateByUrl('/transport');
  }
  loadPage() {
    this.loadData();
  }
  async showLoading(message) {
    if (this.loading) this.loading.dismiss();
    console.log(this.loading)
    let msgKey = message.toLowerCase().split(' ').join('_');
    this.translate.get('loader.' + msgKey).subscribe((msg: string) => {
      message = msg;
    });
    this.loading = await this.loadingCtrl.create({
      message: message,
      backdropDismiss: true
    });
    await this.loading.present();
  }

}
