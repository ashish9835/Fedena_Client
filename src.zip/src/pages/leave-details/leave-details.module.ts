import { NgModule } from '@angular/core';
import { PipesModule } from '../../pipes/pipes.module'
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { LeaveDetailsPage } from './leave-details';
import { LeaveDetailsPageRoutingModule } from './leave-details-routing.module';

@NgModule({
    declarations: [
        LeaveDetailsPage
    ],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        LeaveDetailsPageRoutingModule
    ],
})



export class LeaveDetailsPageModule { }