import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, NavController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { EmployeeLeaveRequestModel } from 'src/models/employeeLeaves/employeeLeaveRequest';
import { CommonService } from 'src/providers/common/common.service';
import { EmployeeLeave } from 'src/providers/employee-leave';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-leave-details',
  templateUrl: 'leave-details.html',
  styleUrls: ['leave-details.scss']
})
export class LeaveDetailsPage implements OnInit {
  leave: any;
  userId = '';
  token = '';
  additional: number;
  lop: number;
  leaveId = '';
  constructor(
    private translate: TranslateService,
    private event: EventsService,
    public navCtrl: NavController,
    private alert: AlertController,
    private leaveService: EmployeeLeave,
    private userService: User,
    private commonService: CommonService,
    private router: Router,
  ) {
    this.leave = this.router.getCurrentNavigation().extras.state.leave;
    this.leaveId = this.router.getCurrentNavigation().extras.state.leaveId;
    console.log(this.leave);
    this.loadDetails();
  }
  ngOnInit() { }
  loadDetails() {
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          this.userId = id;
          this.leaveService.leaveStatus(
            this.token, this.userId, this.leave.id, this.leave.markedAsAbsent,
          ).subscribe(
            (response: any) => {
              if (response.success === true) {
                this.leave = new EmployeeLeaveRequestModel(response.employee_leave);
                console.log(response);
                console.log(this.leave);
                this.additional = this.leave.additionalLeaveCount;
                this.lop = this.leave.lopCount;
              } else {
                this.commonService.presentAlert(response.description);
              }
            },
            (err) => {
              this.commonService.dismissloading();
              console.log(err.status);
              if (err.status === 500) {
                this.userService.errorHandler();
              }
              if (err.status === 403) {
                this.navCtrl.setDirection('root');
                this.router.navigateByUrl('/tutorial', { replaceUrl: true });
              }
            },
          );
        });
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LeaveDetails');
  }
  ionViewWillLeave() {
    this.event.publish('dismiss:overlay', {});
  }
  async withdrawApplication() {
    let message = 'Are you sure?';
    let title = 'Withdraw leave';
    let confirmBtnText = "Confirm";
    let cancelBtnText = "Cancel";
    this.translate.get('leave_requests.are_you_sure').subscribe(val => message = val);
    this.translate.get('leave_requests.withdraw_leave').subscribe(val => title = val);
    this.translate.get('leave_requests.confirm').subscribe(val => confirmBtnText = val);
    this.translate.get('leave_requests.cancel').subscribe(val => cancelBtnText = val);
    const alert = await this.alert.create({
      header: title,
      message: message,
      buttons: [{
        text: confirmBtnText,
        handler: () => { this.exitApp(); },
      }, {
        text: cancelBtnText,
        role: 'cancel',
      }],
    });
    this.event.subscribe('dismiss:overlay', () => {
      alert.dismiss()
    })
    await alert.present();
  }
  exitApp() {
    this.withdraw();
  }
  withdraw() {
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          this.userId = id;
          this.leaveService.withdrawLeaveApplication(
            this.token, this.userId, this.leaveId,
          ).subscribe(
            (response: any) => {
              console.log(response);
              if (response.success === true) {
                this.navCtrl.setDirection('root');
                this.router.navigateByUrl('/my-leave', { replaceUrl: true });
              } else {
                this.commonService.presentAlert('Application expired');
              }
            },
            (err) => {
              this.commonService.dismissloading();
              console.log(err.status);
              if (err.status === 500) {
                this.userService.errorHandler();
              }
              if (err.status === 403) {
                this.navCtrl.setDirection('root');
                this.router.navigateByUrl('/tutorial', { replaceUrl: true });
              }
            },
          );
        });
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
}
