import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LeaveRequestsDetailsPage } from './leave-requests-details';


const routes: Routes = [
  {
    path: '',
    component: LeaveRequestsDetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LeaveRequestsDetailsPageRoutingModule { }
