import { NgModule } from '@angular/core';
import { PipesModule } from '../../pipes/pipes.module'
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { LeaveRequestsDetailsPage } from './leave-requests-details';
import { LeaveRequestsDetailsPageRoutingModule } from './leave-requests-details-routing.module';

@NgModule({
    declarations: [
        LeaveRequestsDetailsPage
    ],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        LeaveRequestsDetailsPageRoutingModule
    ],
})



export class LeaveRequestsDetailsPageModule { }