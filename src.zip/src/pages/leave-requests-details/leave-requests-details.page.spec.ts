import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { LeaveRequestsDetailsPage } from './leave-requests-details';

describe('LeaveRequestsDetailsPage', () => {
  let component: LeaveRequestsDetailsPage;
  let fixture: ComponentFixture<LeaveRequestsDetailsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LeaveRequestsDetailsPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LeaveRequestsDetailsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
