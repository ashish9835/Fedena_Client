import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, NavController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { EmployeeLeaveRequestModel } from 'src/models/employeeLeaves/employeeLeaveRequest';
import { CommonService } from 'src/providers/common/common.service';
import { EmployeeLeave } from 'src/providers/employee-leave';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-leave-requests-details',
  templateUrl: 'leave-requests-details.html',
  styleUrls: ['leave-requests-details.scss']
})
export class LeaveRequestsDetailsPage {
  leave: any;
  userId = '';
  token = '';
  remark = '';
  isLop: boolean;
  allowLopSelection: boolean;
  additionalLeaves: any;
  leaveData: any = {};
  selectOptions: any;
  canSendDates: boolean;
  dates = [];
  managerName: string;
  managerRemark: string;
  constructor(
    public translate: TranslateService,
    private event: EventsService,
    public navCtrl: NavController,
    private leaveService: EmployeeLeave,
    private userService: User,
    public alertCtrl: AlertController,
    public commonService: CommonService,
    public router: Router
  ) {
    this.commonService.presentLoading('Loading leave request');
    this.leave = this.router.getCurrentNavigation().extras.state.leave;
    let selectDateTxt;
    this.translate.get('leave_requests.select_dates').subscribe(val => selectDateTxt = val);
    this.selectOptions = {
      title: selectDateTxt,
      mode: 'md',
    };
    console.log(this.leave);
    this.loadDetails();
  }
  showSelected() {
    console.log(this.dates);
  }
  loadDetails() {

    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          this.userId = id;
          this.leaveService.leaveStatus(
            this.token, this.leave.employeeId, this.leave.id, this.leave.markedAsAbsent,
          ).subscribe(
            (response: any) => {
              this.commonService.dismissloading();
              console.log(response);
              this.dates = [];
              if (response.success === true) {
                this.leaveData = new EmployeeLeaveRequestModel(response.employee_leave);
                console.log(this.leaveData);
                this.canSendDates = this.leaveData.canMarkLop;
                this.additionalLeaves = this.leaveData.additionalLeaves;
                this.isLop = this.leaveData.isLop;
                this.allowLopSelection = this.isLop;
                this.managerName = this.leaveData.approvingManagerRecordFullName;
                this.managerRemark = this.leaveData.managerRemark;
                for (const leave of this.additionalLeaves) {
                  this.dates.push(leave.date);
                }
              } else {
                this.commonService.presentAlert(response.description);
              }
            },
            (err) => {
              this.commonService.dismissloading();
              console.log(err.status);
              if (err.status === 500) {
                this.userService.errorHandler();
              }
              if (err.status === 403) {
                this.navCtrl.setDirection('root');
                this.router.navigateByUrl('/tutorial', { replaceUrl: true });
              }
            },
          );
        });
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad LeaveDetails');
  }
  approveLeave() {
    this.commonService.presentLoading('Approving leave');
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          this.userId = id;
          let condition = false;
          if (this.canSendDates && this.isLop) condition = true;
          this.leaveService.approveLeaveApplication(
            this.token, this.leave.employeeId, this.leave.id, this.remark, this.dates, condition,
          ).subscribe(
            (response: any) => {
              console.log(response);
              if (response.success === true) {
                this.commonService.dismissloading();
                this.remark = '';
                this.loadDetails();
                this.navCtrl.setDirection('root');
                this.router.navigateByUrl('/leave-requests');
              }
            },
            (err) => {
              this.commonService.dismissloading();
              console.log(err.status);
              if (err.status === 500) {
                this.userService.errorHandler();
              }
              if (err.status === 403) {
                this.navCtrl.setDirection('root');
                this.router.navigateByUrl('/tutorial', { replaceUrl: true });
              }
            },
          );
        });
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });


  }
  denyLeave() {
    console.log('denied');
    this.commonService.presentLoading('Denying leave');
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          this.userId = id;
          this.leaveService.denyLeaveApplication(
            this.token, this.leave.employeeid, this.leave.id, this.remark,
          ).subscribe(
            (response: any) => {
              console.log(response);
              if (response.success === true) {
                this.remark = '';
                this.commonService.dismissloading();
                this.loadDetails();
                this.navCtrl.setDirection('root');
                this.router.navigateByUrl('/leave-requests');
              } else {
                this.commonService.presentAlert(response.description);
              }
            },
            (err) => {
              this.commonService.dismissloading();
              console.log(err.status);
              if (err.status === 500) {
                this.userService.errorHandler();
              }
              if (err.status === 403) {
                this.navCtrl.setDirection('root');
                this.router.navigateByUrl('/tutorial', { replaceUrl: true });
              }
            },
          );
        });
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }

  async action(type) {
    let titleString: string;
    let noBtnString = 'No';
    let yesBtnString = 'Yes';
    let msgString = 'Are you sure?';
    if (type === 'approve') {
      this.translate.get('alert.title_approve_leave').subscribe(val => titleString = val);
    }
    if (type === 'deny') {

      this.translate.get('alert.title_deny_leave').subscribe(val => titleString = val);
    }
    this.translate.get('alert.btn_no').subscribe(val => noBtnString = val);
    this.translate.get('alert.btn_yes').subscribe(val => yesBtnString = val);
    this.translate.get('alert.msg_are_you_sure').subscribe(val => msgString = val);

    const confirm = await this.alertCtrl.create({
      header: titleString,
      message: msgString,
      buttons: [
        {
          text: noBtnString,
          handler: () => {
            console.log('Disagree clicked');
          },
        },
        {
          text: yesBtnString,
          handler: () => {
            if (type === 'approve') this.approveLeave();
            if (type === 'deny') this.denyLeave();
            console.log('Agree clicked');
          },
        },
      ],
    });
    this.event.subscribe('dismiss:overlay', () => {
      if (confirm)
        confirm.dismiss()
    })
    confirm.present();
  }
  ionViewWillLeave() {
    this.event.publish('dismiss:overlay', {});
  }


}
