import { NgModule } from '@angular/core';
import { PipesModule } from '../../pipes/pipes.module'
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { LeaveRequestsPage } from './leave-requests';
import { LeaveRequestsPageRoutingModule } from './leave-requests-routing.module';

@NgModule({
    declarations: [
        LeaveRequestsPage
    ],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        LeaveRequestsPageRoutingModule
    ],
})



export class LeaveRequestsPageModule { }