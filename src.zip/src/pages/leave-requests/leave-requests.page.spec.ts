import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { LeaveRequestsPage } from './leave-requests';

describe('LeaveRequestsPage', () => {
  let component: LeaveRequestsPage;
  let fixture: ComponentFixture<LeaveRequestsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LeaveRequestsPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LeaveRequestsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
