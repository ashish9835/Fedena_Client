import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { EmployeeLeaveRequestModel } from 'src/models/employeeLeaves/employeeLeaveRequest';
import { CommonService } from 'src/providers/common/common.service';
import { EmployeeLeave } from 'src/providers/employee-leave';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-leave-requests',
  templateUrl: 'leave-requests.html',
  styleUrls: ['leave-requests.scss']
})
export class LeaveRequestsPage implements OnInit {
  @ViewChild('content') content: any;
  pastRequest: any = [];
  pendingRequest: any = [];
  pastrequests: any = [];
  pendingrequests: any = [];
  type: string = 'pending';
  userId = '';
  token = '';
  pendingPage: number = 1;
  pastPage: number = 1;
  maxPendingPage: number = 1;
  maxPastPage: number = 1;
  constructor(
    private event: EventsService,
    public navCtrl: NavController,
    private leaveService: EmployeeLeave,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.commonService.presentLoading('Loading');
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          this.userId = id;
          this.loadPendingRequests();
          this.loadPastRequests();
        });
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
    this.event.subscribe('LeaveRequest:action', () => {
      this.pastrequests = [];
      this.pendingrequests = [];
      this.loadPastRequests();
      this.loadPendingRequests();
    });
  }
  ngOnInit() { }
  loadPending() {
    this.commonService.presentLoading('Loading');
    this.pendingrequests = [];
    this.pendingPage = 1;
    this.loadPendingRequests();

  }
  loadPast() {
    this.commonService.presentLoading('Loading');
    this.pastrequests = [];
    this.pastPage = 1;
    this.loadPastRequests();
  }


  loadPendingRequests() {
    this.leaveService.loadPendingLeaveApplication(
      this.token,
      this.userId,
      this.pendingPage,
    ).subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        console.log(`Pending Requests Response:`, response);
        if (response.success === true) {
          if (response.employee_leaves.length > 0) {
            this.pendingRequest = [];
            response.employee_leaves.forEach(i => {
              this.pendingRequest.push(new EmployeeLeaveRequestModel(i));
            });
            this.pendingrequests = this.pendingrequests.concat(this.pendingRequest);
            this.maxPendingPage = response.pagination.lastpage;
          }
          console.log('Pending Requests Array:', this.pendingrequests);

        }

      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
    this.content.scrollToTop();
  }
  loadPastRequests() {
    this.leaveService.loadPastLeaveApplication(this.token, this.userId, this.pastPage).subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        console.log(`Pasts Requests Response:`, response);
        if (response.success === true) {
          if (response.employee_leaves.length > 0) {
            this.pastRequest = [];
            response.employee_leaves.forEach(i => {
              this.pastRequest.push(new EmployeeLeaveRequestModel(i));
            });
            this.pastrequests = this.pastrequests.concat(this.pastRequest);
            this.maxPastPage = response.pagination.lastpage;
          }
          console.log('Past Requests Array:', this.pastrequests);

        }

      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },

    );
    this.content.scrollToTop();
  }
  doInfinite(infiniteScroll, type) {
    setTimeout(() => {
      if (this.type === 'pending') {
        this.pendingPage = this.pendingPage + 1;
        if (this.pendingPage > this.maxPendingPage) console.log('all requests fetched');
        else this.loadPendingRequests();

      } else {
        this.pastPage = this.pastPage + 1;
        if (this.pastPage > this.maxPastPage) console.log('all requests fetched');
        else this.loadPastRequests();
      }
    }, 3000);
    infiniteScroll.target.complete();
  }
  viewDetails(leave) {
    this.router.navigateByUrl('/leave-requests-details', { state: { 'leave': leave } });
  }
  changed() {
    this.content.scrollToTop();
  }
  goback() {
    this.navCtrl.setDirection('root');
    this.router.navigateByUrl('/tabs', { replaceUrl: true });
  }
}
