import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LightBoxImagePage } from './lightbox-image';


const routes: Routes = [
  {
    path: '',
    component: LightBoxImagePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LightBoxImagePageRoutingModule { }
