import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { LightBoxImagePage } from './lightbox-image';

describe('LightBoxImagePage', () => {
  let component: LightBoxImagePage;
  let fixture: ComponentFixture<LightBoxImagePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LightBoxImagePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LightBoxImagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
