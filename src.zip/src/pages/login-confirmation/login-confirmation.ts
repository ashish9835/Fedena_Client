import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { MenuController, NavController, Platform } from '@ionic/angular';
import { AppSettings } from 'src/models/app-settings';
import { EmployeeProfileModel } from 'src/models/Authentication/employeeProfile';
import { GuardianProfileModel } from 'src/models/Authentication/guardianProfile';
import { StudentProfileModel } from 'src/models/Authentication/studentProfile';
import { EventsService } from 'src/providers/events/events.service';
import { School } from 'src/providers/school';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-login-confirmation',
  templateUrl: 'login-confirmation.html',
  styleUrls: ['login-confirmation.scss']
})
export class LoginConfirmationPage implements OnInit {

  tokens = [];
  otpno = '';
  schoolLogo = AppSettings.SCHOOL_LOGO;
  schoolName: string;
  schoolPlace: string;
  constructor(
    public events: EventsService,
    public navCtrl: NavController,
    private school: School,
    public user: User,
    public keyboard: Keyboard,
    public platform: Platform,
    private menu: MenuController,
    private route: ActivatedRoute,
    private router: Router
  ) {
    const temp = this.route.snapshot.params.token;
    this.school.getSchool('name').then((value) => { this.schoolName = value; });
    this.school.getSchool('address').then((value) => { this.schoolPlace = value; });
    this.storeTokens();
    console.log(temp);
    temp.forEach(i => {
      if (i.role === 'guardian') {
        this.tokens.push(new GuardianProfileModel(i));
      } else if (i.role === 'student') {
        console.log(i);
        this.tokens.push(new StudentProfileModel(i));
      } else {
        this.tokens.push(new EmployeeProfileModel(i));
      }
    });
    console.log(this.tokens);
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      /*
       * MODIFY BOOTSTRAP CODE BELOW
       * Disable the Ionic Keyboard Plugin scroll for iOS only
       * https://github.com/driftyco/ionic/issues/5571
       */
      if (this.platform.is('ios')) {
        keyboard.disableScroll(false);
      }
      /*
       * END MODIFY
       */
    });

  }
  ngOnInit(){
    
  }
  storeTokens() {
    this.user.setAccessTokens(this.tokens);
  }
  gotoHome(token) {
    if (token.role === 'guardian') {
      this.user.setAccessToken(token.accessToken + ';student_id=' + token.profile[0].id);
      this.user.setUser(token.profile[0]);
      this.user.setUserId(token.profile[0].id);
    } else {
      this.user.setUser(token.profile);
      this.user.setAccessToken(token.accessToken);
      this.user.setUserId(token.profile.id);
    }

    this.user.setUsername(token.username);
    this.user.setRole(token.role);
    this.user.setAccounts(token.profile);
    this.user.setMasterUserId(token.userId);
    this.events.publish('user:created', token);
    this.events.publish('swap:enable', this.tokens);
    this.router.navigateByUrl('/tabs', { replaceUrl: true });
  }
  gotoLogin() {
    this.router.navigateByUrl('/login');
  }
  openContactAdmin() {
    this.router.navigateByUrl('/contact-admin');
  }
  ionViewDidEnter() {
    // the root left menu should be disabled on the tutorial page
    this.menu.enable(false);
  }

  ionViewWillLeave() {
    // enable the root left menu when leaving the tutorial page
    this.menu.enable(true);
  }
}
