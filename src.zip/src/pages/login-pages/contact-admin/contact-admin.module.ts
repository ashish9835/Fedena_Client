import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ContactAdminPage } from './contact-admin';
import { ContactAdminPageRoutingModule } from './contact-admin-routing.module';
import { PipesModule } from 'src/pipes/pipes.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        ContactAdminPageRoutingModule,
        PipesModule
    ],
    declarations: [ContactAdminPage]
})
export class ContactAdminPageModule { }
