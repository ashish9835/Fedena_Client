import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { MenuController, NavController } from '@ionic/angular';
import { AppSettings } from 'src/models/app-settings';
import { Profile } from 'src/providers/profile';
import { User } from 'src/providers/user';


@Component({
  selector: 'page-contact-admin',
  templateUrl: 'contact-admin.html',
  styleUrls: ['./contact-admin.scss'],
})
export class ContactAdminPage implements OnInit {
  schoolLogo = AppSettings.SCHOOL_LOGO;
  schoolName: any;
  schoolPlace: any;
  contactPerson: any;
  contactMobile: any;
  contactEmail: any;
  constructor(
    private storage:Storage,
    public navCtrl: NavController,
    private emailComposer: EmailComposer,
    private callNumber: CallNumber,
    public user: User,
    private profileService: Profile,
    private menu: MenuController,
    private router: Router
  ) {
    this.getSchool();
  }
  ngOnInit() {

  }
  getSchool() {
    this.profileService.getSchool()
      .then((data) => {
        console.log('School data received');
        console.log(data);
        const apiResponse: any = data;
        this.schoolName = apiResponse.school_details.school_name;
        this.schoolPlace = apiResponse.school_details.school_address;
        this.contactPerson = apiResponse.contact_details.contact_name;
        this.contactMobile = apiResponse.contact_details.contact_number;
        this.contactEmail = apiResponse.contact_details.contact_email;
      });
      if(AppSettings.MULTI_SCHOOL_MODE){
        this.storage.get('logo_profile_url').then(val=>{this.schoolLogo = val});
      }
  }
  ionViewDidEnter() {
    // the root left menu should be disabled on the tutorial page
    this.menu.enable(false);
  }

  ionViewWillLeave() {
    // enable the root left menu when leaving the tutorial page
    this.menu.enable(true);
  }
  call(number) {
    this.callNumber.callNumber(number, true)
      .then(() => console.log('Launched dialer!'))
      .catch(() => console.log('Error launching dialer'));
  }
  sendMail(emailId) {
    this.emailComposer.isAvailable().then((available: boolean) => {
      if (available) {
        // Now we know we can send
      }
    });

    const email = {
      to: emailId,
      // attachments: [
      //   'file://img/logo.png',
      //   'res://icon.png',
      //   'base64:icon.png//iVBORw0KGgoAAAANSUhEUg...',
      //   'file://README.pdf'
      // ],
      subject: ' ',
      body: ' ',
      isHtml: true,
    };
    this.emailComposer.open(email);
  }
}
