import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DemoLoginEmailPage } from './demo-login-email';

const routes: Routes = [
  {
    path: '',
    component: DemoLoginEmailPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DemoLoginEmailPageRoutingModule {}
