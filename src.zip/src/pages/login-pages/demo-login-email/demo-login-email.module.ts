import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DemoLoginEmailPageRoutingModule } from './demo-login-email-routing.module';

import { DemoLoginEmailPage } from './demo-login-email';
import { PipesModule } from 'src/pipes/pipes.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipesModule,
    DemoLoginEmailPageRoutingModule
  ],
  declarations: [DemoLoginEmailPage]
})
export class DemoLoginEmailPageModule { }