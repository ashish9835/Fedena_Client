import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DemoLoginEmailPage } from './demo-login-email';

describe('DemoLoginEmailPage', () => {
  let component: DemoLoginEmailPage;
  let fixture: ComponentFixture<DemoLoginEmailPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DemoLoginEmailPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DemoLoginEmailPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
