import { Component, OnInit } from '@angular/core';
import { NavController, Platform, MenuController } from '@ionic/angular';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { Router } from '@angular/router';
import { AppSettings } from 'src/models/app-settings';
import { StudentProfileModel } from 'src/models/Authentication/studentProfile';
import { GuardianProfileModel } from 'src/models/Authentication/guardianProfile';
import { EmployeeProfileModel } from 'src/models/Authentication/employeeProfile';
import { School } from 'src/providers/school';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';
import { Authentication } from 'src/providers/providers';
import { CommonService } from 'src/providers/common/common.service';

@Component({
  selector: 'page-demo-login-email',
  templateUrl: 'demo-login-email.html',
  styleUrls: ['./demo-login-email.scss'],
})
export class DemoLoginEmailPage implements OnInit {
  mobile = '';
  otpSecret = '';
  mobileNumber = '';
  account: { username: string, password: string } = {
    username: '',
    password: '',
  };
  schoolLogo = AppSettings.SCHOOL_LOGO;
  schoolName: string;
  schoolPlace: string;
  // Models
  studentProfile: StudentProfileModel;
  guardianProfile: GuardianProfileModel;
  employeeProfile: EmployeeProfileModel;
  // Our translated text strings
  private loginErrorString: string;
  submitted = false;
  isDemoLogin: boolean = false;
  constructor(
    private school: School,
    public event: EventsService,
    public navCtrl: NavController,
    public platform: Platform,
    public user: User,
    private keyboard: Keyboard,
    private authService: Authentication,
    private menu: MenuController,
    private router: Router,
    private commonService: CommonService
  ) {
    this.school.getSchool('name').then((value) => { this.schoolName = value; });
    this.school.getSchool('address').then((value) => { this.schoolPlace = value; });
    this.loginErrorString = 'Login failed';
    if (this.platform.is('ios')) {
      this.keyboard.disableScroll(true);

    }
  }

  ngOnInit() {
  }
  goback() {
    this.router.navigateByUrl('/tutorial', { replaceUrl: true });
  }
  ionViewDidEnter() {
    // the root left menu should be disabled on the tutorial page
    this.menu.enable(false);
  }
  ionViewWillLeave() {
    // enable the root left menu when leaving the tutorial page
    this.menu.enable(true);
  }
  // Attempt to login in through our User service
  doLogin(form) {
    if ((this.account.username === '' || this.account.password === '') && !this.isDemoLogin) {
      this.commonService.presentToast("toast.enter_credentials", 3000);
    }
    this.submitted = true;

    if (form.valid || this.isDemoLogin) {
      console.log(this.account, 'account');
      this.commonService.presentLoading('Validating credentials')
      this.authService.getTokenByUsernameAndPassword(
        this.account.username,
        this.account.password,
      ).subscribe(
        (response) => {
          const apiResponse: any = response;
          this.commonService.dismissloading();
          if (apiResponse.succes === true) {
            console.log(apiResponse);
            this.user.setUsername(apiResponse.token.username);
            this.user.setRole(apiResponse.token.role);
            const accounts = [];
            if (apiResponse.token.role === 'guardian') {
              this.guardianProfile = apiResponse.token.role === 'guardian' ? new GuardianProfileModel(apiResponse.token) : null;
              console.log(this.guardianProfile);
              for (const profile of this.guardianProfile.profile) {
                profile.role = 'guardian';
                profile.token = this.guardianProfile.accessToken;
                profile.userId = this.guardianProfile.userId;
                accounts.push(profile);
              }
              this.user.setMasterUserId(this.guardianProfile.userId);
              this.user.setAccounts(accounts);
              this.user.setAccessTokens([this.guardianProfile]);
              this.user.setAccessToken(
                this.guardianProfile.accessToken + ';student_id=' + this.guardianProfile.profile[0].id,
              );
              this.user.setUser(this.guardianProfile.profile[0]);
              this.user.setUserId(this.guardianProfile.profile[0].id);
              this.event.publish('user:created', this.guardianProfile);
              this.event.publish('swap:enable', [this.guardianProfile]);
            } else if (apiResponse.token.role === 'student') {
              // tslint:disable-next-line:max-line-length

              // tslint:disable-next-line:max-line-length
              this.studentProfile = apiResponse.token.role === 'student' ? new StudentProfileModel(apiResponse.token) : null;
              console.log(this.studentProfile);
              this.user.setMasterUserId(this.studentProfile.userId);
              console.log('Accounts');
              console.log(accounts);
              this.user.setAccounts(accounts);
              this.user.setAccessTokens([this.studentProfile]);

              this.user.setAccessToken(
                this.studentProfile.accessToken + ';student_id=' + this.studentProfile.profile.id,
              );
              this.user.setUser(this.studentProfile.profile);
              this.user.setUserId(this.studentProfile.profile.id);
              this.event.publish('user:created', this.studentProfile);
              this.event.publish('swap:enable', [this.studentProfile]);

            } else {
              this.employeeProfile = new EmployeeProfileModel(apiResponse.token);
              console.log(this.employeeProfile);
              this.user.setUser(this.employeeProfile.profile);
              this.user.setAccessToken(this.employeeProfile.accessToken);
              this.user.setMasterUserId(this.employeeProfile.userId);
              this.user.setUserId(this.employeeProfile.profile.id);
              this.user.setAccessTokens([]);
              console.log('access tokens validaetd');
              this.event.publish('user:created', this.employeeProfile);
              this.event.publish('swap:enable', [this.employeeProfile]);
            }
            this.router.navigateByUrl('/tabs', { replaceUrl: true })
          } else {
            if (apiResponse.error.length > 0) {
              this.loginErrorString = 'toast.invalid_credentials';
            }
            this.commonService.presentToast(this.loginErrorString, 3000)
          }
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.user.errorHandler();
          }
          if (err.status === 403) {
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        },
      );


    }
  }
  doDemoLogin(userrole: string) {
    this.isDemoLogin = true;
    switch (userrole) {
      case 'parent':
        this.account.username = AppSettings.DEMO_PARENT;
        this.account.password = AppSettings.DEMO_PARENT + '123';
        this.doLogin('');
        break;
      case 'student':
        this.account.username = AppSettings.DEMO_STUDENT;
        this.account.password = AppSettings.DEMO_STUDENT + '123';
        this.doLogin('');
        break;
      case 'employee':
        this.account.username = AppSettings.DEMO_EMPLOYEE;
        this.account.password = AppSettings.DEMO_EMPLOYEE + '123'; 
        this.doLogin('');
        break;

    }
  }
  openContactAdmin() {
    this.router.navigateByUrl('/contact-admin');
  }
  openLoginMobile() {
    this.router.navigateByUrl('/login');
  }
}
