import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { OtpEmailPage } from './otp-email';
import { OtpEmailPageRoutingModule } from './otp-email-routing.module';
import { PipesModule } from 'src/pipes/pipes.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        OtpEmailPageRoutingModule,
        PipesModule
    ],
    declarations: [OtpEmailPage]
})
export class OtpEmailPageModule { }