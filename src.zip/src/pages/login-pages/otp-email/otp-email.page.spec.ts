import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { OtpEmailPage } from './otp-email';

describe('OtpEmailPage', () => {
  let component: OtpEmailPage;
  let fixture: ComponentFixture<OtpEmailPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtpEmailPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(OtpEmailPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
