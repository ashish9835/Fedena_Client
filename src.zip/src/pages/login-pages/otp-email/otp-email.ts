import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuController, NavController } from '@ionic/angular';
import { AppSettings } from 'src/models/app-settings';
import { MobileLoginModel } from 'src/models/login/loginMobile';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Authentication } from 'src/providers/providers';
import { School } from 'src/providers/school';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-otp-email',
  templateUrl: 'otp-email.html',
  styleUrls: ['otp-email.scss']
})
export class OtpEmailPage implements OnInit {
  email = '';
  otpSecret = '';
  token: any;
  schoolLogo = AppSettings.SCHOOL_LOGO;
  schoolName: string;
  schoolPlace: string;
  // Our translated text strings
  private loginErrorString: string;
  submitted = false;
  constructor(
    private storage: Storage,
    private school: School,
    public navCtrl: NavController,
    public user: User,
    private event: EventsService,
    private authService: Authentication,
    private menu: MenuController,
    private router: Router,
    private commonService: CommonService
  ) {
    this.storage.get('SCHOOL_NAME').then((value) => {

      console.log('this is something i dunderusnderstaingding for now. - - - ' + value)
      this.schoolName = value;
    });
    this.school.getSchool('address').then((value) => { this.schoolPlace = value; });
    this.loginErrorString = 'Login failed';
    this.validateEmail(this.email);
    if (AppSettings.MULTI_SCHOOL_MODE) {
      this.storage.get('logo_profile_url').then(val => { this.schoolLogo = val });
    }
  }
  ionViewDidLoad() {
    this.school.getSchool('name').then((value) => {

      console.log('this is something i dunderusnderstaingding for now. - - - ' + value)
      this.schoolName = value;
    });
  }
  ngOnInit() { }

  goback() {
    if (AppSettings.MULTI_SCHOOL_MODE) {
      this.navCtrl.back()
    }
    else
      this.router.navigateByUrl('/tutorial', { replaceUrl: true });
  }
  validateEmail(email) {
    // tslint:disable-next-line:max-line-length
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
  }
  doOtpLogin(form) {
    if (this.email.toString().length === 0) {
      this.commonService.presentToast('toast.email_cant_be_blank', 3000);
    }
    else if (!this.validateEmail(this.email)) {
      this.commonService.presentToast('toast.invalid_email', 3000);
    }
    if (this.validateEmail(this.email)) {
      this.commonService.presentLoading('Loading');
      this.authService.getOTPByEmail(this.email).subscribe(
        (response) => {
          console.log(response);
          this.commonService.dismissloading()
          const apiResponse: any = response;
          if (apiResponse.succes === true) {
            this.token = new MobileLoginModel(apiResponse.token);
            this.otpSecret = this.token.otpSecret;
            this.email = this.token.mobileIdentifier;
            this.user.setMasterUserId(apiResponse.token.user_id);
            this.router.navigateByUrl('/otp', { state: { data: { otp_secret: this.otpSecret, email: this.email, } } })
          } else {
            if (apiResponse.error.length > 0) {
              this.loginErrorString = apiResponse.error;
            }
            this.commonService.presentToast('toast.email_otp_login_not_available', 3000);
          }
        },
        (err) => {
          this.commonService.dismissloading()
          console.log(err.status);
          if (err.status === 500) {
            this.user.errorHandler();
          }
          if (err.status === 403) {
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        },
      );
    }
  }

  openContactAdmin() {
    this.router.navigateByUrl('/contact-admin');
  }
  openLoginEmail() {
    this.router.navigateByUrl('/login-email');
  }
  openOtpMobile() {
    this.router.navigateByUrl('/login');
  }
  ionViewDidEnter() {
    // the root left menu should be disabled on the tutorial page
    this.menu.enable(false);
  }

  ionViewWillLeave() {
    // enable the root left menu when leaving the tutorial page
    this.menu.enable(true);
  }


}
