import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuController, NavController } from '@ionic/angular';
import { AppSettings } from 'src/models/app-settings';
import { MobileLoginModel } from 'src/models/login/loginMobile';
import { TutorialModel } from 'src/models/tutorials/tutorials';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Authentication, Profile } from 'src/providers/providers';
import { School } from 'src/providers/school';
import { User } from 'src/providers/user';


@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
  styleUrls: ['./login.scss']
})
export class LoginPage implements OnInit {
  schoolData: TutorialModel;
  mobile = '';
  otpSecret = '';
  mobileNumber = '';
  token: any;
  schoolLogo = AppSettings.SCHOOL_LOGO;
  schoolName: any;
  schoolPlace: any;
  // Our translated text strings
  private loginErrorString: string;
  submitted = false;
  constructor(
    public profileService: Profile,
    public navCtrl: NavController,
    private school: School,
    public user: User,
    private authService: Authentication,
    private menu: MenuController,
    private commonService: CommonService,
    private router: Router,
    private event: EventsService
  ) {
    if (!AppSettings.MULTI_SCHOOL_MODE) {
      this.school.getSchool('name').then((value) => { this.schoolName = value; });
      this.school.getSchool('address').then((value) => { this.schoolPlace = value; });
      this.loginErrorString = 'Login failed';
    } else {
      // this.schoolName = this.params.get('title') ? this.params.get('title') : this.params.get('SCHOOL_NAME');
      this.school.getSchool('name').then((value) => { this.schoolName = value; });
      this.school.getSchool('address').then((value) => { this.schoolPlace = value; });
      this.loginErrorString = 'Login failed';
    }
  }
  ngOnInit() {

  }
  goback() {
    this.router.navigateByUrl('/tutorial', { replaceUrl: true });
  }
  getSchool() {
    this.profileService.getSchool()
      .then((data: any) => {
        console.log('School data received');
        console.log(data);
        console.log(data.error);
        if (data.status === 500) {
          this.user.errorHandler();
        }

        this.schoolData = new TutorialModel(data);
        // this.schoolName = this.schoolData.schoolDetails.schoolName;
        this.schoolPlace = this.schoolData.schoolDetails.schoolAddress;
        this.school.setSchool('name', this.schoolData.schoolDetails.schoolName);
        this.schoolName = this.schoolData.schoolDetails.schoolName;
        this.school.setSchool('currency', this.schoolData.schoolDetails.currencyType);

        // this.show = true;
        this.loginCheck();
      })
      .catch((error) => {
        // if (error.status === 500) {
        //   this.userService.errorHandler();
        // }
        // if (error.status === 403) {
        //   this.errorMessage =
        //     'This institution is currently not available or no longer active.' +
        //     ' Please contact your admin.';
        // }
        // console.log(error);
      });
  }
  loginCheck() {
    this.event.publish('school:load');
    this.user.getAccessToken().then((value) => {
      if (value) {
        this.event.publish('user:refresh');
        this.navCtrl.setDirection('root');
        this.router.navigateByUrl('/tabs', { replaceUrl: true });
      }
      // else this.show = true;
    });
  }
  ionViewDidEnter() {
    // the root left menu should be disabled on the tutorial page
    this.menu.enable(false);
    if (AppSettings.MULTI_SCHOOL_MODE) {
      // this.getSchool()
    }
  }

  ionViewWillLeave() {
    // enable the root left menu when leaving the tutorial page
    this.menu.enable(true);
  }
  doOtpLogin(form) {
    if (this.mobile.toString().length >= 6) {
      this.commonService.presentLoading('Loading')
      this.authService.getOTP(this.mobile).subscribe(
        (response) => {
          console.log(response);
          const apiResponse: any = response;
          this.commonService.dismissloading();
          if (apiResponse.succes === true) {
            this.token = new MobileLoginModel(apiResponse.token);
            console.log(this.token);
            this.otpSecret = this.token.otpSecret;
            this.mobileNumber = this.token.mobileIdentifier;
            this.router.navigateByUrl('/otp', { state: { data: { otp_secret: this.otpSecret, mobile_number: this.mobileNumber, } } })
          } else {
            if (apiResponse.error.length > 0) {
              this.loginErrorString = apiResponse.error[0];
            }
            console.log(apiResponse.error)
            if (this.loginErrorString === "mobile_number is not in records")
              this.commonService.presentToast("toast.mobile_number_is_not_in_records", 3000)
            else this.commonService.presentToast(this.loginErrorString, 3000)

          }
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.user.errorHandler();
          }
          if (err.status === 403) {
            this.router.navigateByUrl('/tutorial')
          }
        },
      );

    }
    if (this.mobile.toString().length === 0) {
      this.commonService.presentToast('toast.mobile_number_cant_be_blank', 5000);
    }
    else if (this.mobile.toString().length < 6) {
      this.commonService.presentToast('toast.invalid_mobile_number', 5000)
    }
  }

  openContactAdmin() {
    this.router.navigateByUrl('/contact-admin');
  }
  openLoginEmail() {
    this.router.navigateByUrl('/login-email');
  }
  openOtpEmail() {
    this.router.navigateByUrl('/otp-email');
  }
}
