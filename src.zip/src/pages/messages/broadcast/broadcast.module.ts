import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from '../../../pipes/pipes.module';
import { BroadcastPage } from './broadcast';
let routes: Routes = [
    {
        path: '',
        component: BroadcastPage
    }
]
@NgModule({
    declarations: [
        BroadcastPage
    ],
    imports: [
        RouterModule.forChild(routes),
        IonicModule,
        FormsModule,
        CommonModule,
        PipesModule
    ],
})



export class BroadcastPageModule { }