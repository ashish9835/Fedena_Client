import { Component, ElementRef } from '@angular/core';
import { IonInfiniteScroll, NavController, NavParams, Platform, PopoverController } from '@ionic/angular';
import { User } from '../../../providers/user';
import { Messages } from '../../../providers/messages';
import { ReplyModel, GroupMessageModel } from '../../../models/messages/messageThreads';
import { DownloadOptions, DownloadProvider } from '../../../providers/downloader';
import { map, finalize } from 'rxjs/operators';
import { CommonService } from 'src/providers/common/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { EventsService } from 'src/providers/events/events.service';
import { MessageOptions } from '../chat-box/message-options/message-options';

@Component({
  selector: 'page-broadcast',
  templateUrl: 'broadcast.html',
  styleUrls: ['broadcast.scss']
})
export class BroadcastPage {
  token: string;
  threadId: number;
  selectedChat: any;
  title: string;
  picture: string;
  message: string = '';
  broadcastMessage: any;
  autoScroller: MutationObserver;
  scrollOffset = 0;
  senderId: string;
  loadingMessages: boolean;
  messagesBatchCounter: number = 0;
  updateMessages: any;
  messages: any = [];
  userId: number;
  tab = 'recipients';
  recipients = [];
  recipientId: any;
  responseCount: number = 0;
  recipientCount: number = 0;
  replyPossible: boolean;
  messageType: string = 'normal';
  broadcast: any;
  recipientsPage: number = 1;
  responsesPageCount: number = 1;
  subject: string;
  primaryMessage: string;
  attachments: any[];
  messageDeleteHandler: () => void;
  constructor(
    public event: EventsService,
    public popover: PopoverController,
    public navCtrl: NavController,
    public user: User,
    public msgs: Messages,
    // public push: Push,
    // private app: App,
    public commonService: CommonService,
    public router: Router,
    private route: ActivatedRoute,
    public downloader: DownloadProvider,
    public platform: Platform
  ) {
    this.commonService.presentLoading('Loading broadcasts')
    let navParams = this.router.getCurrentNavigation().extras.state;
    this.broadcast = navParams.chat;
    console.log(this.broadcast);
    this.subject = this.broadcast.subject;
    this.primaryMessage = this.broadcast.primaryMessage.body;
    this.attachments = this.broadcast.primaryMessage.attachments || [];
    this.title = this.broadcast.title;
    this.threadId = this.broadcast.id;
    this.picture = this.broadcast.picture;
    this.recipientCount = this.broadcast.recipientCount;
    console.log(this.messageType);
    this.user.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.user.getMasterUserId().then((id) => {
          if (id) {
            this.userId = id;
          } else {
            this.commonService.presentAlert('Account not found');
          }
        });
        this.loadRecipients(this.recipientsPage);
        this.getMessages();
        this.event.subscribe('message:received', () => {
          this.getMessages();
        });
        this.messageDeleteHandler = () => {
          this.router.navigateByUrl('/tabs/messages', { state: { messagePageData: { tab: "group_messages" } } });
        }
        this.event.subscribe('message:deleted', this.messageDeleteHandler);
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });

  }

  async presentOptions(myEvent) {
    // tslint:disable-next-line:max-line-length
    const popover = await this.popover.create({
      component: MessageOptions,
      event: myEvent,
      translucent: true,
      componentProps: { id: this.threadId, recipient_id: this.recipientId, token: this.token, messageType: this.messageType }
    });
    return await popover.present();
  }
  loadConversation(message) {
    message.unreadCount = 0;
    this.tab = 'responses';
    console.log('suthin viduim choudade. . . ')
    console.log(message);
    this.broadcast.messages.recipientId = message.recipientId;
    this.broadcast.messages['replyTo'] = { profile: message.profile };
    this.broadcast.messages.replyTo.role = message.role;
    this.broadcast.messages.replyTo.username = message.username;

    console.log(this.broadcast.messages);
    this.router.navigate(['tabs', 'messages', 'chat_box'], { replaceUrl: true, state: { chat: this.broadcast.messages } })

  }
  removeChat(chat) {
    console.log(chat);
    this.msgs.deleteThread(
      this.token, this.threadId, chat.recipientId, 'response_conversation')
      .subscribe(
        (response: any) => {
          this.commonService.dismissloading();
          if (response.success) {
            console.log('Deleted');
            this.messages = this.messages.filter((msg: any) => {
              return msg.recipientId !== chat.recipientId;
            });
            this.responseCount--;
          } else {
            console.log('Not Deleted');
          }
          console.log(response);
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.user.errorHandler();
          }
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        },
      );

  }
  //this function downloads file from an url 
  download(url, type, name) {
    let options: DownloadOptions = new DownloadOptions();
    options.fileName = name;
    options.mimeType = type;
    options.url = url;
    if (this.platform.is('ios')) this.commonService.presentLoading('Downloading attachment')
    if (this.platform.is('android')) this.commonService.presentToast('toast.downloading', 1500);
    this.downloader.download(options).then(destn => {
      console.log("downloaded")
      if (this.platform.is('ios')) this.commonService.dismissloading();
    }).catch(e => {
      if (this.platform.is('ios')) {
        this.commonService.dismissloading();
        this.commonService.presentToast(e, 1500);
      }
    });

  }
  getMessages() {
    return new Promise((resolve, reject) => {
      this.msgs.loadMessages(this.token, this.threadId, this.responsesPageCount)
        .pipe(
          finalize(() => {
            this.commonService.dismissloading();
          })
        )
        .subscribe(
          (response: any) => {
            this.replyPossible = response.reply_possible;
            this.broadcast = new GroupMessageModel(response);
            console.log(this.broadcast)
            this.messages = [...this.messages, ...this.broadcast.messages.responses];
            this.responsesPageCount = this.responsesPageCount + 1;
            this.responseCount = this.broadcast.messages.responseCount;
            resolve();
          },
          (err) => {
            reject();
            if (err.status === 500) {
              this.user.errorHandler();
            }
            if (err.status === 403) {
              this.navCtrl.setDirection('root');
              this.router.navigateByUrl('/tutorial', { replaceUrl: true });
            }
          },
        );
    })
  }
  doInfinite(infiniteScroll) {
    console.log('Begin async operation');
    setTimeout(() => {
      if (this.tab === 'recipients')
        this.loadRecipients(this.recipientsPage).then(
          () => {
            if (this.recipients.length === this.recipientCount) {
              infiniteScroll.enabled = false;
            }
            infiniteScroll.target.complete();
          }
        );
      else
        this.getMessages().then(() => {
          if (this.messages.length === this.responseCount) {
            infiniteScroll.enabled = false;
          }
          infiniteScroll.target.complete();
        })
    }, 2000);
  }

  loadRecipients(page) {
    return new Promise((resolve, reject) => {
      this.msgs.loadBroadcastRecipients(this.token, this.threadId, page)
        .pipe(
          map((res: any) => {
            // let recipients = []
            // if(res.recipients)
            // res.recipients.forEach(recipient=>{
            //   recipient.isDeleted?recipients.push(recipient.profile):
            // })
            return res
          })
        ).subscribe(
          (response: any) => {
            const temp = [];
            response.recipients.forEach((i) => {
              temp.push(new ReplyModel(i));
            });
            this.recipients = this.recipients.concat(temp);
            this.recipientsPage = this.recipientsPage + 1;
            resolve();
          },
          (err) => {
            this.commonService.dismissloading();
            if (err.status === 500) {
              this.user.errorHandler();
            }
            if (err.status === 403) {
              this.navCtrl.setDirection('root');
              this.router.navigateByUrl('/tutorial', { replaceUrl: true });
            }
            reject();
          },
        );
    })
  }
  ionViewDidLeave() {
    this.event.destroy('message:deleted');
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad Chat Box');

  }
  goback() {
    this.navCtrl.back();
  }
}
