import { NgModule } from '@angular/core';
import { ChatBoxPage } from './chat-box';
import { PipesModule } from '../../../pipes/pipes.module';
import { ComponentsModule } from '../../../components/components.module'
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MessageOptionsModule } from './message-options/message-options.module';
let routes: Routes = [
  {
    path:'',
    component: ChatBoxPage
  }
]
@NgModule({
  declarations: [
    ChatBoxPage,
  ],
  imports: [
    RouterModule.forChild(routes),
    IonicModule,
    FormsModule,
    CommonModule,
    PipesModule,
    MessageOptionsModule,
    ComponentsModule//exports attachment-chip
  ],
})



export class ChatBoxPageModule { }
