import { Component, ElementRef, ViewChild, ChangeDetectorRef } from '@angular/core';
import {
  // Events,
  NavController,
  NavParams,
  PopoverController,
  // Content,
  Platform,
  // App,
} from '@ionic/angular';
// import { DownloadProvider, DownloadOptions } from '../../../providers/downloader';
import { User } from '../../../providers/user';
import { Messages } from '../../../providers/messages';
// import { InAppBrowser } from '@ionic-native/in-app-browser';
// import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
// import { File, FileEntry } from '@ionic-native/file';
import { FileProvider } from '../../../providers/file'
// import { FilePath } from '@ionic-native/file-path/ngx'
// import { FileOpener } from '@ionic-native/file-opener/ngx';
import { Keyboard } from '@ionic-native/keyboard';
// import { EmailComposer } from '@ionic-native/email-composer';
// import { CallNumber } from '@ionic-native/call-number';
import { ChatBoxModel } from '../../../models/messages/chatBox';
import { UploadProvider } from '../../../providers/uploader';
// import { Chooser } from '@ionic-native/chooser/ngx';
// import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
// import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Router } from '@angular/router';
import { MessageOptions } from './message-options/message-options';


@Component({
  selector: 'page-chat-box',
  templateUrl: 'chat-box.html',
  styleUrls: ['chat-box.scss']
})

export class ChatBoxPage {
  // @ViewChild(Content) content: Content;
  @ViewChild('attachment_file') inputfile: any;
  @ViewChild('textCompose') textbox: ElementRef;
  textBoxHeight: number = 34;
  attachments: any = []
  totalCompleted = 0;
  totalAttachmentUploadProgress = 0;
  uploadfile: any;
  token: string;
  threadId: number;
  selectedChat: any;
  title: string;
  picture: string;
  message: string = '';
  autoScroller: MutationObserver;
  chatMessage: any;
  scrollOffset = 0;
  senderId: string;
  loadingMessages: boolean;
  messagesBatchCounter: number = 0;
  updateMessages: any;
  messages: any = [];
  userId: number;
  tab = 'responses';
  recipients: any;
  recipientId: any;
  responseCount: number = 0;
  recipientCount: number = 0;
  replyPossible: boolean;
  showFooter: boolean;
  messageType: string = 'normal';
  broadcast: any;
  test: any;
  page: number = 1;
  prevmessages: any;
  temp: any;
  body: any;
  fullUrl: any;
  url: any;
  keyboardHeight:number = 0;
  keyboardHideSubscription:Subscription;
  KeyboardShowSubscription:Subscription;
  showAttachments:boolean = true;
  messageDeleteHandler:(_: any) => void;
  constructor(
    // private cdref:ChangeDetectorRef,
    private fileProvider: FileProvider,
    public platform: Platform,
    private uploadProvider: UploadProvider,
    // private downloader: DownloadProvider,
    // private iab: InAppBrowser,
    public event: EventsService,
    // private keyboard: Keyboard,
    public popover: PopoverController,
    public navCtrl: NavController,
    // private emailComposer: EmailComposer,
    // public callNumber: CallNumber,
    // private el: ElementRef,
    // public navParams: NavParams,
    public user: User,
    public msgs: Messages,
    // private app: App,
    // private screenOrientation: ScreenOrientation,
    public router: Router,
    public commonService: CommonService
  ) {
    this.commonService.presentLoading('Loading chat')
    let navParams = this.router.getCurrentNavigation().extras.state;
    this.selectedChat = navParams.chat;
    console.log('data received on entering chat box');
    console.log(this.selectedChat);
    if (this.selectedChat.isGroup) this.messageType = 'response_conversation';
    this.title = this.selectedChat.replyTo.profile.role === 'guardian' ? this.selectedChat.replyTo.profile.guardianName : this.selectedChat.replyTo.profile.fullName
    this.threadId = this.selectedChat.id;
    this.picture = this.selectedChat.picture;
    this.recipientCount = this.selectedChat.recipientCount;
    if(this.selectedChat.isGroup) this.recipientId = this.selectedChat.recipientId;
    else this.recipientId = this.selectedChat.replyTo.recipientId;
    this.user.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.user.getMasterUserId().then((id) => {
          if (id) {
            this.userId = id;
          } else {
            //this.event.publish('alert:event', 'show_error', 'Account not found');
          this.commonService.presentAlert('Account not found');
}
        });
        this.getMessages();
        this.messageDeleteHandler = () => {
          // this.app.getRootNav().setRoot('TabsPage', { tabIndex: 1 });
        }
        this.event.subscribe('message:deleted', this.messageDeleteHandler);
      } else {
        //this.event.publish('alert:event', 'session_expired', 'Session expired');
      this.commonService.presentAlert('Session expired');
}
    });
    if (this.platform.is('ios')) {
      console.log('scroll disabled.')
      // this.keyboard.disableScroll(true);

    }

  }
  uploadAttachment(fileInfo:any){
   
    this.uploadProvider.upload2(fileInfo).then(status => {
      if (status === "completed" && this.attachments.find(function(val){return val.id === fileInfo.id})) {
        this.totalCompleted++;
        console.log("progesse totale.");
        
        console.log(this.calculateTotalProgress())
      }
    }).catch(err => {

      if(err==="abort"){
        console.log("do not worry.")
      }

    });;
  }
  openFileChooser() {

    this.fileProvider.chooseFile().then((fileInfo: any) => {
      console.log(fileInfo);
      this.attachments.push(fileInfo)
      this.uploadAttachment(fileInfo);
    }).catch(err => {
      if(err===FileProvider.FILE_IS_TOO_LARGE)this.commonService.presentAlert('errors.file_size');
      if(err===FileProvider.UNSUPPORTED_FILE)this.commonService.presentAlert('errors.unsupported_file');
      if(err===FileProvider.ERROR)this.commonService.presentAlert('errors.error');
      // pressed back button without selecting a file.
    });


  }
  resizetextbox(event: any) {
    console.log("seize enteredo")
    console.log(event)
    if (!this.message) {
      this.textBoxHeight = 40;
      this.textbox['_elementRef'].nativeElement.style.height = this.textBoxHeight + 'px';
    }
    if (event.key == "Enter" && this.textBoxHeight != 60) {
      this.textBoxHeight += 10;
      this.textbox['_elementRef'].nativeElement.style.height = this.textBoxHeight + 'px';
    }
  }
  goback() {
    // this.navCtrl.push('TabsPage', { tabIndex: 1 });
    //this.navCtrl.popToRoot();
  }
  teackPush() {

  }
  launch(fullUrl) {
    // tslint:disable-next-line:max-line-length
    // const browser = this.iab.create(fullUrl, '_blank', 'location=no,toolbar=yes,fullscreen=no,closebuttoncaption=CLOSE');
    // browser.show();
  }
  //this function downloads file from an url 
  download(url, type, name) {
    // let options: DownloadOptions = new DownloadOptions();
    // options.fileName = name;
    // options.mimeType = type;
    // options.url = url;
    // if (this.platform.is('ios')) this.commonService.presentLoading('Downloading attachment')
    // if (this.platform.is('android')) this.event.publish('toast:show', 'toast.downloading');
    // this.downloader.download(options).then(destn => {
    //   console.log("downloaded")
    //   if (this.platform.is('ios')) this.commonService.dismissloading();
    // }).catch(e => {
    //   if (this.platform.is('ios')) {
    //     this.commonService.dismissloading();
    //     this.event.publish('toast:show', e);
    //   }
    // });

  }

  async presentOptions(myEvent) {
    // tslint:disable-next-line:max-line-length
    // const popover = this.popover.create('MessageOptions', { id: this.selectedChat.id, recipientId: this.recipientId, token: this.token, messageType: this.messageType });
    // popover.present({
    //   ev: myEvent,
    // });
    // this.event.subscribe('dismiss:overlay',()=>{
    //   if(popover)
    //   popover.dismiss();
    // })
    const popover = await this.popover.create({
      component: MessageOptions,
      // cssClass: this.cssClass,
      event: myEvent,
      translucent: true,
      componentProps:  { id: this.selectedChat.id, recipientId: this.recipientId, token: this.token, messageType: this.messageType }
    });
    this.event.subscribe('dismiss:overlay', () => {
      if (popover)
        popover.dismiss();
    })
    return await popover.present();
  }
  getMessages() {
    if (this.selectedChat.isGroup) {
      console.log('this is a broadcast conversation');
      this.msgs.loadResponseConversation(
        this.token,
        this.selectedChat.id,
        this.selectedChat.recipientId,
        '1',
      ).subscribe(
        (response: any) => {
          console.log('Broadcast reponse conversation messages fetched');
          console.log(response);
          this.commonService.dismissloading();
          this.chatMessage = new ChatBoxModel(response);
          console.log(this.chatMessage);
          this.replyPossible = this.chatMessage.replyPossible;
          this.showFooter = true;
          this.messages = this.chatMessage.messages;
          this.recipientId = this.chatMessage.recipientId;
          this.scrollDown();
          //this.content.scrollToBottom(0);
          // setTimeout(function(){ alert("Hello"); }, 500);

        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.user.errorHandler();
          }
          if (err.status === 403) {
            //this.navCtrl.setRoot('TutorialPage');
          }
        },
      );
    } else {
      this.msgs.loadMessages(this.token, this.threadId, this.page).subscribe(
        (response: any) => {
          this.scrollDown();
          console.log('normal messages fetched');
          this.commonService.dismissloading();
          this.chatMessage = new ChatBoxModel(response);
          this.replyPossible = this.chatMessage.replyPossible;
          this.showFooter = true;
          this.messages = this.chatMessage.messages;
          this.recipientId = this.chatMessage.recipientId;
          this.scrollDown();
          console.log(response);
          //this.content.scrollToBottom(0);
          console.log(this.chatMessage);
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.user.errorHandler();
          }
          if (err.status === 403) {
            //this.navCtrl.setRoot('TutorialPage');
          }
        },
      );
    }
  }
  handleClick(event) {
    if (event.target.getAttribute('target-data') === 'webulr') {
      // this.iab.create(event.target.href, '_blank',
      //   'location=no,toolbar=yes,fullscreen=no,closebuttoncaption=CLOSE');
      // return false;
    }
    if (event.target.getAttribute('target-data') === 'call') {
      const str = event.target.href;
      const index = str.lastIndexOf('/');
      const mobile = str.substring(index + 1);
      console.log(mobile);
      // this.callNumber.callNumber(mobile, true)
      //   .then(() => console.log('Launched dialer!'))
      //   .catch(() => console.log('Error launching dialer'));
      return false;
    }
    if (event.target.getAttribute('target-data') === 'mailopen') {

      // this.emailComposer.isAvailable().then((available: boolean) => {
      //   if (available) {
      //     // Now we know we can send
      //   }
      // });
      const str = event.target.href;
      const index = str.lastIndexOf('/');
      const emailid = str.substring(index + 1);
      console.log(emailid);

      const email = {
        to: emailid,
        subject: ' ',
        body: ' ',
        isHtml: true,
      };
      // this.emailComposer.open(email);
      return false;

    }
  }
  calculateTotalProgress() {
    this.totalAttachmentUploadProgress = ((this.attachments.length === 0 ? 1 : this.totalCompleted) / (this.attachments.length || 1)) * 100;
    return this.totalAttachmentUploadProgress;
  }
  doInfinite(infiniteScroll) {
    console.log('Begin async operation');
    setTimeout(() => {
      console.log('Async operation has ended');
      infiniteScroll.complete();
    }, 500);
  }
  doRefresh(refresher) {
    console.log('Begin async operation ', refresher);
    this.page = this.page + 1;
    setTimeout(() => {
      console.log('Async operation has ended');
      this.msgs.loadMessages(this.token, this.threadId, this.page).subscribe(
        (response: any) => {
          this.temp = this.messages;
          this.chatMessage = new ChatBoxModel(response);
          this.messages = this.chatMessage.messages;
          this.recipientId = this.chatMessage.recipientId;
          this.messages = this.messages.concat(this.temp);
          console.log('previous messages fetched');
          console.log(response);
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.user.errorHandler();
          }
          if (err.status === 403) {
            //this.navCtrl.setRoot('TutorialPage');
          }
        },
      );
      refresher.complete();
    }, 2000);
  }
  sendTextMessage(): void {
    // If message was yet to be typed, abort
    if (!this.message) {
      return;
    }
    this.commonService.presentLoading('Sending message')
    this.msgs.replyMessage(this.token, this.message, this.threadId, this.recipientId, this.attachments).subscribe(
      (response: any) => {
        // this.event.publish('alert:event', 'dismiss_loading')
        this.commonService.dismissloading()
        this.message = '';
        this.attachments = [];
        this.totalCompleted = 0;
        this.getMessages();
        
      },(err)=>{
        this.commonService.dismissloading();
        if (err.status === 500) {
          this.user.errorHandler();
        }
      }
    );

    this.scrollDown();
  }
  ionViewDidLeave() {
    clearInterval(this.updateMessages);
    this.event.destroy('chat:received');
    if(this.platform.is('ios')){
      if(this.KeyboardShowSubscription)this.KeyboardShowSubscription.unsubscribe();
      if(this.keyboardHideSubscription)this.keyboardHideSubscription.unsubscribe(); 
    }
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad Chat Box');

    if (this.platform.is('ios')) {
    //   this.keyboard.disableScroll(true);
    //   this.KeyboardShowSubscription = this.keyboard.onKeyboardShow().subscribe((val:Event)=>{
    //        this.keyboardHeight = val['keyboardHeight'];
    //        console.log(this.keyboardHeight)
    //        this.showAttachments = false;
    //       //  this.cdref.detectChanges();
    //   })
    //  this.keyboardHideSubscription =  this.keyboard.onKeyboardHide().subscribe((val:Event)=>{
    //        this.keyboardHeight = 0;
    //        this.showAttachments = true;
    //       //  this.cdref.detectChanges();
    //   })

    }
    this.subscribeMessages();

    this.event.subscribe('chat:received', (data) => {
      this.page = 1;
      this.getMessages();
      console.log('Welcome', data.notification, 'at', data.time);

    });

  }

  // ionViewWillEnter() {
  //   // this.autoScroll();
  // }
  ionViewWillEnter() {
      // this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT)
    //this.content.scrollToBottom(0);
    // Scroll down to last message while view is being loaded
    setTimeout(() => {
      //this.content.scrollToBottom(0);
    });
  }
  ionViewDidEnter() {
    this.scrollDown();
    setTimeout(() => {
      this.scrollDown();
    });
  }
  ionViewWillLeave(){
      // this.screenOrientation.unlock();
      this.event.publish('dismiss:overlay');  
      this.event.destroy('message:deleted');   
  }
  removeAttachment(file) {
    console.log(file)
    if(file.uploadComplete){
      this.totalCompleted--;
    }
    this.attachments = this.attachments.filter(item => {
      if (item.id !== file.id) return true;
    })
  }
  // private get messagesPageContent(): Element {
  //   return this.el.nativeElement.querySelector('.messages-page-content');

  // }

  // private get messagesList(): Element {
  //   // return this.messagesPageContent.querySelector('.messages');
  // }

  // private get scroller(): Element {
  //   // return this.messagesList.querySelector('.scroll-content');
  // }

  // Subscribes to the relevant set of messages
  subscribeMessages(): void {
    // A flag which indicates if there's a subscription in process
    this.loadingMessages = true;
    // A custom offset to be used to re-adjust the scrolling position once
    // new dataset is fetched
    // this.scrollOffset = this.scroller.scrollHeight;

    this.loadingMessages = false;

    this.scrollDown();
  }

  autoScroll(): MutationObserver {
    const autoScroller = new MutationObserver(this.scrollDown.bind(this));

    autoScroller.observe(this.messages, {
      childList: true,
      subtree: true,
    });

    return autoScroller;
  }
  scrollDown(): void {

    // this.scroller.scrollTop = this.scroller.scrollHeight - this.scrollOffset;
    // // Zero offset for next invocation
    // this.scrollOffset = 30;
  }

  onInputKeypress({ keyCode }: KeyboardEvent): void {
    if (keyCode === 13) {
      this.sendTextMessage();
    }
  }
}
