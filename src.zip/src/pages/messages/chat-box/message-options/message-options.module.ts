import { NgModule } from '@angular/core';
import { MessageOptions } from './message-options';
import { PipesModule } from '../../../../pipes/pipes.module'
import { IonicModule } from '@ionic/angular';
@NgModule({
    declarations: [
        MessageOptions
    ],
    imports: [
        IonicModule,
        PipesModule
    ],
})



export class MessageOptionsModule { }