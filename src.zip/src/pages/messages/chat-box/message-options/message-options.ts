import { Component } from '@angular/core';
import { NavController, NavParams} from '@ionic/angular';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Messages } from '../../../../providers/messages';
import { User } from '../../../../providers/user';
@Component({
  template: `
    <ion-list>
      <ion-item lines="none" (click)="close()" detail-none>{{ 'chat_box.delete_conversation' | translator }}</ion-item>
    </ion-list>
  `,
  styleUrls:['message-options.scss']
})
export class MessageOptions {
  id: number;
  recipientId: number;
  token: string;
  messageType: string;
  constructor(
    private events: EventsService,
    // public navCtrl: NavController,
    // public viewCtrl: ViewController,
    private userService: User,
    private nav: NavParams,
    public commonService: CommonService,
    public msgs: Messages,
  ) {
    this.id = this.nav.get('id');
    this.recipientId = this.nav.get('recipientId');
    this.token = nav.get('token');
    this.messageType = this.nav.get('messageType');
  }
  ionViewDidLeave() {
    // this.navCtrl.pop()

  }
  close() {
    // this.event.publish('alert:event', 'show_loading', 'Deleting conversation');
    this.commonService.presentLoading("Deleting conversation");
    this.msgs.deleteThread(this.token, this.id, this.recipientId, this.messageType).subscribe(
      (response:any) => {
        // this.event.publish('alert:event', 'dismiss_loading');
        this.commonService.dismissloading()
        if (response.success) {
          console.log('Deleted');
          // this.event.publish('alert:event', 'dismiss_loading');
          this.commonService.dismissloading()
          this.events.publish('message:deleted',{});
          // this.viewCtrl.dismiss();
          this.dismissOverlay()
        } else {
          console.log('Not Deleted');
          // this.viewCtrl.dismiss();
          this.dismissOverlay()
        }
        console.log(response);
      },
      (err) => {
        // this.event.publish('alert:event', 'dismiss_loading');
        this.commonService.dismissloading()
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          // this.navCtrl.setRoot('TutorialPage');
        }
      },
    );
  }
  dismissOverlay() {
    this.events.publish('dismiss:overlay', {});
  }
}
