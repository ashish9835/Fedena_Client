import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MessagesPage } from './messages';

const routes: Routes = [
  {
    path: '',
    component: MessagesPage
  },
  {
    path: 'chat_box',
    loadChildren: ()=>import('./chat-box/chat-box.module').then(m=>m.ChatBoxPageModule),
  },
  {
    path: 'new_message',
    loadChildren: ()=>import('./new-message/new-message.module').then(m=>m.NewMessagePageModule)
  },
  {
    path: 'new_broadcast',
    loadChildren: ()=>import('./new-broadcast/new-broadcast.module').then(m=>m.NewBroadcastPageModule)
  },
  {
    path: 'broadcast',
    loadChildren: ()=>import('./broadcast/broadcast.module').then(m=>m.BroadcastPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MessagesPageRoutingModule {}