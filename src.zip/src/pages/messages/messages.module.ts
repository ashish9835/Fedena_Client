import { NgModule } from '@angular/core';
import { MessagesPage } from './messages';
import { PipesModule } from '../../pipes/pipes.module'
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { MessagesPageRoutingModule } from './messages-routing.module';
@NgModule({
    declarations: [
        MessagesPage
    ],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        MessagesPageRoutingModule,
        PipesModule
    ],
})



export class MessagesPageModule { }