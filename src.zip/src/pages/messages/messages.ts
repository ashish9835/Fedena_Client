import { Component } from '@angular/core';
import {
   NavController, 
  //  NavParams,  
   Platform, 
   AlertController, 
   } from '@ionic/angular';
import { User } from '../../providers/user';
import { Messages } from '../../providers/messages';
import { MessageThreadModel } from '../../models/messages/messageThreads';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { ActivatedRoute, Router } from '@angular/router';
export enum BroadcastType{
  Parents='parents',
  Students='students',
  Employees='employees' 
}
@Component({
  selector: 'page-messages',
  templateUrl: 'messages.html',
  styleUrls:['messages.scss']
})
export class MessagesPage {
  updateMessages: any;
  updateGroupMessages: any;
  token = '';
  tab = 'conversations';
  threads: any;
  chats: any;
  groupChats: any;
  role: string;
  page = 1;
  groupPage = 1;
  type: string;
  test: string;
  canMessage: false;
  messagePermissons:any;
  constructor(
    public platform: Platform,
    public alertCtrl: AlertController,
    public commonService: CommonService,
    public event: EventsService,
    public navCtrl: NavController,
    private user: User,
    // public navParams: NavParams,
    public msgs: Messages,
    public router: Router,
    public route: ActivatedRoute
  ) {
    this.init();
    this.event.subscribe('messages_reload', (data) => {
      this.init();
    });
    // this.tab = this.navParams.get('tab')?this.navParams.get('tab'):'conversations';
  }

  private init() {
    this.commonService.presentLoading('Loading conversations');
    this.user.getAccessToken().then((value) => {
      console.log(value);
      if (value) {
        this.token = value;
        if(this.tab === 'conversations')
        { 
          this.loadConversations();
        }else{
         this.loadGroupMessages()
        }
        this.msgs.getMessagePermissons(this.token).subscribe(
          (permissions)=>{
            this.messagePermissons = permissions;
          }
        )
      } else {
        // this.event.publish('alert:event', 'session_expired', 'Session expired');
      }
    });
    this.user.getRole().then((value) => {
      this.role = value;
    });
  }

  ionViewDidLeave() {
    // clearInterval(this.updateMessages)
    // clearInterval(this.updateGroupMessages)
    this.event.destroy('message:received');
    this.event.publish('message:read',"");
  }
  ionViewDidEnter() {
    //clear all the cached recipients data from the messages service.
    this.msgs.clearAllRecipients();

    // Put here the code you want to execute on paga load
    this.event.publish('message:read',"");
    this.event.subscribe('message:received', () => {
      this.loadConversations();
    });
    this.loadConversations();

  }

  showMessages(chat) {
    chat.unreadCount = 0;
    //this.navCtrl.push('ChatBoxPage', { chat });
    this.router.navigate(['chat_box'],{ replaceUrl:false,relativeTo:this.route, state:{chat}})
  }
  showBroadcast(chat) {
    chat.unreadCount = 0;
    //this.navCtrl.push('BroadcastPage', { chat });
    this.router.navigate(['broadcast'],{ replaceUrl:false,relativeTo:this.route, state:{chat}})

  }
  composeMessage(type:string, fab_button ) {
  
    if(type === BroadcastType.Parents || type === BroadcastType.Employees || type === BroadcastType.Students){
        //closes the opened list
        // (fab_button._elementRef.nativeElement as HTMLElement).click()
        //launch compose message page
          // this.navCtrl.push('NewBroadcastPage', { recipients_type: type })
         this.router.navigate(['new_broadcast'], { state: { recipients_type: type }, relativeTo: this.route});


    }
    else 
    this.router.navigate(['new_message'], { relativeTo: this.route});
  }


  loadConversations() {
    this.type = 'personal';
    this.getMessages();
  }
  loadGroupMessages() {
    // clearInterval(this.updateMessages)
    this.type = 'group';
    this.commonService.presentLoading('Loading conversations');
    this.getGroupMessages();
  }
  loadConversation() {
    this.type = 'personal';
    this.commonService.presentLoading('Loading conversations');
    this.getMessages();
  }
  removeChat(chat) {
    console.log(chat);
    this.msgs.deleteThread(this.token, chat.id, '0', 'normal').subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        if (response.success) {
          console.log('Deleted');
          this.getMessages();
        } else {
          console.log('Not Deleted');
        }
        console.log(response);
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          //this.navCtrl.setRoot('TutorialPage');
        }
      },
    );

  }
  getMessages() {
    this.page = 1;
    this.msgs.loadThreads(this.token, this.page).subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        this.canMessage = response.can_message;
        if (this.chats !== response.message_threads) {
          this.chats = [];
          response.message_threads.forEach((i) => {
            this.chats.push(new MessageThreadModel(i));
          });
          // this.chats = response.message_threads;

          console.log(this.chats);
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          //this.navCtrl.setRoot('TutorialPage');
        }
      },
    );
  }

  getGroupMessages() {
    this.groupPage = 1;
    this.msgs.loadGroupThreads(this.token, this.groupPage).subscribe(
      (response: any) => {
        this.groupChats = [];
        this.commonService.dismissloading();
        if (this.chats !== response.message_threads) {
          response.message_threads.forEach((i) => {
            this.groupChats.push(new MessageThreadModel(i));
          });
          // this.groupChats = response.message_threads;
          console.log(this.groupChats);
          console.log('Teacking Group Messages');
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          //this.navCtrl.setRoot('TutorialPage');
        }
      },
    );
  }

  doInfinite(infiniteScroll) {

    console.log('Loading messages');
    setTimeout(() => {
      if (this.type === 'personal') {
        this.page = this.page + 1;
        this.msgs.loadThreads(this.token, this.page).subscribe(
          (response: any) => {
            this.commonService.dismissloading();
            if (this.chats !== response.message_threads) {
              const temp = [];
              response.message_threads.forEach((i) => {
                temp.push(new MessageThreadModel(i));
              });
              this.chats = this.chats.concat(temp);
              console.log(this.chats);
              infiniteScroll.target.complete();
            }
          },
          (err) => {
            this.commonService.dismissloading();
            console.log(err.status);
            if (err.status === 500) {
              this.user.errorHandler();
            }
            if (err.status === 403) {
              //this.navCtrl.setRoot('TutorialPage');
            }
          },
        );
      } else {
        this.groupPage = this.groupPage + 1;
        this.msgs.loadGroupThreads(this.token, this.groupPage).subscribe(
          (response: any) => {
            this.commonService.dismissloading();
            if (this.chats !== response.message_threads) {
              const temp = [];
              response.message_threads.forEach((i) => {
                temp.push(new MessageThreadModel(i));
              });
              this.groupChats = this.groupChats.concat(temp);
              console.log(this.groupChats);
              infiniteScroll.target.complete();
            }
          },
          (err) => {
            this.commonService.dismissloading();
            console.log(err.status);
            if (err.status === 500) {
              this.user.errorHandler();
            }
            if (err.status === 403) {
              //this.navCtrl.setRoot('TutorialPage');
            }
          },
        );
      }
    }, 500);
  }

  loadPage() {
    
    console.log(this.tab);
    if (this.tab === 'group_messages') {
      this.loadGroupMessages();
    } else {
      this.loadConversation();
    }
    this.msgs.getMessagePermissons(this.token).subscribe(
      (permissions)=>{
        this.messagePermissons = permissions;
      }
    )
  }
}
