import { PipesModule } from './../../../pipes/pipes.module';
import { ComponentsModule } from './../../../components/components.module';
import { NgModule } from '@angular/core';
import { NewBroadcastPage } from './new-broadcast';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RecipientsListPage } from './recipients-list/recipients-list';
let routes: Routes = [
  {
    path:'',
    component: NewBroadcastPage
  },
  {
    path: 'recipients_list',
    loadChildren: ()=>import('./recipients-list/recipients-list.module').then(m=>m.RecipientsListPageModule)
  },
  {
    path: 'compose_message',
    loadChildren: ()=>import('../new-message/compose-message/compose-message.module').then(m=>m.ComposeMessagePageModule)
  }
]
@NgModule({
  declarations: [
    NewBroadcastPage,
  ],
  imports: [
    RouterModule.forChild(routes),
    IonicModule,
    FormsModule,
    CommonModule,
    ComponentsModule,
    PipesModule
  ],
})
export class NewBroadcastPageModule {}
