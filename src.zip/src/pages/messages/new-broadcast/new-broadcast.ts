import { User } from './../../../providers/user';
import { ChangeDetectorRef } from '@angular/core';
// import { loadash } from 'lodash';
import { DepartmentListModel, BatchListModel } from './../../../models/messages/newMessage';
import { Messages, RecipientGroup } from './../../../providers/messages';
import { Component } from '@angular/core';
import { NavController, NavParams } from '@ionic/angular';
import { BroadcastType } from '../messages';
import lodash from 'lodash';
import { registerLocaleData } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { EventsService } from 'src/providers/events/events.service';
import { CommonService } from 'src/providers/common/common.service';

/**
 * Generated class for the NewBroadcastPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
@Component({
  selector: 'page-new-broadcast',
  templateUrl: 'new-broadcast.html',
  styleUrls:['new-broadcast.scss']
})
export class NewBroadcastPage {
  title: string;
  broadcastType: BroadcastType;
  departments: DepartmentListModel[] = [];
  recipientGroups: RecipientGroup[] = [];
  filterKey:string = "";
  totalSelectedRecipientCount:number = 0 ;
  isLoaded:boolean = false;
  constructor(
    // public navCtrl: NavController,
    // public navParams: NavParams,
    public commonService: CommonService,
    public messageService: Messages,
    private event:EventsService,
    private user: User,
    public router: Router,
    public route: ActivatedRoute
  ) {
    let navParams = this.router.getCurrentNavigation().extras.state;
    this.broadcastType = navParams.recipients_type;
    switch (this.broadcastType) {
      case 'employees': this.title = 'Broadcast To Employees'; break;
      case 'students': this.title = 'Broadcast To Students'; break;
      case 'parents': this.title = 'Broadcast To Parents'; break;
    }

  }
  filterItems(){
    console.log(this.filterKey)
    const val = this.filterKey;
    this.recipientGroups = this.messageService.getRecipientGroupArray();
    if (val && val.trim() !== '') {
      this.recipientGroups = this.recipientGroups.filter((data) => {
        return (data.title.toLowerCase().indexOf(val.toLowerCase()) > -1);
      });
    }
  }
  ngOnInit() {
    this.commonService.presentLoading('loading');
    this.isLoaded = false;
    //based on the broadcast type load corresponding recipient groups ( Departments, Batches )
    switch (this.broadcastType) {
      case BroadcastType.Employees:
        this.messageService.loadDepartments().subscribe(
          (res: any) => {
            res.departments.forEach(item => {
              let group = new DepartmentListModel(item);
              this.messageService.addRecipientGroup(
                new RecipientGroup({
                  selectionStatus: 'null',
                  groupId: group.id,
                  title: group.name,
                  recipients: {},
                  recipientsCount:group['totalEmployees']
                })
              )
            });
            this.recipientGroups = this.messageService.getRecipientGroupArray();
            this.commonService.dismissloading();
            // this.event.publish('alert:event', 'dismiss_loading');
            this.isLoaded = true;

          },
          err=>{this.errorHandler(err)}
        );
        break;
      case BroadcastType.Parents:
          this.messageService.loadParentsBatches().subscribe(
            (res: any) => {
              res.batches.forEach(item => {
                let group = new BatchListModel(item);
                this.messageService.addRecipientGroup(
                  new RecipientGroup({
                    selectionStatus: 'null',
                    groupId: group.id,
                    title: group.fullName,
                    recipients: {},
                    recipientsCount:group['totalParents']
                  })
                )
              });
              this.recipientGroups = this.messageService.getRecipientGroupArray();
              // this.event.publish('alert:event', 'dismiss_loading');
              this.commonService.dismissloading();

              this.isLoaded = true;
            },
            err=>{this.errorHandler(err)}
          );
          break;
      case BroadcastType.Students:
        this.messageService.loadBatches().subscribe(
          (res: any) => {
            res.batches.forEach(item => {
              let group = new BatchListModel(item);
              this.messageService.addRecipientGroup(
                new RecipientGroup({
                  selectionStatus: 'null',
                  groupId: group.id,
                  title: group.fullName,
                  recipients: {},
                  recipientsCount:group['totalStudents']
                })
              )
            });
            this.recipientGroups = this.messageService.getRecipientGroupArray();
            // this.event.publish('alert:event', 'dismiss_loading');
            this.commonService.dismissloading();
            this.isLoaded = true;
          },
          err=>{this.errorHandler(err)}
        );
        break;

    }

  }
  onGroupItemSelect(state, group: RecipientGroup) {
    group.selectionStatus = state;
    this.totalSelectedRecipientCount = this.getSelectedRecipientCount()
  }
  ionViewWillEnter() {
    this.restoreState()
    this.totalSelectedRecipientCount = this.getSelectedRecipientCount();
    console.log(this.totalSelectedRecipientCount)
    if(this.filterKey && this.filterKey != ""){
      this.filterItems();
    }
  }
  ionViewWillUnload(){
  //  this.messageService.clearAllRecipients();
  }
  goToRecipeints(group) {
    // this.navCtrl.push('RecipientsListPage', { broadcastType: this.broadcastType, group: group });
    this.router.navigate(['recipients_list'], {relativeTo: this.route, state: { broadcastType: this.broadcastType, group: group }})
  }
  restoreState() {
    let cachedData = this.messageService.getRecipientGroupArray();
    if (cachedData.length > 0) this.recipientGroups = cachedData;
  }
  getSelectedRecipientCount(){
    return this.messageService.getSelectedRecipientsCount();
  }
  async composeMessage() {
    //this.messagePermissions 
    let token = await this.user.getAccessToken();
    let permissions = await this.messageService.getMessagePermissons(token).toPromise();
    // this.navCtrl.push('ComposeMessagePage',
    //   { user:this.recipientGroups, group: this.broadcastType , messagePermissions: permissions},
    // );
    this.router.navigate(['compose_message'], {relativeTo:this.route, state: { user:this.recipientGroups, group: this.broadcastType , messagePermissions: permissions}})
  }
  errorHandler(error){

    //  this.event.publish('alert:event', 'dismiss_loading');
     this.commonService.dismissloading();
     this.isLoaded = true;
    //  this.event.publish('toast:show', 'toast.error_try_again_later', 4000);
     this.commonService.presentToast('toast.error_try_again_later', 4000)

  }
}
