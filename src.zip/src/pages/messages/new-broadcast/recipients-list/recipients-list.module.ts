import { PipesModule } from './../../../../pipes/pipes.module';
import { ComponentsModule } from './../../../../components/components.module';
import { NgModule } from '@angular/core';
import { RecipientsListPage } from './recipients-list';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
let routes: Routes = [
  {
    path:'',
    component: RecipientsListPage
  }
]
@NgModule({
  declarations: [
    RecipientsListPage,
  ],
  imports: [
    RouterModule.forChild(routes),
    IonicModule,
    FormsModule,
    CommonModule,
    ComponentsModule,
    PipesModule
  ]
})
export class RecipientsListPageModule {}
