import { DepartmentListModel, EmployeeListModel } from './../../../../models/messages/newMessage';
import { BatchStudentListModel } from './../../../../models/student/student';
import { User } from './../../../../providers/user';
import { BroadcastType } from './../../messages';
import { Component } from '@angular/core';
import { NavController, NavParams } from '@ionic/angular';
import { Recipient, Messages } from '../../../../providers/messages';
import lodash from 'lodash';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Router } from '@angular/router';

/**
 * Generated class for the RecipientsListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-recipients-list',
  templateUrl: 'recipients-list.html',
  styleUrls:['recipients-list.scss']
})
export class RecipientsListPage {
  recipients:Recipient[] = [];
  broadcastType:BroadcastType;
  groupId:number;
  token:string;
  title:string;
  groupSelectionStatus:string = 'null';
  filterKey:string = "";
  selectedCount:number = 0;
  isLoaded:boolean = false;

  constructor(
    public navCtrl: NavController,
    // public navParams: NavParams,
    public messageService:Messages,
    private user:User,
    private event:EventsService,
    public commonService: CommonService,
    public router: Router
    ) {
    let navParams = this.router.getCurrentNavigation().extras.state;
    this.broadcastType = navParams.broadcastType;
    this.groupId = navParams.group.groupId;
    this.title = navParams.group.title;
    this.groupSelectionStatus =  navParams.group.selectionStatus;
    this.user.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
      }
    })
  }
  //filter recipients using the filter key entered to the searchbar
  filterItems(){
    console.log(this.filterKey)
    const val = this.filterKey;
    this.recipients = this.messageService.getRecipientsArray(this.groupId);
    if (val && val.trim() !== '') {
      this.recipients = this.recipients.filter((data) => {
        return (data.title.toLowerCase().indexOf(val.toLowerCase()) > -1);
      });
    }
  }
  ngOnInit() {

    this.commonService.presentLoading('loading')
    // this.isLoaded = true;
    //load group members based on the broadcast type
    switch(this.broadcastType){
      case BroadcastType.Employees:
          this.messageService.loadEmployees(this.token, this.groupId).subscribe(
            (res:any)=>{
              res.employees.forEach(item => {
                let recipient = new EmployeeListModel(item);
                this.recipients.push({
                  selectionStatus: 'null',
                  recipientId: recipient.recipientId,
                  title: recipient.fullName,
                  subtitle: recipient.employeeNumber
                })
              });
              this.restoreState()
              // this.event.publish('alert:event', 'dismiss_loading');
              this.commonService.dismissloading();
              this.isLoaded = true;
            }, 
            err=>{this.errorHandler(err)}
          );
          break;
      case BroadcastType.Parents :
          this.messageService.loadParents(this.token, this.groupId).subscribe(
            (res:any)=>{
              res.parents.forEach(item => {
                this.recipients.push({
                  selectionStatus: 'null',
                  recipientId: item.recipient_id,
                  title: item.full_name,
                  subtitle: item.tag_line
                })
  
              });
              this.restoreState()
              // this.event.publish('alert:event', 'dismiss_loading');
              this.commonService.dismissloading();
              this.isLoaded = true;
            }, 
            err=>{this.errorHandler(err)}
          );
          break;
      case BroadcastType.Students:
        this.messageService.loadStudents(this.token, this.groupId).subscribe(
          (res:any)=>{
            res.students.forEach(item => {
              let recipient = new BatchStudentListModel(item);
              this.recipients.push({
                selectionStatus: 'null',
                recipientId: recipient.recipientId,
                title: recipient.fullName,
                subtitle: recipient.admissionNo
              })

            });
            this.restoreState()
            // this.event.publish('alert:event', 'dismiss_loading');
            this.commonService.dismissloading();
            this.isLoaded = true;
          }, 
          err=>{this.errorHandler(err)}
        );
        break;
        
    }
   
  }
  ionViewWillLeave(){
  }

  onSelectStateChange(state, recipient:Recipient){
    recipient.selectionStatus = state;
    if(state === 'complete')this.selectedCount++;
    else this.selectedCount--;

  }
  getSelectedCount(){
    let count = 0;
    this.recipients.forEach(value=>{
       if(value.selectionStatus === 'complete')
       count++;
    })
    return count;
  }
  saveState(){
    this.messageService.updateRecipients(this.groupId, this.recipients);
  }
  restoreState(){
    let cachedRecipients = this.messageService.getRecipientsArray(this.groupId);
    //merge the newly fetched recipient list with the cached ones.
    this.recipients = lodash.unionBy(cachedRecipients, this.recipients, 'recipientId')
    //update the recipients selection status to the group selection status if 
    //it is complete or null
    this.recipients.forEach((element,index,list) => {
      if(this.groupSelectionStatus==='complete'){
      list[index].selectionStatus = 'complete'
      }
      if(this.groupSelectionStatus === 'null'){
        list[index].selectionStatus = 'null'
      }
    });

    //calculate the selection count
    this.selectedCount = this.getSelectedCount()

    //save the new merged state
    this.saveState()



  }
  errorHandler(error){
    
    // this.event.publish('alert:event', 'dismiss_loading');
    this.commonService.dismissloading();
    this.isLoaded = true;
    // this.event.publish('toast:show', 'toast.error_try_again_later', 4000);

 }
 goBack(){
  //  this.navCtrl.pop()
  this.navCtrl.back();
 }

}