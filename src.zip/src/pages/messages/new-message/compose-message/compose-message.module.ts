import { NgModule } from '@angular/core';
import { ComposeMessagePage } from './compose-message';
import { PipesModule } from '../../../../pipes/pipes.module';
import { ComponentsModule } from '../../../../components/components.module'
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
let routes:Routes = [
    {
        path: '',
        component: ComposeMessagePage
    }
]
@NgModule({
    declarations: [
        ComposeMessagePage
    ],
    imports: [
        RouterModule.forChild(routes),
        CommonModule,
        IonicModule,
        FormsModule,
        PipesModule,
        ComponentsModule
    ],
})



export class ComposeMessagePageModule { }