import { Component, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { NavController, Platform } from '@ionic/angular';
import { Messages } from '../../../../providers/messages';
import { User } from '../../../../providers/user';
import { Keyboard } from '@ionic-native/keyboard';
import { ComposeMessageModel } from '../../../../models/messages/composeMessage';
import { MessageThreadModel } from '../../../../models/messages/messageThreads';
// import { TranslateService } from '@ngx-translate/core';
import { FileProvider } from '../../../../providers/file';
import { UploadProvider } from '../../../../providers/uploader';
// import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

export class ComposeMessagePageState{
  subject: string;
  message: string;
  messageParent: boolean;
  messageStudent: boolean;
  enableReplies: boolean;
  attachments:any;
  textBoxHeight: number;
  constructor(
    subject: string,
    message: string,
    messageParent: boolean,
    messageStudent: boolean,
    enableReplies: boolean,
    attachments:any,
    textBoxHeight: number
  ){
    this.subject = subject;
    this.message = message;
    this.messageParent = messageParent;
    this.messageStudent = messageStudent;
    this.enableReplies = enableReplies;
    this.attachments = attachments;
    this.textBoxHeight = textBoxHeight;
  }
}

@Component({
  selector: 'page-compose-message',
  templateUrl: 'compose-message.html',
  styleUrls:['compose-message.scss']
})
export class ComposeMessagePage {
  @ViewChild('textCompose') textbox: ElementRef;
  @ViewChild('ionFooter') footer: ElementRef;
  textBoxHeight: number = 40;
  token = '';
  attachments: any[] = [];
  totalCompleted = 0;
  totalAttachmentUploadProgress = 0;
  userId = '';
  recipientIds: any;
  image = 'default';
  name = 'Broadcast';
  result: any;
  role: string = '';
  recipient: any;
  messageThread: any;
  subject: any;
  message: any;
  messageParent: boolean;
  messageStudent: boolean;
  sendTo: string;
  enableReplies: boolean;
  group: any;
  sending: boolean;
  isGroupMessage: boolean = false;
  hideToggleOptions: boolean = true;
  hideParentToggle: boolean = false;
  hideStudentToggle: boolean = false;
  hideBothToggle: boolean = true;
  hideReplyToggle: boolean = true;
  disableBoth: boolean = false;
  messagePermissions: any;
  keyboardHeight:number = 0;
  keyboardHideSubscription:Subscription;
  KeyboardShowSubscription:Subscription;
  showAttachments:boolean = true;
  messageTextBoxRows:number = 40;
  reduceMessageBoxHeight: boolean;
  totalRecipients: number;
  constructor(
    private uploadProvider: UploadProvider,
    private fileProvider: FileProvider,
    public translate: TranslateService,
    // private keyboard: Keyboard,
    public platform: Platform,
    public navCtrl: NavController,
    public user: User,
    public messages: Messages,
    // private screenOrientation: ScreenOrientation,
    // private cdref:ChangeDetectorRef,
    public commonService: CommonService,
    public router: Router,
    public route: ActivatedRoute
  ) {

    this.commonService.presentLoading('Loading')
    let navParams = this.router.getCurrentNavigation().extras.state
    this.recipient = navParams.user;
    this.group = navParams.group;
    this.messagePermissions = navParams.messagePermissions
    this.user.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.user.getUserId().then((id) => {
          if (id) {
            this.userId = id;
            if (this.recipient.fullName) {
              if (this.recipient.role === 'student' || this.recipient.role === 'guardian') {
                this.user.getRole().then((role) => {
                  if (role === 'employee' || role === 'admin') {
                    this.messages.getIndividualPermissions(
                      this.token, this.recipient.recipientId,
                    ).subscribe(
                      (response: any) => {
                        this.result = new ComposeMessageModel(response.result);
                        if (this.result.status) {
                          console.log('individual permission cheking');
                          this.hideBothToggle = false;
                          this.hideToggleOptions = false;
                          this.hideParentToggle = false;
                          this.hideStudentToggle = false;
                          if (this.recipient.role === 'student') this.messageStudent = true;
                          if (this.recipient.role === 'guardian') this.messageParent = true;
                          if (this.result.disableParent || this.result.disableStudent) {
                            this.disableBoth = true;
                          }

                        }
                        console.log(this.result);
                      },
                      (err) => {
                        this.commonService.dismissloading();
                        console.log(err.status);
                        if (err.status === 500) {
                          this.user.errorHandler();
                        }
                        if (err.status === 403) {
                          //this.navCtrl.setRoot('TutorialPage');
                        }
                      },
                    );
                  }
                });

              }
              this.recipientIds = this.recipient.recipientId;
              this.image = this.recipient.profilePhoto;
              this.name = this.recipient.fullName;
              this.translate.get('compose_message.role', { role: this.recipient.role }).subscribe(
                val => this.role = val
              )
              this.enableReplies = true;
              this.hideReplyToggle = true;
            } else {
              console.log(this.messages.getSelectedBroadcastRecipients());
              this.totalRecipients = this.messages.getSelectedRecipientsCount();
              this.hideBothToggle = false;
              if (this.group === 'students') {
                this.messageStudent = true;
                this.hideStudentToggle = true;
                if (!this.messagePermissions.canMessageParents) this.hideBothToggle = true;
              }
              if (this.group === 'parents') {
                this.messageParent = true;
                this.hideParentToggle = true;
                if (!this.messagePermissions.canMessageStudents) this.hideBothToggle = true;
              }
              if (this.group === 'employees') {
                this.hideBothToggle = true;
              }
              this.hideReplyToggle = false;
              this.isGroupMessage = true;
              this.enableReplies = false;
            }

            this.commonService.dismissloading();
            console.log(this.recipient);
          } else {
            this.commonService.presentAlert('Account not found');
          }
        });

      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
    if (this.platform.is('ios')) {
      // this.keyboard.disableScroll(false);
    }

  }
  calculateTotalProgress() {
    this.totalAttachmentUploadProgress = ((this.attachments.length === 0 ? 1 : this.totalCompleted) / (this.attachments.length || 1)) * 100
    return this.totalAttachmentUploadProgress;
  }
  uploadAttachment(fileInfo:any){
   
    this.uploadProvider.upload2(fileInfo).then(status => {
      if (status === "completed" && this.attachments.find(function(val){return val.id === fileInfo.id})) {
        this.totalCompleted++;
        console.log("progesse totale.");
        console.log(this.calculateTotalProgress())
      }
    }).catch(err => {

      if(err==="abort"){
        console.log("do not worry.")
      }

    });;
  }
  openFileChooser() {

    this.fileProvider.chooseFile().then((fileInfo: any) => {
      console.log(fileInfo);
      this.attachments.push(fileInfo);
      this.uploadAttachment(fileInfo);
    }).catch(err => {
      if(err===FileProvider.FILE_IS_TOO_LARGE)
      this.commonService.presentToast('errors.file_size', 2000);
      if(err===FileProvider.UNSUPPORTED_FILE)
      this.commonService.presentToast('errors.unsupported_file', 2000);
      if(err===FileProvider.ERROR)
      this.commonService.presentToast('errors.error', 2000);
    });


  }
  removeAttachment(file) {
    console.log(file)
    if(file.uploadComplete){
      this.totalCompleted--;
    }
    this.attachments = this.attachments.filter(item => {
      if (item.id !== file.id) { 
        return true
      };
    })
  }
  sendtoparent(value) {
    if (!value) {
      this.messageStudent = true;
      this.sendTo = 'student';
    }
  }
  sendtostudent(value) {
    if (!value) {
      this.messageParent = true;
      this.sendTo = 'parent';
    }
  }
  ionViewDidEnter() {
    console.log("textbox:::::")
    console.log(this.textbox['_elementRef'].nativeElement.getElementsByClassName("text-input")[0].scrollHeight)
    this.textbox['_elementRef'].nativeElement.style.height = "40px";
    this.restoreState();
  }
  resizetextbox(event: any) {
    if(event.keyCode === 8){ //backspace event
      let content = event.srcElement.value;
      if(content.trim() === ''){
        this.textbox['_elementRef'].nativeElement.style.height = 40 + 'px';
        return;
      }
      if(this.reduceMessageBoxHeight){//if reduce height flag is set reduce the text box height.

        let elementHeight = Number.parseInt(this.textbox['_elementRef'].nativeElement.style.height.split('px')[0]);
        this.textbox['_elementRef'].nativeElement.style.height = (elementHeight - 16) + 'px';

        this.reduceMessageBoxHeight = false;
        return;
      }
      //if the last char of the content is '\n', the next backspace event will remove a line
      
      let lastChar = content.charAt(content.length-1);
      if(lastChar === "\n"){//next backspace event will  remove a line
        this.reduceMessageBoxHeight = true;//set the reduce height flag. Next backspace will remove a line and also reduce the height of the text box.
      }
    }
    if(event.keyCode === 13){// 'Enter' event, increase the height to the scroll height
      this.textBoxHeight = (this.textbox['_elementRef'].nativeElement.getElementsByClassName("text-input")[0] as HTMLElement).scrollHeight;
      this.textbox['_elementRef'].nativeElement.style.height = this.textBoxHeight + 'px';
      return;
    }
   
    
  }
  cancelMessage(){
    //this.navCtrl.popToRoot();
    this.navCtrl.navigateRoot('/tabs/messages');
  }
  sendMessage() {
    if (!this.sending) {
      this.sending = true;
      if (this.subject && this.message && this.subject.trim() != '' && this.message.trim() != '') {
        this.commonService.presentLoading('Sending message')
        if(this.isGroupMessage)this.recipientIds = this.messages.getSelectedBroadcastRecipients();
        if (this.messageStudent && this.messageParent) this.sendTo = 'both';
        if (this.messageStudent && !this.messageParent) this.sendTo = 'student';
        if (!this.messageStudent && this.messageParent) this.sendTo = 'parent';
        if(!this.messageStudent && !this.messageParent) this.sendTo = 'employee'
        this.messages.sendMessage(
          this.token,
          this.isGroupMessage?(this.group==='employees'?{'departments':this.recipientIds}:{'batches':this.recipientIds}):this.recipientIds,
          this.subject,
          this.message,
          this.isGroupMessage,
          this.enableReplies,
          this.sendTo,
          this.attachments
        ).subscribe(
          (response: any) => {
            this.commonService.dismissloading();
            this.sending = false;
            console.log(response);
            this.attachments = [];
            this.totalCompleted = 0;
            this.messageThread = new MessageThreadModel(response.message_thread);
            if (this.isGroupMessage) 
            {
              //this.navCtrl.push('TabsPage', { tabIndex: 1 });
            }
            else{
              this.navCtrl.navigateBack('/tabs/messages',{state:{chat: this.messageThread}}).then(
                ()=>{
                  this.navCtrl.navigateForward('/tabs/messages/chat_box',{state:{chat: this.messageThread}});
                }
              );
            }
            // this.navCtrl.push('ChatBoxPage', { chat: this.messageThread });
          },
          (err) => {
            console.log(err)
            this.commonService.dismissloading();
            console.log(err.status);
            if (err.status === 500) {
              this.user.errorHandler();
            }
            if (err.status === 403) {
              //this.navCtrl.setRoot('TutorialPage');
            }
          },
        );
        console.log(this.subject + this.message);
      } else {
        this.commonService.presentAlert('Enter a subject and message')
        this.sending = false;
      }
    }
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ComposeMessage');
    // if (this.platform.is('ios')) {
    //   this.keyboard.disableScroll(true);
    //   this.keyboard.onKeyboardShow().subscribe((val:Event)=>{
    //        this.keyboardHeight = val['keyboardHeight'];
    //        this.showAttachments = false;
    //       //  this.cdref.detectChanges();
    //   })
    //   this.keyboard.onKeyboardHide().subscribe((val:Event)=>{
    //        this.keyboardHeight = 0;
    //        this.showAttachments = true;
    //       //  this.cdref.detectChanges();
    //   })

    // }

  }
  ionViewDidLeave() {
    if (this.platform.is('ios')) {
      // this.keyboard.disableScroll(false);
      if(this.KeyboardShowSubscription)this.KeyboardShowSubscription.unsubscribe();
      if(this.keyboardHideSubscription)this.keyboardHideSubscription.unsubscribe(); 
    }
  }

  goback() {
    this.navCtrl.back();
    console.log('Click on button Test Console Log');
  }
   ionViewWillEnter(){
    // this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    // this.screenOrientation.lock('portrait');
   }
   ionViewWillLeave(){
    // this.screenOrientation.unlock()
   }
   restoreState(){
     let data:ComposeMessagePageState = this.messages.getComposeMessageData();
    //  console.log(data)
    if(data){
     this.subject = data.subject;
     this.message = data.message;
     this.messageParent = data.messageParent;
     this.messageStudent = data.messageStudent;
     this.enableReplies = data.enableReplies;
     this.attachments = data.attachments;
     this.attachments.forEach(a=>{
       if(a.uploadComplete)this.totalCompleted++;
     })
     this.textBoxHeight = data.textBoxHeight;
     this.textbox['_elementRef'].nativeElement.style.height = this.textBoxHeight + 'px';
     this.messages.clearComposeMessageData();
    }
     

   }
   goToEditRecipients(){
     
    this.messages.saveComposeMessageData(new ComposeMessagePageState(
      this.subject,
      this.message,
      this.messageParent,
      this.messageStudent,
      this.enableReplies,
      this.attachments,
      this.textBoxHeight)
    )
    //this.navCtrl.popTo('NewBroadcastPage')
    this.navCtrl.back();

    
   }
}
