import { NgModule } from '@angular/core';
import { NewMessagePage } from './new-message';
import { PipesModule} from '../../../pipes/pipes.module'
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { NewMessagePagePageRoutingModule } from './new-message-routing-module';
@NgModule({
    declarations: [
        NewMessagePage
    ],
    imports: [
        CommonModule,
        IonicModule,
        FormsModule,
        NewMessagePagePageRoutingModule,
        PipesModule
    ],
})



export class NewMessagePageModule { }