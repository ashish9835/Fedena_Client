import { Component } from '@angular/core';
import { User } from '../../../providers/user';
import { Messages } from '../../../providers/messages';
import { NewMessageStudentModel, 
          NewMessageEmployeeModel, 
          EmployeeListModel,
          DepartmentListModel,
          BatchListModel,
          RecipientListModel} from '../../../models/messages/newMessage';
import { ProfileModel } from '../../../models/messages/messageThreads';
import { EventsService } from 'src/providers/events/events.service';
import { CommonService } from 'src/providers/common/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { relativeTimeThreshold } from 'moment';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'page-new-message',
  templateUrl: 'new-message.html',
  styleUrls: ['new-message.scss']
})
export class NewMessagePage {
  items;
  contacts: any;
  quickContacts: any;
  newMessage: any;
  token = '';
  userId = '';
  tab = 'recent';
  selectedDepartment = { id: '' };
  selectedBatch = { id: '' };
  selectedParentsBatch = { id: '' };
  departments: any;
  batches: any;
  parentsBatches: any;
  employees: any;
  students: any;
  parents: any;
  group: any;
  role: string;
  admin: any;
  showFrequent = false;
  canMessageEmployees = false;
  canMessageStudents = false;
  canMessageParents = false;
  hideStudentContacts = true;
  hideTeacherContacts = true;
  selects = ['1', '2', '3', '4'];
  search: boolean;
  searchKey: string = '';
  searchResults: any;
  hideNoResults: boolean = true;
  singleTab: boolean;
  messagePermissions: any;
  constructor(
    public user: User,
    public navCtrl: NavController,
    // public navParams: NavParams,
    public messages: Messages,
    public router: Router,
    public route: ActivatedRoute,
    public commonService: CommonService
  ) {
    this.initializeItems();
    // this.event.publish('alert:event', 'show_loading', 'Loading contacts');
    this.commonService.presentLoading('Loading contacts');
    this.user.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.user.getUserId().then((id) => {
          if (id) {
            this.userId = id;
            this.loadQuickContacts();
          } else {
            // this.event.publish('alert:event', 'show_error', 'Account not found');
            this.commonService.presentAlert('Account not found');
          }
        });
        this.user.getRole().then((role) => {
          this.role = role;
        });

      } else {
        // this.event.publish('alert:event', 'session_expired', 'Session expired');
        this.commonService.presentAlert('Session expired');
        setTimeout(() => {

        }, 0);
      }
    });

    // this.event.publish('alert:event', 'dismiss_loading');
    this.commonService.dismissloading();

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MessageStudents');
  }
  goback() {
    // this.navCtrl.push('TabsPage', { tabIndex: 1 });
    this.navCtrl.back();
  }
  loadDepartments() {
    this.selectedDepartment = null;
    // this.event.publish('alert:event', 'show_loading', 'Loading departments');
    this.commonService.presentLoading('Loading departments');
    this.messages.loadDepartments(this.token).subscribe(
      (response: any) => {
        console.log(response);
        if (response.success === true) {
          const temp = [];
          response.departments.forEach((i) => {
            temp.push(new DepartmentListModel(i));
          });
          this.departments = temp;
          console.log(this.departments);
          this.selectedDepartment = null;
          this.selectedDepartment = this.departments[0];
          console.log('Selected Department:', this.selectedDepartment);
          this.loadEmployees(false);
        }
      },
      (err) => {
        // this.event.publish('alert:event', 'dismiss_loading');
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          // this.navCtrl.setRoot('TutorialPage');
        }
      },
    );
  }
  loadBatches() {
    this.selectedBatch = null;
    // this.event.publish('alert:event', 'show_loading', 'Loading batches');
    this.commonService.presentLoading('Loading batches');
    this.messages.loadBatches(this.token).subscribe(
      (response: any) => {
        console.log(response);
        if (response.success === true) {
          const temp = [];
          response.batches.forEach((i) => {
            temp.push(new BatchListModel(i));
          });
          this.batches = temp;
          console.log(this.batches);
          this.selectedBatch = null;
          this.selectedBatch = this.batches[0];
          console.log('Selected Batch:', this.selectedBatch);
          this.loadStudents(false);
        }
      },
      (err) => {
        // this.event.publish('alert:event', 'dismiss_loading');
        this.commonService.dismissloading()
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          // this.navCtrl.setRoot('TutorialPage');
        }
      },
    );
  }
  loadParentsBatches() {
    this.selectedParentsBatch = null;
    // this.event.publish('alert:event', 'show_loading', 'Loading batches');
    this.commonService.presentLoading('Loading batches');
    this.messages.loadParentsBatches(this.token).subscribe(
      (response: any) => {
        console.log(response);
        if (response.success === true) {
          const temp = [];
          response.batches.forEach((i) => {
            temp.push(new BatchListModel(i));
          });
          this.parentsBatches = temp;
          this.selectedParentsBatch = null;
          this.selectedParentsBatch = this.parentsBatches[0];
          console.log('Selected Parents Batch:', this.selectedParentsBatch);
          this.loadParents(false);
        }
      },
      (err) => {
        // this.event.publish('alert:event', 'dismiss_loading');
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          // this.navCtrl.setRoot('TutorialPage');
        }
      },
    );
  }
  loadEmployees(value) {
    // if (value === true) this.event.publish('alert:event', 'show_loading', 'Loading employees');
    if (value === true) this.commonService.presentLoading('Loading employees');

    this.messages.loadEmployees(this.token, this.selectedDepartment.id).subscribe(
      (response: any) => {
        console.log(response);
        if (response.success === true) {
          const temp = [];
          response.employees.forEach((i) => {
            temp.push(new EmployeeListModel(i));
          });
          this.employees = temp;
          console.log(this.employees);
          console.log(`Selected Department is:`, this.selectedDepartment);
          // this.event.publish('alert:event', 'dismiss_loading');
          this.commonService.dismissloading();
        }
      },
      (err) => {
        // this.event.publish('alert:event', 'dismiss_loading');
        this.commonService.dismissloading();

        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          // this.navCtrl.setRoot('TutorialPage');
        }
      },
    );
  }
  loadStudents(value) {
    // if (value === true) this.event.publish('alert:event', 'show_loading', 'Loading students');
    if (value === true) this.commonService.presentLoading('Loading students');
    this.messages.loadStudents(this.token, this.selectedBatch.id).subscribe(
      (response: any) => {
        console.log(response);
        if (response.success === true) {
          const temp = [];
          response.students.forEach((i) => {
            temp.push(new ProfileModel(i));
          });
          this.students = temp;
          console.log(this.students);
          console.log(`Selected Course is:`, this.selectedBatch);

          // this.event.publish('alert:event', 'dismiss_loading');
          this.commonService.dismissloading()
        }
      },
      (err) => {
        // this.event.publish('alert:event', 'dismiss_loading');
        this.commonService.dismissloading()
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          // this.navCtrl.setRoot('TutorialPage');
        }
      },
    );
  }
  loadParents(value) {
    if (value === true) this.commonService.presentLoading('Loading parents')
    this.messages.loadParents(this.token, this.selectedParentsBatch.id).subscribe(
      (response: any) => {
        console.log(response);
        if (response.success === true) {
          const temp = [];
          response.parents.forEach((i) => {
            temp.push(new ProfileModel(i));
          });
          this.parents = temp;
          console.log(this.parents);
          this.commonService.dismissloading();
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          // this.navCtrl.setRoot('TutorialPage');
        }
      },
    );
  }
  switchContactstab() {
    if (this.contacts.students) {
      if (!this.showFrequent) this.tab = 'students_contacts';
      this.hideStudentContacts = false;
      if (this.contacts.teachers.length) this.hideTeacherContacts = false;
    } else if (this.contacts.teachers) {
      if (!this.showFrequent) this.tab = 'teachers_contacts';
      this.hideTeacherContacts = false;
    }
  }
  loadQuickContacts() {
    this.messages.getQuickContacts(this.token).subscribe(
      (response: any) => {
        if (this.role === 'student' || this.role === 'parent') {
          this.newMessage = new NewMessageStudentModel(response); 
        } else this.newMessage =  new NewMessageEmployeeModel(response);
        
        this.messagePermissions = this.newMessage.messagePermissions;
        this.showFrequent = this.messagePermissions.showFrequent;
        this.canMessageEmployees = this.messagePermissions.canMessageEmployees;
        this.canMessageStudents = this.messagePermissions.canMessageStudents;
        this.canMessageParents = this.messagePermissions.canMessageParents;
        this.admin = this.newMessage.admin;
        this.contacts = this.newMessage.recipients.filter((item)=>{
          switch(item.role){
            case 'student' : return this.canMessageStudents;
            case 'guardian' : return this.canMessageParents; 
            case 'employee' : return this.canMessageEmployees; 
            case 'admin' : return true; 
            default: return false;
          }
        });
        

        if (this.contacts.frequent) this.quickContacts = this.contacts.frequent;
        else this.quickContacts = this.contacts;
        this.switchContactstab();
        console.log(this.quickContacts);
        if (this.quickContacts.length === 0 && (this.admin && this.admin.length == 0)) {
          this.showFrequent = false;
          if (this.canMessageEmployees) {
            this.tab = 'employees';
            this.loadDepartments();
          } else {
            if (this.canMessageStudents) {
              this.tab = 'students';
              this.loadBatches();
            } else {
              if (this.canMessageParents) {
                this.tab = 'parents';
                this.loadParentsBatches();
              } else {
                this.switchContactstab();
              }
            }
          }
        }
        let i = 0;
        // tslint:disable-next-line:no-increment-decrement
        if (this.canMessageEmployees) i++;
        // tslint:disable-next-line:no-increment-decrement
        if (this.canMessageStudents) i++;
        // tslint:disable-next-line:no-increment-decrement
        if (this.canMessageParents) i++;
        // tslint:disable-next-line:no-increment-decrement
        if (this.showFrequent) i++;
        // tslint:disable-next-line:no-increment-decrement
        if (!this.hideTeacherContacts) i++;
        // tslint:disable-next-line:no-increment-decrement
        if (!this.hideStudentContacts) i++;
        if (i === 1) this.singleTab = true;
        //this.event.publish('alert:event', 'dismiss_loading');
        this.commonService.dismissloading()
        console.log(this.newMessage);
      },
      (err) => {
        //this.event.publish('alert:event', 'dismiss_loading');
        this.commonService.dismissloading()
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          // this.navCtrl.setRoot('TutorialPage');
        }
      },
    );

  }

  initializeItems() {
    this.items = [
      'Amsterdam',
      'Bogota',
    ];
  }

  getItems() {
    this.hideNoResults = true;
    console.log(this.searchKey);
    if (this.searchKey === '') {
      this.search = false;
      this.searchResults = [];
    } else {
      this.search = true;
      this.messages.getSearchResults(this.token, this.searchKey).subscribe(
        (response: any) => {
          console.log(response);
          const temp = [];
          response.results.forEach((i) => {
            temp.push(new RecipientListModel(i));
          });
          this.searchResults = temp;
          console.log(this.searchResults);
          if (this.searchResults.length === 0) this.hideNoResults = false;
          
        },
        (err) => {
          //this.event.publish('alert:event', 'dismiss_loading');
          this.commonService.dismissloading()
          console.log(err.status);
          if (err.status === 500) {
            this.user.errorHandler();
          }
          if (err.status === 403) {
            // this.navCtrl.setRoot('TutorialPage');
          }
        },
      );
    }



  }

  composeMessage(user, group) {
    // this.navCtrl.push('ComposeMessagePage',
    //   { user, group, messagePermissions: this.messagePermissions },
    // );
    this.router.navigate(['compose_message'],{ 
      relativeTo: this.route,
      state: { user, group, messagePermissions: this.messagePermissions 
    }})
    
  }

}
