import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { MyClassPage } from './my-class';
import { MyClassPageRoutingModule } from './my-class-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipesModule,
    MyClassPageRoutingModule
  ],
  declarations: [MyClassPage]
})



export class MyClassPageModule { }
