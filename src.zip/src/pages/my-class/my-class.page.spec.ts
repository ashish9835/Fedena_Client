import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { MyClassPage } from './my-class';

describe('MyClassPage', () => {
  let component: MyClassPage;
  let fixture: ComponentFixture<MyClassPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MyClassPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MyClassPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
