import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController, Platform } from '@ionic/angular';
import { EmployeeClassModel } from 'src/models/my-class/employeeClass';
import { Batch } from 'src/providers/batch';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';


@Component({
  selector: 'page-my-class',
  templateUrl: 'my-class.html',
  styleUrls: ['my-class.scss']
})
export class MyClassPage implements OnInit {
  batches = [];
  tempBatches = [];
  token = '';
  userid = '';
  attendanceType: string;
  page: number = 1;
  disableInfiniteScroll: boolean = false;
  constructor(
    public navCtrl: NavController,
    public platform: Platform,
    private batchService: Batch,
    private userService: User,
    private event: EventsService,
    private commonService: CommonService,
    private router: Router
  ) {
    this.init();
    this.event.subscribe('class_reload', (data) => {
      this.init();
    });
  }
  ngOnInit() {

  }
  private init() {
    this.disableInfiniteScroll = false;
    this.page = 1;
    this.commonService.presentLoading('Loading batches')
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          if (id) {
            this.userid = id;
            this.loadbatches();
          } else {
            this.commonService.presentAlert('Account not found')
          }
        });
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }

  loadbatches() {
    this.batchService.loadBatchList(this.token, this.userid, this.page).subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        console.log(response);
        if (response.success === true) {
          this.batches = [];
          response.batches.forEach((i) => {
            this.batches.push(new EmployeeClassModel(i));
          });
          console.log(this.batches);
          this.attendanceType = response.attendance_type;
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  pushStudentPage(batch) {
    this.router.navigateByUrl('/students', { state: { 'batch': batch } });
  }
  pushSubjectsPage(batch) {
    this.router.navigateByUrl('/batch-subjects', { state: { 'batch': batch } });
  }
  pushAttendanceReportPage(batch) {
    this.router.navigateByUrl('/attendance-report', { state: { 'batch': batch } });
  }
  pushMarkAttendancePage(batch) {
    this.router.navigateByUrl('/academic-days', { state: { 'batch': batch } });
  }

  pushTimetablePage(batch) {
    this.router.navigateByUrl('/timetable', { state: { 'batch': batch } });
  }

  doInfinite(infiniteScroll) {
    setTimeout(() => {
      this.page = this.page + 1;
      this.batchService.loadBatchList(this.token, this.userid, this.page).subscribe(
        (response: any) => {
          console.log(response.batches);
          this.commonService.dismissloading();
          this.tempBatches = [];
          response.batches.forEach((i) => {
            this.tempBatches.push(new EmployeeClassModel(i));
          });
          this.batches = this.batches.concat(this.tempBatches);
          this.attendanceType = response.attendance_type;
          console.log(this.batches);
          infiniteScroll.target.complete();
          if (response.batches.length === 0) this.disableInfiniteScroll = true;
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.userService.errorHandler();
          }
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        },
      );
    }, 500);
  }

  loadPage() {
    this.init();
    this.event.subscribe('class_reload', (data) => {
      this.init();
    });

  }
}
