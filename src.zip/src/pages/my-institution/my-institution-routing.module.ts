import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MyInstitutionPage } from './my-institution';


const routes: Routes = [
  {
    path: '',
    component: MyInstitutionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MyInstitutionPageRoutingModule { }
