import { NgModule } from '@angular/core';
import { PipesModule } from '../../pipes/pipes.module'
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { MyInstitutionPageRoutingModule } from './my-institution-routing.module';
import { MyInstitutionPage } from './my-institution';

@NgModule({
    declarations: [
        MyInstitutionPage
    ],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        MyInstitutionPageRoutingModule
    ],
})



export class MyInstitutionPageModule { }