import { Component, OnInit } from '@angular/core';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { NavController, Platform } from '@ionic/angular';
import { AppSettings } from 'src/models/app-settings';
import { Profile } from 'src/providers/profile';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';
import { Router } from '@angular/router';
import { Storage } from '@ionic/storage';


@Component({
  selector: 'page-my-institution',
  templateUrl: 'my-institution.html',
  styleUrls: ['my-institution.scss']
})
export class MyInstitutionPage implements OnInit {

  schoolLogo: string;
  schoolCover: string;
  schoolName: string;
  schoolAddress: string;
  schoolContact: string;
  schoolEmail: string;
  schoolWebsite: string;
  userData = [];
  staticPages = [];
  token = '';
  studentId = '';
  employee = true;
  announcmentsTotal = '0';
  isMultischoolMode: any = AppSettings.MULTI_SCHOOL_MODE;
  constructor(
    private event: EventsService,
    private storage: Storage,
    private emailComposer: EmailComposer,
    private iab: InAppBrowser,
    public platform: Platform,
    private callNumber: CallNumber,
    public navCtrl: NavController,
    private profileService: Profile,
    private userService: User,
    private router: Router
  ) {
    this.getSchool();

  }
  ngOnInit() {

  }
  getSchool() {
    if (AppSettings.MULTI_SCHOOL_MODE) {
      this.storage.get('logo_profile_url').then(val => { this.schoolLogo = val });
      this.storage.get('cover_url').then(val => { this.schoolCover = val })
    }
    this.profileService.getSchool()
      .then((data) => {
        console.log('School data received');
        console.log(data);
        this.schoolName = data.school_details.school_name;
        this.schoolAddress = data.school_details.school_address;
        this.schoolContact = data.school_details.school_contact_no;
        this.schoolEmail = data.school_details.school_email;
        this.schoolWebsite = data.school_details.school_website;
        this.staticPages = data.connect_app_pages;
      })
      .catch((err) => {
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      });
  }
  call(number) {
    this.callNumber.callNumber(number, true)
      .then(() => console.log('Launched dialer!'))
      .catch(() => console.log('Error launching dialer'));
  }
  sendMail(emailId) {
    this.emailComposer.isAvailable().then((available: boolean) => {
      if (available) {
        // Now we know we can send
      }
    });

    const email = {
      to: emailId,
      // attachments: [
      //   'file://img/logo.png',
      //   'res://icon.png',
      //   'base64:icon.png//iVBORw0KGgoAAAANSUhEUg...',
      //   'file://README.pdf'
      // ],
      subject: ' ',
      body: ' ',
      isHtml: true,
    };
    this.emailComposer.open(email);
  }
  launch(url) {
    // tslint:disable-next-line:max-line-length
    const browser = this.iab.create(url, '_blank', 'location=no,toolbar=yes,fullscreen=no,closebuttoncaption=close');
    browser.show();
    // const browser = this.iab.create(this.payment_details.payment_url,'_blank','location=no');

  }
  openAnnouncement() {
    this.router.navigateByUrl('/announcements');
  }
  openProfile() {
    this.navCtrl.setDirection('root');
    this.router.navigateByUrl('/tabs/account', { replaceUrl: true })
  }
  openStaticPage(page) {
    this.router.navigateByUrl('/static-page/' + page);
  }
}
