import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { ApplyLeavePageRoutingModule } from './apply-leave-routing.module';
import { ApplyLeavePage } from './apply-leave';
import { PipesModule } from 'src/pipes/pipes.module';

@NgModule({
    declarations: [
        ApplyLeavePage
    ],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        ApplyLeavePageRoutingModule
    ],
    schemas: [
        CUSTOM_ELEMENTS_SCHEMA
    ]
})



export class ApplyLeavePageModule { }