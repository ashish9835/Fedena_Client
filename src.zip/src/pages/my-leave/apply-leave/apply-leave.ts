import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertController, LoadingController, NavController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import moment from 'moment';
import { EmployeeLeaveModel } from 'src/models/employeeLeaves/employeeLeave';
import { CommonService } from 'src/providers/common/common.service';
import { EmployeeLeave } from 'src/providers/employee-leave';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-apply-leave',
  templateUrl: 'apply-leave.html',
  styleUrls: ['apply-leave.scss']
})
export class ApplyLeavePage implements OnInit {
  @ViewChild('datepicker') datetime: any;
  @ViewChild('leaveselect') leaveselect: any;

  alert: any;
  currentDate = new Date();
  currentday = moment(this.currentDate).locale('en').add(0, 'days').format('YYYY-MM-DD');
  nextday = moment(this.currentDate).locale('en').add({ days: 1 }).format('YYYY-MM-DD');

  maxdate = moment(this.currentDate).locale('en').endOf('year').add({ year: 1 }).format('YYYY-MM-DD');

  token = '';
  userId = '';
  type: string;
  employeeLeave: any;
  leaveType = '64';
  leaveTypes: any;
  reason = '';
  isMultiple = false;
  isHalfDay = false;
  startDate = this.currentday;
  endDate = this.nextday;
  loading: any;
  daysCount = 1;
  private loginErrorString: string;
  submitted = false;
  constructor(
    public translate: TranslateService,
    private event: EventsService,
    public navCtrl: NavController,
    public userService: User,
    private leaveService: EmployeeLeave,
    private alertCtrl: AlertController,
    private commonService: CommonService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.showLoading();
    this.loginErrorString = 'Login failed';
    this.type = this.route.snapshot.params.type;
    if (this.type === 'multiple') this.isMultiple = true;
    if (this.type === 'half') this.isHalfDay = true;
    console.log('Leave type ' + this.type);
    this.loadLeaveOverview();
  }
  ngOnInit() {

  }
  loadLeaveOverview() {
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          this.userId = id;
          this.leaveService.loadLeaveOverview(this.token, this.userId)
            .subscribe(
              (response: any) => {
                this.commonService.dismissloading();
                console.log(response);
                if (response.success === true) {
                  this.loginErrorString = response.description;
                  this.employeeLeave = new EmployeeLeaveModel(response.employee_leave);
                  console.log(this.employeeLeave);
                  this.leaveTypes = this.employeeLeave.leaveTypes;
                } else {
                  this.loginErrorString = response.description;
                  this.showError('Error', this.loginErrorString);
                }
              },
              (err) => {
                console.log(err.status);
                if (err.status === 500) {
                  this.userService.errorHandler();
                }
                if (err.status === 403) {
                  this.navCtrl.setDirection('root');
                  this.router.navigateByUrl('/tutorial', { replaceUrl: true })
                }
              },
            );
        });
      } else {
        this.showError('Error', 'Access token not found!');
      }
    });
  }
  goback() {
    this.navCtrl.pop();
  }
  ionViewWillLeave() {
    if (this.alert) this.alert.dismiss();
    if (this.datetime && this.datetime._picker) this.datetime._picker.dismiss();
    if (this.leaveselect && this.leaveselect._overlay) this.leaveselect._overlay.dismiss()
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ApplyLeave');
  }
  ionViewDidLeave() {
    // enable the root left menu when leaving the tutorial page
    // this.navCtrl.pop();
  }
  calculateDays() {
    console.log(this.endDate + " --------------------- " + this.startDate)
    const date2 = new Date(this.endDate);
    const date1 = new Date(this.startDate);
    const timeDiff = Math.abs(date2.getTime() - date1.getTime());
    this.daysCount = Math.ceil((timeDiff / (1000 * 3600 * 24)) + 1);
  }
  // Attempt to login in through our User service
  applyLeave(form) {
    if (form.valid) {
      this.showLoading();
      this.leaveService.applyLeave(
        this.token,
        this.userId,
        this.reason,
        this.isMultiple,
        this.isHalfDay,
        this.startDate,
        this.endDate,
        this.leaveType,
      )
        .subscribe(
          (response: any) => {
            console.log(response);
            this.commonService.dismissloading();;
            if (response.success === true) {
              // this.navCtrl.setRoot('MyLeavePage', { tab: 'leaves' });
            } else {
              let reasons = '';
              for (const reason of response.reasons) {
                reasons = reasons + '<li>' + reason + '</li>';
              }
              this.loginErrorString = response.description + '<br/><ul class=\'my-nav\'>' + reasons + '</ul>';
              this.showError('Error', this.loginErrorString);
            }
          },
          (err) => {
            console.log(err.status);
            if (err.status === 500) {
              this.userService.errorHandler();
            }
            if (err.status === 403) {
              // this.navCtrl.setRoot('TutorialPage');
            }
          },
        );
    }
  }
  showLoading() {
    this.commonService.presentLoading('Please wait');
  }
  async showError(title, text) {
    let okBtnString = 'OK';
    this.translate.get('alert.btn_ok').subscribe(val => okBtnString = val);
    this.alert = await this.alertCtrl.create({
      header: title,
      message: text,
      buttons: [okBtnString],
    });
    await this.alert.present();
  }

}
