import { NgModule } from '@angular/core';
import { MyLeavePage } from './my-leave';
import { PipesModule } from '../../pipes/pipes.module'
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';
import { MyLeavePageRoutingModule } from './my-leave-routing.module';

@NgModule({
    declarations: [
        MyLeavePage
    ],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        ChartsModule,
        MyLeavePageRoutingModule
    ],
})



export class MyLeavePageModule { }