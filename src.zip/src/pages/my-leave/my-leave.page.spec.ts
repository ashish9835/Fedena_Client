import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { MyLeavePage } from './my-leave';

describe('MyLeavePage', () => {
  let component: MyLeavePage;
  let fixture: ComponentFixture<MyLeavePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyLeavePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MyLeavePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
