import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActionSheetController, NavController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { EmployeeLeaveModel } from 'src/models/employeeLeaves/employeeLeave';
import { EmployeeLeaveRequestModel } from 'src/models/employeeLeaves/employeeLeaveRequest';
import { CommonService } from 'src/providers/common/common.service';
import { EmployeeLeave } from 'src/providers/employee-leave';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-my-leave',
  templateUrl: 'my-leave.html',
  styleUrls: ['my-leave.scss']
})
export class MyLeavePage implements OnInit {
  userId = '';
  token = '';
  doughnutChartLabels: string[] = ['Available leaves', 'Leaves taken'];
  doughnutChartColours: any[] = [{ backgroundColor: ['#2E4C6F', '#C24587'] }];
  doughnutChartData: number[] = [0, 100];
  doughnutChartType: string = 'doughnut';
  doughnutChart: any;
  type: string = 'overviews';
  leaveOverview: any = [];
  myleaves: any = [];
  canApply = false;
  leaveTypes = [];
  totalLeavesTaken = 0;
  totalLeaves = 0;
  totalAvailableLeaves = 0;
  totalAdditionalLeaves = 0;
  totalLossOfPay = 0;
  constructor(
    private translate: TranslateService,
    private event: EventsService,
    public actionSheetCtrl: ActionSheetController,
    public navCtrl: NavController,
    private leaveService: EmployeeLeave,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.commonService.presentLoading('Loading leaves');
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          this.userId = id;
          this.loadOverview();
          this.loadLeaves();
        });
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });

  }
  ngOnInit() {

  }
  async presentActionSheet() {
    let btnHalfDay = 'Half day';
    let btnFullDay = 'Full day';
    let btnMultipleDays = 'Multiple days';
    let titleTxt = 'Select leave type'
    this.translate.get('button.half_day').subscribe(val => btnHalfDay = val);
    this.translate.get('button.full_day').subscribe(val => btnFullDay = val);
    this.translate.get('button.multiple_days').subscribe(val => btnMultipleDays = val);
    this.translate.get('my_leave.action_sheet_title').subscribe(val => titleTxt = val);
    const actionSheet = await this.actionSheetCtrl.create({
      header: titleTxt,
      buttons: [
        {
          text: btnHalfDay,
          handler: () => {
            this.applyLeaves('half');
            console.log('Selected half day');
          },
        },
        {
          text: btnFullDay,
          handler: () => {
            this.applyLeaves('full');
            console.log('Selected full day');
          },
        },
        {
          text: btnMultipleDays,
          handler: () => {
            this.applyLeaves('multiple');
            console.log('Selected multiple days');
          },
        },
      ],
    });

    this.event.subscribe('dismiss:overlay', () => {
      if (actionSheet)
        actionSheet.dismiss();
    })

    await actionSheet.present();
  }
  ionViewWillLeave() {
    this.event.publish('dismiss:overlay', {});
  }
  goback() {
    this.navCtrl.setDirection('root');
    this.router.navigateByUrl('/tabs', { replaceUrl: true })
  }

  async loadChart() {
    let strAvailableLeaves = "Available leaves";
    let strLeavesTaken = "Leaves taken";
    strAvailableLeaves = await this.translate.get('my_leave.available_leaves').toPromise();
    strLeavesTaken = await this.translate.get('my_leave.leaves_taken').toPromise();
    this.doughnutChartLabels[0] = strAvailableLeaves;
    this.doughnutChartLabels[1] = strLeavesTaken;
    this.doughnutChartData = [this.totalAvailableLeaves, this.totalLeavesTaken];
  }
  overview() {
    this.commonService.presentLoading('Loading leaves');
    this.loadOverview();
  }
  leaves() {
    this.commonService.presentLoading('Loading leaves');
    this.loadLeaves();

  }
  updateChart() {
    this.loadChart();
  }

  loadOverview() {
    this.leaveService.loadLeaveOverview(this.token, this.userId).subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        console.log(response);
        if (response.success === true) {
          this.leaveOverview = new EmployeeLeaveModel(response.employee_leave);
          console.log(this.leaveOverview);
          this.totalLeavesTaken = this.leaveOverview.totalLeavesTaken;
          this.totalLeaves = this.leaveOverview.totalLeaves;
          this.totalAvailableLeaves = this.leaveOverview.totalAvailableLeaves;
          this.totalAdditionalLeaves = this.leaveOverview.totalAdditionalLeaves;
          this.totalLossOfPay = this.leaveOverview.totalLossOfPay;
          this.leaveTypes = this.leaveOverview.leaveTypes;
          this.canApply = this.leaveOverview.canApply;
          this.loadChart();
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      },
    );

  }
  loadLeaves() {
    this.leaveService.loadEmployeeLeaveList(this.token, this.userId).subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        console.log(response);
        this.myleaves = [];
        if (response.success === true) {
          response.employee_leaves.forEach((i) => {
            this.myleaves.push(new EmployeeLeaveRequestModel(i));
          });
          console.log(this.myleaves);
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      },
    );
  }

  applyLeaves(type) {
    this.router.navigateByUrl('/apply-leave/' + type);
  }
  viewLeaveDetails(leave) {
    this.router.navigateByUrl('/leave-details', { state: { 'leave': leave, 'leaveId': leave.id } });
  }
}
