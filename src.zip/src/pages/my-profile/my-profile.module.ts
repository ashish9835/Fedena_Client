import { NgModule } from '@angular/core';
import { MyProfilePage } from './my-profile';
import { PipesModule } from '../../pipes/pipes.module'
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { MyProfilePageRoutingModule } from './my-profile-routing.module';

@NgModule({
    declarations: [
        MyProfilePage
    ],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        MyProfilePageRoutingModule
    ],
})



export class MyProfilePageModule { }