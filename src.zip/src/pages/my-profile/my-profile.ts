import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Profile } from 'src/providers/profile';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { User } from 'src/providers/user';
import { StudentProfileDetailsModel } from 'src/models/Profile/studentProfileDetails';
import { EmployeeProfileDetailsModel } from 'src/models/Profile/employeeProfileDetails';
import { NavController } from '@ionic/angular';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { Clipboard } from '@ionic-native/clipboard/ngx';

@Component({
  selector: 'page-my-profile',
  templateUrl: 'my-profile.html',
  styleUrls: ['my-profile.scss']
})
export class MyProfilePage implements OnInit {
  userData: any = {};
  token = '';
  studentId = '';
  employee = true;
  profile: any = {};
  name = '';
  profileTitle = '';
  profileSubTitle = '';
  profilePhoto = 'assets/img/appicon.png';
  constructor(
    public event: EventsService,
    private profileService: Profile,
    private userService: User,
    private router: Router,
    private commonService: CommonService,
    private navCtrl: NavController,
    private callNumber: CallNumber,
    private emailComposer: EmailComposer,
    private clipboard: Clipboard
  ) {
    this.profile = (this.router.getCurrentNavigation().extras.state) ? this.router.getCurrentNavigation().extras.state.profile : null;
    if (!this.profile) {
      this.commonService.presentLoading('Loading profile')
      console.log('if');
      this.userService.getAccessToken().then((value) => {
        if (value) {
          this.token = value;
          this.userService.getRole().then((role) => {
            this.userService.getUser().then((value) => {
              this.name = value.fullName;
              if (role === 'employee') {
                this.profileTitle = 'Employee ';
                this.profileSubTitle = value.employeePositionName;
                this.employee = true;
                this.getEmployee();
              } else {

                this.profileTitle = 'Student';
                console.log(value.batchCourseName);
                this.profileSubTitle = value.batchCourseName;
                console.log(this.profileSubTitle);
                this.employee = false;
                this.getStudent();
              }
              if (value.profilePhoto !== '') {
                this.profilePhoto = value.profilePhoto;
              }
            });

          });

        } else {
          this.commonService.presentAlert('Session expired')
        }
      });
    }
    if (this.profile) {
      console.log(this.profile);
      this.name = this.profile.fullName;
      this.profileTitle = 'Student';
      this.profileSubTitle = this.profile.batchCourseName;
      this.employee = false;
      if (this.profile.profilePhoto !== '') {
        this.profilePhoto = this.profile.profilePhoto;
      }
      this.userData = this.profile;

    }
  }
  ngOnInit(){
    
  }
  getStudent() {
    this.userService.getUserId().then((id) => {
      this.studentId = id;
      this.profileService.loadStudnetProfile(this.token, this.studentId).subscribe(
        (response: any) => {
          this.commonService.dismissloading();
          if (response.success === true) {
            this.userData = new StudentProfileDetailsModel(response.student);
            console.log(this.userData);
            this.userService.setUser(this.userData);
          }
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.userService.errorHandler();
          }
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        },

      );
    });

  }
  getEmployee() {
    this.profileService.loadEmployeeProfile(this.token).subscribe(
      (response: any) => {
        console.log(response);
        this.commonService.dismissloading();
        if (response.success === true) {
          this.userData = new EmployeeProfileDetailsModel(response.employee);
          this.userService.setUser(this.userData);
          console.log(this.userData);
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true })
        }
      },
    );
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad MyProfile');

    if (!this.profile) {
      this.userService.getUser().then((value) => {
        this.userData = value;
      });
    }

  }
  call(number) {
    this.callNumber.callNumber(number, true)
      .then(() => console.log('Launched dialer!'))
      .catch(() => console.log('Error launching dialer'));
  }
  sendMail(emailId) {
    this.emailComposer.isAvailable().then((available: boolean) => {
      if (available) {
        // Now we know we can send
      }
    });
    const email = {
      to: emailId,
      subject: ' ',
      body: ' ',
      isHtml: true,
    };
    this.emailComposer.open(email);
  }
  copy(data) {
    this.clipboard.copy(data);
    this.commonService.presentToast( 'Copied', 1000);
  }
}
