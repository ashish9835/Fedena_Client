import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { NotificationPageRoutingModule } from './notification-routing.module';
import { NotificationPage } from './notification';
import { PipesModule } from 'src/pipes/pipes.module';

@NgModule({
    declarations: [
        NotificationPage
    ],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        NotificationPageRoutingModule,
        PipesModule
    ],
})



export class NotificationPageModule { }