import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { NotificationModel } from 'src/models/notifications/notifications';
import { EventsService } from 'src/providers/events/events.service';
import { Notifications } from 'src/providers/notifications';
import { User } from 'src/providers/user';


@Component({
  selector: 'page-notification',
  templateUrl: 'notification.html',
  styleUrls: ['notification.scss']
})
export class NotificationPage implements OnInit {
  token: string;
  notifications: any = [];
  disableInfiniteScroll: boolean = false;
  count: number;
  page: number = 1;
  constructor(
    public events: EventsService,
    public navCtrl: NavController,
    public notification: Notifications,
    public user: User,
    public router: Router,
    public route: ActivatedRoute
  ) {
    // this.showLoading();
    this.count = this.route.snapshot.params.count;
    this.user.getAccessToken().then((value) => {
      console.log(value);
      if (value) {
        this.token = value;
        this.getNotifications();
        this.events.subscribe('message:received', (data) => {
          this.getNotifications();
          // user and time are the same arguments passed in `events.publish(user, time)`
          console.log('Welcome', data.notification, 'at', data.time);
        });
      } else {
        // this.showError("Access token not found!");
        // this.logout();
      }
    });
  }
  ngOnInit() {

  }
  getNotifications() {
    this.page = 1;
    this.notification.loadNotifications(this.token, this.page).subscribe(
      (response: any) => {
        // this.notifications = new NotificationModel(response.notifications);
        response.notifications.forEach((i) => {
          this.notifications.push(new NotificationModel(i));
        });
        console.log(this.notifications);
      },
      (err) => {
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad NotificationPage');
  }

  isClickable(notification) {
    const allowedList = ['view_calendar', 'view_fees', 'employee_leave', 'show_news'];
    const flag = (notification.payload && allowedList.indexOf(notification.payload.target) > -1);
    // tslint:disable-next-line:max-line-length
    if (flag && notification.payload.target === 'employee_leave' && notification.payload.linkText === 'approve_leave') {
      return true;
      // tslint:disable-next-line:no-else-after-return
    } else {
      return flag;
    }
  }

  clickNotification(notification) {
    console.log(notification);
    if (this.isClickable(notification)) {
      const target = notification.payload.target;
      console.log(target);
      switch (target) {
        case 'view_calendar': {
          this.router.navigateByUrl('/events');
          break;
        }
        case 'view_fees': {
          this.router.navigateByUrl('/fees');
          break;
        }
        case 'employee_leave': {
          this.router.navigateByUrl('/leave-requests');
          break;
        }
        case 'show_news': {
          this.router.navigateByUrl('/announcements-details', { state: { news: '', newsId: notification.payload.targetValue, token: this.token } });
          break;
        }
        default: {
          console.log('do something');
          break;
        }
      }
    }
  }

  doInfinite(infiniteScroll) {
    const fetch = true;
    if (fetch) {
      console.log('Loading Notifications');
      setTimeout(() => {
        this.page = this.page + 1;
        this.notification.loadNotifications(this.token, this.page).subscribe(
          (response: any) => {
            response.notifications.forEach((i) => {
              this.notifications.push(new NotificationModel(i));
            });
            console.log(response);
            if (response.notifications.length === 0) this.disableInfiniteScroll = true;
          },
          (err) => {
            console.log(err.status);
            if (err.status === 500) {
              this.user.errorHandler();
            }
            if (err.status === 403) {
              this.navCtrl.setDirection('root');
              this.router.navigateByUrl('/tutorial', { replaceUrl: true });
            }
          },
        );
        infiniteScroll.target.complete();
      }, 3000);
    } else {
      infiniteScroll.target.complete();
    }
  }
}
