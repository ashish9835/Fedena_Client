
import { Component, OnInit, ViewChild, } from '@angular/core';
import { Router } from '@angular/router';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { MenuController, NavController, Platform } from '@ionic/angular';
import { AppSettings } from 'src/models/app-settings';
import { CommonService } from 'src/providers/common/common.service';
import { Authentication } from 'src/providers/providers';
import { School } from 'src/providers/school';
import { User } from 'src/providers/user';


@Component({
  selector: 'page-otp',
  templateUrl: 'otp.html',
  styleUrls: ['otp.scss']
})
export class OtpPage implements OnInit {

  otpSecret = '';
  otpType: string;
  otpno = '';
  otpno1 = '';
  otpno2 = '';
  otpno3 = '';
  otpno4 = '';
  identifier = '';
  email = '';
  isShowResend = true;
  showRetryLater = true;
  schoolLogo = AppSettings.SCHOOL_LOGO;
  schoolName: string;
  schoolPlace: string;
  tryCount: number = 0;
  hideSuccessMessage: boolean;
  private loginErrorString: string;
  submitted = false;
  @ViewChild('ipt1') ipt1;
  @ViewChild('ipt2') ipt2;
  @ViewChild('ipt3') ipt3;
  @ViewChild('ipt4') ipt4;
  constructor(
    private school: School,
    public navCtrl: NavController,
    private keyboard: Keyboard,
    public platform: Platform,
    public user: User,
    private authService: Authentication,
    private menu: MenuController,
    private router: Router,
    private commonService: CommonService
  ) {
    this.school.getSchool('name').then((value) => { this.schoolName = value; });
    this.school.getSchool('address').then((value) => { this.schoolPlace = value; });
    let data = this.router.getCurrentNavigation().extras.state.data;
    console.log(data, 'data');
    if (data.mobile_number) {
      this.identifier = data.mobile_number;
      this.otpType = 'mobile_number';
    }
    if (data.email) {
      this.identifier = data.email;
      this.otpType = 'email';
    }
    this.email = data.email;
    this.otpSecret = data.otp_secret;
    this.loginErrorString = 'Login failed';
    this.showResend();

    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      /*
       * MODIFY BOOTSTRAP CODE BELOW
       * Disable the Ionic Keyboard Plugin scroll for iOS only
       * https://github.com/driftyco/ionic/issues/5571
       */

      if (this.platform.is('ios')) {

        keyboard.onKeyboardShow().subscribe(() => {
          keyboard.disableScroll(true);
        });

        keyboard.onKeyboardHide().subscribe(() => {
          keyboard.disableScroll(false);
        });
      }
      /*
       * END MODIFY
       */
    });



  }
  ngOnInit(){
    
  }

  ionViewDidEnter() {
    // the root left menu should be disabled on the tutorial page
    this.menu.enable(false);

  }
  ionViewDidLeave() {
    if (this.platform.is('ios')) {
      this.keyboard.onKeyboardHide().subscribe((value) => {
        this.keyboard.disableScroll(false);
      });
    }

  }
  ionViewWillLeave() {
    // enable the root left menu when leaving the tutorial page
    this.menu.enable(true);
    this.keyboard.disableScroll(false);

  }
  showResend() {
    this.tryCount = this.tryCount + 1;
    if (this.tryCount < 4) {
      setTimeout(() => {
        this.isShowResend = false;
      }, 5000);
    } else {
      this.showRetryLater = false;
    }
  }
  setFocus() {
    setTimeout(() => {
      this.ipt1.setFocus();
      console.log('Focus set');
    }, 500);
  }
  next(el, val, prev) {
    this.hideSuccessMessage = true;
    if (val !== '' && val !== ' ') el.setFocus();
    if (val === '') prev.setFocus();
  }
  next_end(el, val, prev, form) {
    if (val !== '' && val !== ' ') this.verifyOtp(form);
    if (val === '') prev.setFocus();
  }
  verifyOtp(form) {
    if (this.otpno1 || this.otpno2 || this.otpno3 || this.otpno4) {
      this.keyboard.disableScroll(false);
      this.otpno = this.otpno1 + this.otpno2 + this.otpno3 + this.otpno4;
      this.commonService.presentLoading('Verifying OTP');
      this.authService.verifyOTP(
        this.identifier,
        this.otpSecret,
        this.otpno,
        this.otpType,
      ).subscribe((response) => {
        console.log(response);
        const apiResponse: any = response;
        this.commonService.dismissloading();
        if (apiResponse.succes === true) {
          this.router.navigateByUrl('/login-confirmation/' + apiResponse.token);
        } else {
          if (apiResponse.error.length > 0) {
            this.loginErrorString = apiResponse.error[0];
            this.otpno1 = '';
            this.otpno2 = '';
            this.otpno3 = '';
            this.otpno4 = '';
            setTimeout(() => {
              this.ipt1.setFocus();
              console.log('Focus set');
            }, 500);
          }
          this.commonService.presentToast("toast.invalid_otp", 3000)
        }
      });
    } else {
      this.commonService.presentToast("toast.enter_otp", 3000);
    }

  }

  resendOtp() {
    this.isShowResend = true;
    this.commonService.presentLoading('Resending OTP')
    this.authService.resendOTP(
      this.identifier,
      this.otpType,
      this.otpSecret,
    ).subscribe(
      (response) => {
        console.log(response);
        this.hideSuccessMessage = false;
        this.commonService.dismissloading();
        this.showResend();
        this.otpno1 = '';
        this.otpno2 = '';
        this.otpno3 = '';
        this.otpno4 = '';
        setTimeout(() => {
          this.ipt1.setFocus();
          console.log('Focus set');
        }, 500);
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.user.errorHandler();
        }
        if (err.status === 403) {
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  openContactAdmin() {
    this.router.navigateByUrl('/contact-admin', { replaceUrl: true });
  }
}
