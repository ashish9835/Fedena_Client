import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PayAllFeesPage } from './pay-all-fees';


const routes: Routes = [
  {
    path: '',
    component: PayAllFeesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PayAllFeesPageRoutingModule { }
