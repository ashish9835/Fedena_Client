import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { PayAllFeesPage } from './pay-all-fees';
import { PayAllFeesPageRoutingModule } from './pay-all-fees-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PayAllFeesPageRoutingModule,
    PipesModule
  ],
  declarations: [PayAllFeesPage]
})
export class PayAllFeesPageModule { }
