import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { PayAllFeesPage } from './pay-all-fees';

describe('PayAllFeesPage', () => {
  let component: PayAllFeesPage;
  let fixture: ComponentFixture<PayAllFeesPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PayAllFeesPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PayAllFeesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
