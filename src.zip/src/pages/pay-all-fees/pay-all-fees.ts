import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser/ngx';
import { IonContent, NavController, Platform, ToastController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { AllFeeDetailsModel, BatchDetails, PayAllFeeReceiptModel, FeesDetailModel, OnlinePaymentDetailsModel } from 'src/models/fees/allFeesDetails';
import { CommonService } from 'src/providers/common/common.service';
import { DownloadOptions, DownloadProvider } from 'src/providers/downloader';
import { EventsService } from 'src/providers/events/events.service';
import { Fees } from 'src/providers/fees';


/**
 * Generated class for the PayAllFeesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-pay-all-fees',
  templateUrl: 'pay-all-fees.html',
  styleUrls: ['pay-all-fees.scss']
})
export class PayAllFeesPage implements OnInit {
  @ViewChild(IonContent) content: IonContent;
  @ViewChild('receiptsBlockHeader') receiptBlockHeader: ElementRef;
  payAllFeesDetails: AllFeeDetailsModel;
  financeTypes: any[];
  categorySelectEvent: boolean = true;
  partialPaymentEnabled: boolean = false;
  payAllFeeReceipts: PayAllFeeReceiptModel[];
  selectedFees: FeesDetailModel[];
  selectedBatch?: number;
  showReceipts: boolean = false;
  paymentDetails: OnlinePaymentDetailsModel;
  batchDetails: BatchDetails;
  redirectUrl: string;
  currencyType: string;
  error: boolean = false;
  initialChange: boolean = true;
  totalSelectedAmount: number = 0;
  currentBatch: string;
  ERROR_NO_FEE_SELECTED: string = "Select one or more fees to proceed.";
  ALERT_NO_PAYMENT_REQUIRED: string = "No payment required.";
  ERROR_EXCEEDS_THE_LIMIT: string = "Fees should not be empty or exceed the max payable amount.";
  constructor(public platform: Platform,
    public downloader: DownloadProvider,
    public navCtrl: NavController,
    public fees: Fees,
    public event: EventsService,
    public toastCtrl: ToastController,
    public iab: InAppBrowser,
    public translate: TranslateService,
    public commonService: CommonService,
    private router: Router
  ) {
    this.loadPayAllFeesDetails();
    this.initTranslationStrings();
  }
  ngOnInit() { }
  async initTranslationStrings() {
    this.ERROR_NO_FEE_SELECTED = await this.translate.get('fees.error_no_fee_selected').toPromise();
    this.ALERT_NO_PAYMENT_REQUIRED = await this.translate.get('fees.alert_no_payment_required').toPromise();
    this.ERROR_EXCEEDS_THE_LIMIT = await this.translate.get('fees.error_exceeds_the_limit').toPromise();

  }
  ionViewDidLoad() {
    this.content.scrollToTop();
  }
  ionViewDidEnter() {
    this.content.scrollToTop();
  }

  goback() {
    this.navCtrl.back();
  }
  onClickLable($event) {
    ($event['target']['previousElementSibling'] as HTMLElement).click()
  }
  loadPayAllFeesDetails() {
    this.commonService.presentLoading('Loading fees');
    this.fees.loadPayAllFeesDetails(this.selectedBatch).subscribe((val: any) => {
      this.payAllFeesDetails = new AllFeeDetailsModel(val.fees);
      this.partialPaymentEnabled = this.payAllFeesDetails.onlinePaymentDetails.partialPaymentEnabled;
      let types = Object.keys(this.payAllFeesDetails.feesDetails);
      this.financeTypes = ['FinanceFee', 'HostelFee', 'TransportFee'];
      this.payAllFeeReceipts = this.payAllFeesDetails.paymentReceipts.reverse();
      this.paymentDetails = this.payAllFeesDetails.onlinePaymentDetails;
      this.currencyType = this.payAllFeesDetails.currencyType;
      this.batchDetails = this.payAllFeesDetails.batchDetails;
      this.selectedBatch = this.selectedBatch ? this.selectedBatch : this.payAllFeesDetails.batchDetails.currentBatchId;
      this.currentBatch = this.payAllFeesDetails.batchDetails.currentBatch;

      this.commonService.dismissloading();
      if (this.showEmptyState() && this.payAllFeeReceipts.length > 0) {
        this.showReceipts = true;
      }
      this.content.scrollToTop()
    }, err => {
      this.commonService.dismissloading();
    })
  }
  onBatchChange() {
    this.loadPayAllFeesDetails()
    this.financeTypes.forEach(type => {
      this[type] = false;
    })

  }
  onCategorySelected(isChecked, key) {
    //on first selection of the group onCollection is not called for individual collection
    //which updates the checked count for the group. So here checked count is set to all.
    if (this[key + "_checked_count"] === undefined && isChecked) {
      this[key + "_checked_count"] = this.payAllFeesDetails.feesDetails[key].length
    }
    //
    if (!this.categorySelectEvent) {
      this.categorySelectEvent = true;
      return;
    }
    this.payAllFeesDetails.feesDetails[key].forEach(collection => {
      collection['selected'] = isChecked ? true : false;
    });
    if (isChecked) {
      this[key] = true;
    }
    this.calculateTotalSelectedAmount();
  }
  onCollectionSelected(isChecked, collection) {
    //keeps track of checked items for a group(finance type) so that group check box is 
    //checked when all the items of the group are selected.
    let checkedCount = this[collection.financeType + "_checked_count"] | 0;
    if (isChecked) {
      checkedCount++;
    } else if (checkedCount > 0) checkedCount--;
    this[collection.financeType + "_checked_count"] = checkedCount ? checkedCount : 0;
    if (this[collection.financeType + "_checked_count"] === this.payAllFeesDetails.feesDetails[collection.financeType].length) {
      this[collection.financeType] = true;
    }
    //
    if (!isChecked && this[collection.financeType]) {
      this.categorySelectEvent = false;
      this[collection.financeType] = false;
    } else {

    }
    //if collection amount input is empty or zero greater than due amount, it is not payable.
    if (isChecked && (collection.amountPaying == undefined || collection.amountPaying == 0 || collection.dueAmount < collection.amountPaying)) {
      collection.isPayable = false;
    }
    else {
      collection.isPayable = true;
    }
    //calculate total amount that user has selected to pay.
    this.calculateTotalSelectedAmount();
  }
  calculateTotalSelectedAmount() {
    this.selectedFees = [];
    this.totalSelectedAmount = 0;
    this.error = false;
    this.financeTypes.forEach(type => {
      if (this.payAllFeesDetails.feesDetails[type])
        this.payAllFeesDetails.feesDetails[type].forEach(fee => {
          if (fee.isPayable && fee.selected) {
            this.selectedFees.push(fee);
            this.totalSelectedAmount += fee.amountPaying;
          }
          if (fee.selected && !fee.isPayable) {
            this.error = true;
            return;
          }
        });
    });
    this.totalSelectedAmount = Number.parseFloat(this.totalSelectedAmount.toFixed(this.payAllFeesDetails.precision));
    console.log(this.totalSelectedAmount)
  }
  showPayButton() {
    return (this.payAllFeesDetails && Object.keys(this.payAllFeesDetails.feesDetails).length > 0)
  }
  showEmptyState() {
    let showEmptyState = this.payAllFeesDetails && (Object.keys((this.payAllFeesDetails).feesDetails).length === 0);
    return showEmptyState;
  }

  openPDF(pdf, filename) {

    let options: DownloadOptions = new DownloadOptions();
    options.fileName = filename + '.pdf';
    options.mimeType = 'application/pdf';
    options.url = pdf.url;
    options.headers = {
      Cookie: '_fedena_session_=' + pdf.sessionId,
    };
    if (this.platform.is('ios')) this.commonService.presentLoading('Downloading receipt');
    if (this.platform.is('android')) this.event.publish('toast:show', 'toast.downloading');
    this.downloader.download(options).then(destn => {
      if (this.platform.is('ios')) this.commonService.dismissloading();
    }).catch(e => {
      if (this.platform.is('ios')) {
        this.commonService.dismissloading();
        this.presentToast(e)
      }
    });
  }
  async presentToast(notification) {

    const toast = await this.toastCtrl.create({
      message: notification,
      duration: 2000,
      position: 'top',
    });
    toast.present();
  }
  toggleReceiptView() {
    this.showReceipts = !this.showReceipts;
    if (this.showReceipts === true) {
      this.scrollTo();
    }
  }
  scrollTo() {
    // const dimensions = this.content.getContentDimensions();
    // this.content.scrollTo(0, this.receiptBlockHeader.nativeElement['offsetTop'], 200);
    this.content.scrollToTop();
  }
  //called upon change in fee input value of a collection.
  onPaymentAmountChange(value, collection) {
    value = Number.parseFloat(value);
    collection.amountPaying = Number.isNaN(value) ? 0 : value;
    if (value && (collection.dueAmount < collection.amountPaying)) {
      collection.isPayable = false;
    } else if (value && collection.amountPaying == undefined || collection.amountPaying == 0) {
      collection.isPayable = false;
    }
    else {
      collection.isPayable = true;
    }
    this.calculateTotalSelectedAmount();
  }
  payFees() {
    this.selectedFees = [];
    this.error = false;
    this.financeTypes.forEach(type => {
      if (this.payAllFeesDetails.feesDetails[type])
        this.payAllFeesDetails.feesDetails[type].forEach(fee => {
          if (fee.isPayable && fee.selected) {
            this.selectedFees.push(fee);
          }
          if (fee.selected && !fee.isPayable) {
            this.error = true;
            return;
          }
        });
    });
    if (!this.error) {
      if (this.paymentDetails.paymentEnabled) {
        let i = 0;
        let totalAmountToPay = 0;
        let request_body = {};
        let transactions = {};
        if (this.selectedFees.length === 0) {
          this.presentToast(this.ERROR_NO_FEE_SELECTED);
          return;
        }
        this.selectedFees.forEach(collection => {
          i++;
          let transaction = {};
          transaction['amount'] = collection.amountPaying;
          transaction['transaction_date'] = new Date().toDateString();
          transaction['finance_id'] = collection.financeId;
          transaction['finance_type'] = collection.financeType;
          transaction['payee_type'] = collection.payeeType;
          transaction['payee_id'] = this.payAllFeesDetails.id;
          transaction['category_id'] = collection.categoryId;
          transaction['title'] = collection.title;
          transaction['payment_mode'] = "";
          transaction['reference_no'] = "";
          transactions[i] = transaction;
          totalAmountToPay += collection.amountPaying;
        });


        var data = JSON.stringify({
          "transactions": transactions,
          "multi_fees_transaction": {
            "student_id": this.payAllFeesDetails.id,
            "amount": totalAmountToPay,
            "batch_id": this.selectedBatch,
            "transaction_date": new Date().toDateString()
          },
          "transaction_extra": {
            "total_amount": totalAmountToPay
          },
          "app": 'mobile'
        });
        var pageContent = `<html><head></head><body><form id="loginForm" action="${this.paymentDetails.paymentUrl}" method="post">` +
          "<input type='hidden' name='data' value='" + data + "'>" +
          "<input type='hidden' name='session' value='true'>" +
          `</form>
           <script type="text/javascript">var form_payment = document.getElementById("loginForm");form_payment.submit();</script></body></html>`;
        var pageContentUrl = 'data:text/html;base64,' + btoa(pageContent);

        let iosIabOptions: InAppBrowserOptions = {
          usewkwebview: 'yes',
          location: 'no',
          clearcache: 'yes',
          clearsessioncache: 'yes',
          toolbar: 'yes'
        }
        let androidIabOptions: InAppBrowserOptions = {
          location: 'no',
          clearcache: 'yes',
          clearsessioncache: 'yes'
        }
        let options = this.platform.is('ios') ? iosIabOptions : androidIabOptions;

        const browser = this.iab.create(
          pageContentUrl, '_blank', options,
        );
        let cookieCode = this.payAllFeesDetails.sessionId;
        browser.on('loadstart').subscribe((data: any) => {
          const substring = '/online_payments/complete_payment';
          this.redirectUrl = data.url;
          if (data.url.includes(substring)) {
            browser.close();
            this.navCtrl.back();
            this.router.navigateByUrl('/transaction-details', {
              state: {
                url: data.url, studentName: this.payAllFeesDetails.fullName, feeName: "Multi-fee", feeAmount: totalAmountToPay,
              }
            })
          }
          console.log(`The payment response is:`, data);
        });
      } else {
        this.presentToast(this.ALERT_NO_PAYMENT_REQUIRED)
      }
    } else {
      this.presentToast(this.ERROR_EXCEEDS_THE_LIMIT);
    }
  }
}