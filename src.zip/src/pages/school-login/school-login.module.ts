import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { DirectivesModule } from 'src/directives/directives.module';
import { SchoolLoginPage } from './school-login';
import { SchoolLoginPageRoutingModule } from './school-login-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SchoolLoginPageRoutingModule,
    DirectivesModule
  ],
  declarations: [SchoolLoginPage]
})
export class SchoolLoginPageModule { }
