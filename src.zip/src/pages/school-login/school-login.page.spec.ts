import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SchoolLoginPage } from './school-login';

describe('SchoolLoginPage', () => {
  let component: SchoolLoginPage;
  let fixture: ComponentFixture<SchoolLoginPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchoolLoginPage ],
    }).compileComponents();

    fixture = TestBed.createComponent(SchoolLoginPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
