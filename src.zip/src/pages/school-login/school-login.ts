import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { MultiSchool } from 'src/providers/multi-school';

/**
 * Generated class for the SchoolLoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-school-login',
  templateUrl: 'school-login.html',
  styleUrls: ['school-login.scss']
})
export class SchoolLoginPage implements OnInit {
  // @ViewChild('searchBarLogin') searchBar:Searchbar;
  schoolCode: string;
  schools: any;
  data: string;
  constructor(
    public storage: Storage,
    public menu: MenuController,
    public MultiSchool: MultiSchool,
    public router: Router,) {
    this.storage.get('schools').then(val => this.schools = val);
    console.log(this.schools);
  }
  ngOnInit() { }
  goToSearchSchool() {
    this.router.navigateByUrl('/school-search');
  }
  ionViewDidEnter() {
    this.menu.enable(false);
  }
  ionViewWillLeave() {
    this.menu.enable(true);
  }

}
