import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { SchoolSearchPage } from './school-search';
import { SchoolSearchPageRoutingModule } from './school-search-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        SchoolSearchPageRoutingModule,
        PipesModule
    ],
    declarations: [SchoolSearchPage]
})
export class SchoolSearchPageModule { }
