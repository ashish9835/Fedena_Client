import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { IonSearchbar, LoadingController, MenuController, NavController, Platform } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { TranslateService } from '@ngx-translate/core';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, map, filter, switchMap } from 'rxjs/operators';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { MultiSchool } from 'src/providers/multi-school';
import { User } from 'src/providers/user';

/**
 * Generated class for the SchoolSearchPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-school-search',
  templateUrl: 'school-search.html',
  styleUrls: ['school-search.scss']
})
export class SchoolSearchPage implements OnInit {
  loading: any;
  @ViewChild('searchbar') searchBar: IonSearchbar;
  searchTerm$ = new Subject<string>();
  schools: any;
  showSpinner: boolean = false;
  constructor(
    public loadingCtrl: LoadingController,
    public event: EventsService,
    public user: User,
    public platfrom: Platform,
    public translate: TranslateService,
    public menu: MenuController,
    public storage: Storage,
    public multiSchoolService: MultiSchool,
    public navCtrl: NavController,
    private commonService: CommonService,
    private router: Router) {
    this.search(this.searchTerm$).subscribe((val: any) => {
      console.log('in search');
      if (val.ok === false) {
        console.log(val);
        this.commonService.presentToast('toast.error_try_again_later', 2000);
      } else {
        this.schools = val.schools;
      }

      this.showSpinner = false;
    }, error => {
      this.showSpinner = false;
    }
    )
  }
  ngOnInit() { }
  goToUserSignInPage(school: any) {
    this.showLoading('Loading...')
    this.multiSchoolService.switchSchool(school).then(() => {
      this.user.getAccessToken().then((value) => {
        this.loading.dismiss()
        if (value) {
          this.event.publish('user:refresh');
          this.router.navigateByUrl('/tabs')
          this.event.publish('school:load')
          this.event.publish('load:menu');
        } else {
          this.router.navigateByUrl('/tutorial', { state: { 'school': school } })
        }
        // else this.show = true;
      });

    })
  }
  search(term: Observable<string>) {
    console.log('in searchhh');
    return term.pipe(
      debounceTime(400),
      map(term => term.trim()),
      distinctUntilChanged(),
      filter((term: any) => {
        if (term.search(/^\s*$/i) == 0 || term.search(/^_*$/i) == 0 || term.length < 3) {
          this.schools = undefined;
          return false;
        }
        else return true;
      }),
      switchMap((term) => {
        this.showSpinner = true;
        this.schools = undefined;
        return this.multiSchoolService.getSchools(term);
      })
    )
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolSearchPage');
  }
  ionViewDidEnter() {
    this.menu.enable(false);
    setTimeout(() => {
      this.searchBar.setFocus();
    }, 100);
  }
  // ionViewWillEnter(){
  //   this.getSchool();
  // }
  ionViewWillLeave() {
    this.menu.enable(true);
  }
  async showLoading(message) {
    this.loading = await this.loadingCtrl.create({
      message: message
    });
    this.loading.setCssClass(`direction-ltr`);
    console.log(this.loading)
    await this.loading.present();
  }

}
