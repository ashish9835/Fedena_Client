import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { SchoolOptionsPage } from './school-options';
@NgModule({
    declarations: [
        SchoolOptionsPage
    ],
    imports: [
        IonicModule
    ],
})



export class SchoolOptionsPageModule { }