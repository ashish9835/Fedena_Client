import { Component } from '@angular/core';
import { NavController, NavParams } from '@ionic/angular';
import { EventsService } from 'src/providers/events/events.service';
import { MultiSchool } from 'src/providers/multi-school';

/**
 * Generated class for the SchoolOptionsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-school-options',
  templateUrl: 'school-options.html',
  styleUrls:['school-options.scss']
})
export class SchoolOptionsPage {

  constructor(public multiSchool:MultiSchool,public navCtrl: NavController, public navParams: NavParams,public events:EventsService) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolOptionsPage');
  }
  removeSchool(){
    let context = this.navParams.data.context;
    let schoolId = this.navParams.data.key;
    console.log(this.navParams.data)
    context.loggedInSchools = context.loggedInSchools.filter((key)=>{
      if(key.key === schoolId){return false;}else{return true;}
    });
    this.multiSchool.removeLoggedInSchool(schoolId);
    context.schoolSwitched = false;
    this.events.publish('dismiss:overlay', {});
    console.log("logged in school - - -  "+context.loggedInSchools.length)
    if(context.loggedInSchools.length === 0){
      context.navCtrl.setRoot('SchoolLoginPage');
    }
   
  }

}
