import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { DirectivesModule } from 'src/directives/directives.module';
import { SchoolsListPage } from './schools-list';
import { SchoolsListPageRoutingModule } from './schools-list-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SchoolsListPageRoutingModule,
    PipesModule,
    DirectivesModule
  ],
  declarations: [SchoolsListPage]
})
export class SchoolsListPageModule { }
