import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, LoadingController, MenuController, NavController, PopoverController, ToastController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { TranslateService } from '@ngx-translate/core';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { MultiSchool } from 'src/providers/multi-school';
import { User } from 'src/providers/user';
import { SchoolOptionsPage } from './school-options/school-options';
@Component({
  selector: 'page-schools-list',
  templateUrl: 'schools-list.html',
  styleUrls: ['schools-list.scss']
})
export class SchoolsListPage implements OnInit {
  loading: any;
  loggedInSchools: any[] = [];
  showNavbar: boolean = false;
  context: any = this;
  hideLogo: boolean = false;
  schoolSwitched: boolean = true;
  TOAST_MAX_SCHOOLS_TEXT = "You can add only 5 schools at max.";
  REMOVE_SCHOOL_CONFIRMATION_TEXT = "This will logout and remove the school from this list.";
  DONT_ASK_AGAIN_TEXT = "Don't ask again.";
  ARE_YOU_SURE_TEXT = "Are you sure ?";
  OK = 'OK';
  CANCEL = 'Cancel';
  constructor(
    private toastCtrl: ToastController,
    private alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    public popover: PopoverController,
    public user: User,
    public event: EventsService,
    public multiSchoolService: MultiSchool,
    public translate: TranslateService,
    public menu: MenuController,
    public storage: Storage,
    public navCtrl: NavController,
    public router: Router,
    public commonService: CommonService
  ) {
    this.showNavbar = this.router.getCurrentNavigation().extras.state.showNavbar || false;
    this.intitTranslations();
  }
  ngOnInit() { }
  intitTranslations() {
    [
      'TOAST_MAX_SCHOOLS_TEXT',
      'REMOVE_SCHOOL_CONFIRMATION_TEXT',
      'DONT_ASK_AGAIN_TEXT',
      'ARE_YOU_SURE_TEXT',
      'OK',
      'CANCEL'
    ].forEach((key: string) => {
      this.translate.get('school_search.' + key.toLowerCase()).subscribe(text => {
        this[key] = text;
      })
    })
  }
  async presentPopover(myEvent, key) {
    myEvent.stopPropagation();
    console.log("my event");
    console.log(myEvent)
    const popover = await this.popover.create({
      component: SchoolOptionsPage,
      cssClass: 'school-popover',
      event: myEvent,
      translucent: true,
      componentProps: { key: key, context: this.context }
    });
    this.event.subscribe('dismiss:overlay', () => {
      if (popover)
        popover.dismiss();
    })
    return await popover.present();
  }
  ionViewWillEnter() {
    console.log('ionViewDidLoad SchoolsListPage');
    this.menu.enable(false);
    this.listLoggedInSchools();
  }
  async addNewSchool() {
    if (this.loggedInSchools.length === 5) {
      console.log("enterdo")
      let toast = await this.toastCtrl.create({ message: this.TOAST_MAX_SCHOOLS_TEXT, duration: 1000, position: 'top' });
      toast.present()
      return;
    }
    this.router.navigateByUrl('/school-search');
  }
  listLoggedInSchools() {
    this.commonService.presentLoading('loading')
    this.storage.get('schools').then((val) => {
      console.log(val)
      for (const key in val) {
        let vval = val[key];
        vval['key'] = key;
        this.loggedInSchools.push(vval);
      }
      this.commonService.dismissloading();
    });
  }
  goToLoginPage(school) {
    this.commonService.presentLoading('Loading school...')
    this.multiSchoolService.switchSchool(school).then(() => {
      this.schoolSwitched = true;
      this.user.getAccessToken().then((value) => {
        this.commonService.dismissloading();
        if (value) {
          this.event.publish('user:refresh');
          try {
            if (this.router.url === "/tabs") {
              // this.navCtrl.getViews()[0].instance.tabRef.select(0)
            }
          } catch (e) { console.log("errror") }
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tabs', { replaceUrl: true })
        } else {
          this.router.navigateByUrl('/tutorial', { state: { 'school': school } })
        }
      });
    })
  }
  ionViewWillLeave() {
    this.menu.enable(true);
    this.hideLogo = true;
  }
  async showConfirmationBox($event, key) {
    $event.stopPropagation();
    if (window.localStorage.getItem('showRemoveSchoolPrompt') === "false") { this.removeSchool(key); return };
    let okBtnString = 'OK';
    const alert = await this.alertCtrl.create({
      message: this.ARE_YOU_SURE_TEXT,
      cssClass: 'school-remove-alert',
      subHeader: this.REMOVE_SCHOOL_CONFIRMATION_TEXT,
      buttons: [
        {
          text: this.OK,
          handler: () => {
            this.removeSchool(key);
            console.log("remove clicked...")
          }
        },
        {
          text: this.CANCEL,
          handler: () => { console.log("cancel clicked...") }
        }
      ].reverse(),
      inputs: [
        {
          type: 'checkbox',
          label: this.DONT_ASK_AGAIN_TEXT,
          handler: (val) => {
            if (val.checked) {
              window.localStorage.setItem('showRemoveSchoolPrompt', 'false');
            } else window.localStorage.removeItem('showRemoveSchoolPrompt');
          }
        }
      ]

    });
    await alert.present();
  }
  removeSchool(key) {
    let context = this.context;
    let schoolId = key;
    context.loggedInSchools = context.loggedInSchools.filter((key) => {
      if (key.key === schoolId) { return false; } else { return true; }
    });
    this.multiSchoolService.removeLoggedInSchool(schoolId);
    context.schoolSwitched = false;
    console.log("logged in school - - -  " + context.loggedInSchools.length)
    if (context.loggedInSchools.length === 0) {
      context.navCtrl.setRoot('SchoolLoginPage');
    }
  }
}
