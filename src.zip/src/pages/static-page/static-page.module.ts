import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { StaticPagePage } from './static-page';
import { PipesModule } from 'src/pipes/pipes.module';
import { StaticPagePageRoutingModule } from './static-page-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        StaticPagePageRoutingModule,
        PipesModule
    ],
    declarations: [StaticPagePage]
})
export class StaticPagePageModule { }
