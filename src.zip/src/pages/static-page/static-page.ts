import { Component, OnInit } from '@angular/core';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { Profile } from 'src/providers/profile';
import { User } from 'src/providers/user';
import { StaticPageModel } from 'src/models/tutorials/staticPage';
import { AppSettings } from 'src/models/app-settings';
import { NavController } from '@ionic/angular';
import { Router, ActivatedRoute } from '@angular/router';
import { Storage } from '@ionic/storage';
@Component({
  selector: 'page-static-page',
  templateUrl: 'static-page.html',
  styleUrls: ['./static-page.scss'],
})
export class StaticPagePage implements OnInit {
  schoolLogo = AppSettings.SCHOOL_LOGO;
  profilePhoto: string;
  connectAppPage: any = '';
  token = '';
  page = 0;
  constructor(
    private iab: InAppBrowser,
    private emailComposer: EmailComposer,
    private callNumber: CallNumber,
    private profileService: Profile,
    private userService: User,
    private navCtrl: NavController,
    private route: ActivatedRoute,
    private router: Router,
    private storage:Storage
  ) {
    this.page = this.route.snapshot.params.id;
    if (AppSettings.MULTI_SCHOOL_MODE) {
      this.storage.get('logo_profile_url').then(val => { this.schoolLogo = val });
    }
    this.page = this.route.snapshot.params.id;
    const temp = localStorage.getItem(JSON.stringify(this.page));
    if (temp === null) {
      this.connectAppPage = '';
    } else {
      this.connectAppPage = JSON.parse(temp);
    }

    this.getPage();
  }
  getPage() {
    this.profileService.loadStaticPage(this.page).subscribe(
      (response: any) => {
        if (response.success === true) {
          this.connectAppPage = new StaticPageModel(response.connect_app_page);
          const entr = this.connectAppPage.content;
          const urllRegex = /(?:(?:href="|src=")?(?:https?|ftp|file):\/\/|ftp\.)(?:\([-A-Z0-9+&@#\/%=~_|$?!:.]*\)|[-A-Z0-9+&@#\/%=~_|$?!:,.])*(?:\([-A-Z0-9+&@#\/%=~_|$?!:,.]*\)|[A-Z0-9+&@#\/%=~_|$][^ ,><]+[^\s[",><]*)/igm;
          const emailRegex = /((mailto:)?[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/ig
          const mobileRegex = /[^\d](([+]?\d{2,3}[.\-\s]?)?(\d{3}[.\-]?){2}\d{4})(([^\d\/\.]|$)+?)/ig
          this.connectAppPage.content = this.connectAppPage.content.replace(urllRegex, (url) => {
            let urlregex = /(?:(?:https?|ftp|file):\/\/|ftp\.)((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))+)/igm
            if (!(/^href\=\"|src\=\"/ig).test(url)) {
              console.log("match found:  ")
              console.log(url)
              let fullUrl = url.trim();
              if (!fullUrl.match('^https?:\/\/')) {
                fullUrl = 'http://' + fullUrl;
              }
              let functionn = 'window.open("' + fullUrl + '", "_system", "location=yes");return false;'
              console.log(functionn)
              let onclickk = "onclick='" + functionn + "'"
              console.log(onclickk)
              return '<a href="#"' + onclickk + '>' + fullUrl + '</a>';
            }
            else if ((/^href\=\"/ig).test(url)) {
              console.log("entered href")
              let link = url.match(urlregex)[0];
              console.log(link)
              let functionn = 'window.open("' + link + '", "_system", "location=yes");return false;'
              console.log(functionn)
              let onclickk = "onclick='" + functionn + "'"
              console.log(onclickk)
              return 'href="#" ' + onclickk;

            }
            return url;
          });
          //replaces email address plain text with anchor tags
          this.connectAppPage.content = this.connectAppPage.content.replace(emailRegex, (email) => {
            if (!(/^mailto:/ig).test(email)) {
              return '<a href="' + email + '" target-data="mailopen">' + email + '</a>';
            }
            return email;
          })
        }
      },
      (err) => {
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.back();;
        }
      },
    );
  }

  ngOnInit() {

  }
  handleClick(event) {
    if (event.target.getAttribute('target-data') === 'webulr') {
      this.iab.create(event.target.href, '_blank', 'location=no,toolbar=yes,fullscreen=no,closebuttoncaption=CLOSE');
      return false;
    }
    if (event.target.getAttribute('target-data') === 'call') {
      const str = event.target.href;
      const index = str.lastIndexOf('/');
      const mobile = str.substring(index + 1);
      console.log(mobile);
      this.callNumber.callNumber(mobile, true)
        .then(() => console.log('Launched dialer!'))
        .catch(() => console.log('Error launching dialer'));
      return false;
    }
    if (event.target.getAttribute('target-data') === 'mailopen') {

      this.emailComposer.isAvailable().then((available: boolean) => {
        if (available) {
          // Now we know we can send
        }
      });
      const str = event.target.href;
      const index = str.lastIndexOf('/');
      const emailid = str.substring(index + 1);
      console.log(emailid);

      const email = {
        to: emailid,
        subject: ' ',
        body: ' ',
        isHtml: true,
      };
      this.emailComposer.open(email);
      return false;

    }
  }


}
