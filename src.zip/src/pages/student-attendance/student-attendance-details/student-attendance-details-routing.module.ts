import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentAttendanceDetailsPage } from './student-attendance-details';

const routes: Routes = [
  {
    path: '',
    component: StudentAttendanceDetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StudentAttendanceDetailsPageRoutingModule { }
