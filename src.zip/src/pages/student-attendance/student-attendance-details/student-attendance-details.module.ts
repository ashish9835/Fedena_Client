import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { StudentAttendanceDetailsPage } from './student-attendance-details';
import { StudentAttendanceDetailsPageRoutingModule } from './student-attendance-details-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        StudentAttendanceDetailsPageRoutingModule
    ],
    declarations: [StudentAttendanceDetailsPage]
})



export class StudentAttendanceDetailsPageModule { }
