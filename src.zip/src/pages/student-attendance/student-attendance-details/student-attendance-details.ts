import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'page-student-attendance-details',
  templateUrl: 'student-attendance-details.html',
  styleUrls: ['student-attendance-details.scss']
})
export class StudentAttendanceDetailsPage implements OnInit {

  data: any = [];
  info: any;
  response: any = [];
  date: any;
  totalLeaves: any;
  totalPeriod: any;
  details = {
    endTime: '',
    startTime: '',
    reason: '',
    subjectCode: '',
    subjectName: '',
    employeeData: [],
  };
  constructor(public router: Router) {
    this.info = this.router.getCurrentNavigation().extras.state.data
    // this.date = this.data.date;
    this.response = this.info.periodData;
    // this.totalLeaves = data.total_leaves;
    // this.totalPeriod = data.total_periods;
    for (const period of this.response) {
      // console.log(typeof period.employeeData);
      if (Array.isArray(period.employeeData)) {
        this.data.push(period);
      } else {
        this.details.endTime = period.endTime;
        this.details.startTime = period.startTime;
        // console.log(period.reason);

        this.details.reason = period.reason;

        this.details.subjectCode = period.subjectCode;
        this.details.subjectName = period.subjectName;
        this.details.employeeData = [
          {
            employeeName: period.employeeData.employeeName,
            employeeId: period.employeeData.employeeId,
          },
        ];
        this.data.push(this.details);
      }
      //console.log(this.data);
    }
    console.log(this.response);
    // console.log(this.data);
  }
  ngOnInit() {

  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad StudentAttendanceSubdetails');
  }

}
