import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ChartsModule } from 'ng2-charts';
import { PipesModule } from 'src/pipes/pipes.module';
import { StudentAttendancePage } from './student-attendance';
import { StudentAttendancePageRoutingModule } from './student-attendance-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        StudentAttendancePageRoutingModule,
        ChartsModule
    ],
    declarations: [StudentAttendancePage]
})



export class StudentAttendancePageModule { }
