import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { StudentAttendanceLeaveModel, StudentAttendanceOverviewModel } from 'src/models/student/studentAttendance';
import { CommonService } from 'src/providers/common/common.service';
import { Student } from 'src/providers/student';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-student-attendance',
  templateUrl: 'student-attendance.html',
  styleUrls: ['student-attendance.scss']
})
export class StudentAttendancePage implements OnInit {


  public doughnutChartLabels: string[] = ["", ""];
  public doughnutChartData: number[] = [0, 100];
  public doughnutChartType: string = 'doughnut';
  doughnutChart: any;
  overviews: any;
  isDataLoaded = false;
  type: string = 'overviews';
  attendanceType: string = '';
  token = '';
  studentId = '0';
  today = new Date();
  filterdate = this.today.toISOString();
  month = 10;
  year = 2017;
  overallStartDate = '2014-01-01';
  overallEndDate = '2018-01-01';
  daysPresent = 0;
  totalLeaves: any;
  totalWorkingHours = 0;
  totalWorkingDays = 0;
  dates = [];
  overall = 0;
  subjects: any = [];
  attendances: any = [];
  fullAttendance: boolean = true;

  constructor(
    private translate: TranslateService,
    public navCtrl: NavController,
    private studentService: Student,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.month = this.today.getMonth();
    this.year = this.today.getFullYear();
    this.commonService.presentLoading('Loading attendance');
    this.userService.getAccessToken().then(
      (value) => {
        if (value) {
          this.token = value;
          this.userService.getUserId().then(
            (id) => {
              if (id) {
                this.studentId = id;
                this.loadOverview();
                // this.loadAttendanceInRange();
              } else {
                this.commonService.presentAlert('Session expired');
              }

            });
        } else {
          this.commonService.presentAlert('Session expired');
        }
      });

  }
  ngOnInit() {

  }
  overview() {
    this.commonService.presentLoading('Loading attendance');
    this.loadOverview();
  }

  leaves() {
    // this.loadOverview();
    this.commonService.presentLoading('Loading attendance');
    this.loadAttendanceInRange();
  }

  ionViewDidLoad() {

  }

  compare(date1, date2) {
    const tempDate1 = new Date(date1);
    const tempDate2 = new Date(date2);
    // tslint:disable-next-line:max-line-length
    if (tempDate1.getMonth() === tempDate2.getMonth() && tempDate1.getFullYear() === tempDate2.getFullYear()) return true;
    // tslint:disable-next-line:no-else-after-return
    else return false;
  }
  async loadChart() {
    console.log(this.totalLeaves);
    console.log(this.daysPresent);
    // let strTotalLeaves = 'Total Leaves';
    // let strTotalPresence = 'Total Presence';
    let strTotalLeaves = await this.translate.get('student_attendance.total_leaves').toPromise();
    let strTotalPresence = await this.translate.get('student_attendance.total_presence').toPromise();
    if (this.attendanceType === 'SubjectWise') {
      this.doughnutChartLabels[0] = strTotalLeaves;
      this.doughnutChartLabels[1] = strTotalPresence;
      this.doughnutChartData = [this.totalLeaves, this.totalWorkingHours - this.totalLeaves];
    }
    if (this.attendanceType === 'Daily') {
      this.doughnutChartLabels[0] = strTotalLeaves;
      this.doughnutChartLabels[1] = strTotalPresence;
      this.doughnutChartData = [this.totalLeaves, this.totalWorkingDays - this.totalLeaves];
    }
  }

  updateChart() {
    this.loadChart();

  }
  load() {
    this.commonService.dismissloading();
    this.isDataLoaded = true;
    if (this.totalLeaves === 0 || this.totalLeaves === '-') this.fullAttendance = true;
    else {
      this.fullAttendance = false;
      this.loadChart();
    }

    // this.loadAttendanceInRange();
  }
  loadOverview() {
    this.studentService.studentOverall(this.token, this.studentId).subscribe(
      (response: any) => {

        console.log(response);
        if (response.success === true) {
          this.overviews = new StudentAttendanceOverviewModel(response);
          console.log(this.overviews);
          this.attendanceType = this.overviews.attendanceType;
          this.overallStartDate = this.overviews.startDate;
          this.overallEndDate = this.overviews.endDate;
          this.totalLeaves = this.overviews.totalLeaves;
          if (this.attendanceType === 'SubjectWise') {
            console.log('subject wisse');
            this.totalWorkingHours = this.overviews.totalWorkingHours;
            this.subjects = this.overviews.subjects;
            this.daysPresent = this.totalWorkingHours - this.totalLeaves;
          } else {
            this.totalWorkingDays = this.overviews.totalWorkingDays;
            this.daysPresent = this.totalWorkingDays - this.totalLeaves;
          }
          this.load();
        }

      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );

  }
  viewAttendance(data) {
    this.router.navigateByUrl('/student-attendance-details', { state: { data: data } });
  }
  changeDate() {
    const selectedDate = new Date(this.filterdate);
    this.month = selectedDate.getMonth();
    this.year = selectedDate.getFullYear();

    this.loadAttendanceInRange();
  }
  loadAttendanceInRange() {
    this.dates = [];
    this.studentService.studentAttendancesDetails(
      this.token,
      this.studentId,
      this.overallStartDate,
      this.overallEndDate,
    ).subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        this.attendanceType = response.attendance_type;
        console.log(response);
        if (response.success === true) {
          if (this.attendanceType === 'SubjectWise') {
            console.log('subject wise');
            response.leave_dates.forEach(i => {
              this.dates.push(new StudentAttendanceLeaveModel(i));
            });
            // this.dates = response.leave_dates;
            // this.dates = Object.keys(this.attendances);
            console.log(this.dates);
          } else {
            this.attendances = response.absents;
          }

        }

      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );

  }

  viewDetails(date, data) {
    this.router.navigateByUrl('/student-attendance-details', { state: { data: data, date: date } });
  }
}
