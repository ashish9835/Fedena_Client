import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentClassPage } from './student-class';

const routes: Routes = [
  {
    path: '',
    component: StudentClassPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StudentClassPageRoutingModule { }
