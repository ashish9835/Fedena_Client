import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { StudentClassPage } from './student-class';
import { StudentClassPageRoutingModule } from './student-class-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipesModule,
    StudentClassPageRoutingModule
  ],
  declarations: [StudentClassPage]
})



export class StudentClassPageModule { }
