import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { StudentClassPage } from './student-class';

describe('StudentClassPage', () => {
  let component: StudentClassPage;
  let fixture: ComponentFixture<StudentClassPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StudentClassPage],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(StudentClassPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
