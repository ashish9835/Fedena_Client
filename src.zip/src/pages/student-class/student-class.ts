import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController, Platform } from '@ionic/angular';
import { StudentClassModel } from 'src/models/my-class/studentClass';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Student } from 'src/providers/student';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-student-class',
  templateUrl: 'student-class.html',
  styleUrls: ['student-class.scss']
})
export class StudentClassPage implements OnInit {
  token = ' ';
  userid = '';
  studentId = '0';
  studentClass: any;
  attendanePercentage: number;
  periods: any;
  totalClasses: number;
  totalSubjects: number;
  constructor(
    public platform: Platform,
    private event: EventsService,
    public navCtrl: NavController,
    private studentService: Student,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.init();
  }
  ngOnInit() {

  }
  private init() {
    this.commonService.presentLoading('Loading class');
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.userService.getUserId().then((id) => {
          if (id) {
            this.userid = id;
            this.loadOverview();
          } else {
            this.commonService.presentAlert('Account not found');
          }
        });

      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  loadOverview() {
    this.studentService.studentClass(this.token, this.userid).subscribe(
      (response: any) => {
        this.commonService.dismissloading();
        console.log(response);
        if (response.success === true) {
          this.attendanePercentage = response.attendances.percentage;
          this.studentClass = new StudentClassModel(response);
          console.log(this.studentClass);
          this.totalClasses = this.studentClass.timetables.total;;
          this.periods = this.studentClass.timetables.periods;
          this.totalSubjects = this.studentClass.totalSubjects;
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  pushMySubjectsPage() {
    this.router.navigateByUrl('/subjects');
  }
  pushMyAttendancePage() {
    this.router.navigateByUrl('/student-attendance');
  }
  pushMyTimetablePage() {
    this.router.navigateByUrl('/timetable');
  }
  loadPage() {
    this.init();
  }
}
