import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { StudentsPage } from './students';
import { StudentsPageRoutingModule } from './students-routing.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        StudentsPageRoutingModule
    ],
    declarations: [StudentsPage]
})



export class StudentsPageModule { }
