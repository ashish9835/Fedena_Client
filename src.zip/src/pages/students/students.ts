import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { StudentProfileDetailsModel } from 'src/models/Profile/studentProfileDetails';
import { BatchStudentListModel } from 'src/models/student/student';
import { Batch } from 'src/providers/batch';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Profile } from 'src/providers/profile';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-students',
  templateUrl: 'students.html',
  styleUrls: ['students.scss']
})
export class StudentsPage implements OnInit {
  batch = [];
  students = [];
  fullstudents = [];
  profile: any;
  batchid = '0';
  token = '';
  userid = '';
  key: string;
  page: number = 1;
  constructor(
    private event: EventsService,
    private profileService: Profile,
    public navCtrl: NavController,
    private batchService: Batch,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.commonService.presentLoading('Loading students');
    this.batch = this.router.getCurrentNavigation().extras.state.batch;
    console.log(this.batch);
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.token = value;
        this.batchid = this.batch['id'];
        this.loadStudents();

      } else {
        this.commonService.presentAlert('Session expired');
      }
    });

  }
  ngOnInit() {

  }
  loadProfile(id) {
    this.profileService.loadStudnetProfile(this.token, id).subscribe(
      (response) => {
        this.commonService.dismissloading();
        console.log(response);
        this.profile = new StudentProfileDetailsModel(response);
        console.log(this.profile);
        this.router.navigateByUrl('/my-profile', { state: { profile: this.profile.student } })
        // if (response.success == true) {
        //   this.fullstudents = response.students;
        //   this.students = response.students;
        // }

      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  loadStudents() {
    this.batchService.loadBatchStudents(this.token, this.batchid).subscribe(
      (response) => {
        this.commonService.dismissloading();
        console.log(response);
        const apiResponse: any = response;
        if (apiResponse.success === true) {
          apiResponse.students.forEach((i) => {
            this.fullstudents.push(new BatchStudentListModel(i));
          });
          // this.fullstudents = apiResponse.students;
          this.students = this.fullstudents;
          console.log(this.students);
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
  getItems(ev: any) {
    // Reset items back to all of the items
    // this.initializeItems();
    this.key = ev.target.value;
    // set val to the value of the searchbar
    const val = ev.target.value;
    console.log(val);
    // if the value is an empty string don't filter the items
    if (val && val.trim() !== '') {
      this.students = this.students.filter((data) => {
        return (data.fullName.toLowerCase().indexOf(val.toLowerCase()) > -1);
      });
    } else {
      this.students = this.fullstudents;
    }
  }
  doInfinite(infiniteScroll) {
    console.log('Loading Students');
    setTimeout(() => {
      this.page = this.page + 1;
      this.batchService.loadBatchStudents(this.token, this.batchid, this.page).subscribe(
        (response: any) => {
          this.commonService.dismissloading();
          // const apiResponse:any = response;
          this.fullstudents = [];
          response.students.forEach((i) => {
            this.fullstudents.push(new BatchStudentListModel(i));
          });
          this.students = this.students.concat(this.fullstudents);
          // this.fullstudents = this.fullstudents.concat(response.students);
          console.log(response);
          infiniteScroll.target.complete();
          if (response.status === 500) {
            this.userService.errorHandler();
          }
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.userService.errorHandler();
          }
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        },
      );
    }, 500);
  }
}
