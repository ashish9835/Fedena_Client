import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { SubjectsPage } from './subjects';
import { SubjectsPageRoutingModule } from './subjects-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipesModule,
    SubjectsPageRoutingModule
  ],
  declarations: [SubjectsPage]
})



export class SubjectsPageModule { }
