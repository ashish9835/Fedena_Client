import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { SubjectModel } from 'src/models/my-class/batchAttendance';
import { CommonService } from 'src/providers/common/common.service';
import { Timetable } from 'src/providers/timetable';
import { User } from 'src/providers/user';

@Component({
  selector: 'page-subjects',
  templateUrl: 'subjects.html',
  styleUrls: ['subjects.scss']
})
export class SubjectsPage implements OnInit{
  studentId = '';
  subjects: SubjectModel[] = [];
  token = '';
  constructor(
    public navCtrl: NavController,
    private timetableService: Timetable,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.commonService.presentLoading('Loading subjects');
    this.userService.getAccessToken().then((value) => {
      console.log(value);
      if (value) {
        this.userService.getUserId().then((id) => {
          console.log(id);
          if (id) {
            this.studentId = id;
            this.token = value;
            this.loadSubjects();
          } else {
            this.commonService.presentAlert('User not found')
          }
        });
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  ngOnInit() {

  }
  loadSubjects() {
    this.timetableService.loadSubjects(this.token, this.studentId).subscribe(
      (response: any) => {
        console.log(response);
        this.commonService.dismissloading();
        if (response.success === true) {
          response.subjects.forEach((i) => {
            this.subjects.push(new SubjectModel(i));
          });
          console.log(this.subjects, 'subjects');
        }
      },
      (err) => {
        this.commonService.dismissloading();
        console.log(err.status);
        if (err.status === 500) {
          this.userService.errorHandler();
        }
        if (err.status === 403) {
          this.navCtrl.setDirection('root');
          this.router.navigateByUrl('/tutorial', { replaceUrl: true });
        }
      },
    );
  }
}
