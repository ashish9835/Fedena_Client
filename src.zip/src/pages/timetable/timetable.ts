import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { TimetableModel } from 'src/models/time-table/time-table';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Timetable } from 'src/providers/timetable';
import { User } from 'src/providers/user';
import moment from 'moment';

@Component({
  selector: 'page-timetable',
  templateUrl: 'timetable.html',
  styleUrls: ['timetable.scss']
})
export class TimetablePage implements OnInit {
  @ViewChild('content') content: any;
  currentDate = new Date();
  currentday = moment(this.currentDate).add(0, 'days').format('YYYY-MM-DD');
  day: string = '\'Monday\'';

  isAndroid: boolean = false;
  studentId = '';
  currentDayFound: boolean;
  token = '';
  days = [];
  weekday = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  weekDay = this.weekday[this.currentDate.getDay()];
  employee = false;
  batch: any;
  isPageLoaded: boolean = false;
  constructor(
    private event: EventsService,
    public navCtrl: NavController,
    private timetableService: Timetable,
    private userService: User,
    private commonService: CommonService,
    private router: Router
  ) {
    this.commonService.presentLoading('Loading');
    this.batch = (this.router.getCurrentNavigation().extras.state) ? this.router.getCurrentNavigation().extras.state.batch : null
    this.userService.getRole().then((value) => {
      if (value === 'employee') this.employee = true;
    });
    this.userService.getAccessToken().then((value) => {
      console.log(value);
      if (value) {
        this.token = value;
        this.loadTimetables();
      } else {
        this.commonService.presentAlert('Session expired');
      }
    });
  }
  ngOnInit() {

  }
  ondrag(item) {
    const percent = item.getSlidingPercent();
    if (percent > 0) {
      // positive
      console.log('right side');
    } else {
      // negative
      console.log('left side');
    }
    if (Math.abs(percent) > 1) {
      console.log('overscroll');
    }
  }
  // tapEvent($event: Gesture) {
  //   console.log($event.direction);
  //   for (const day of this.days) {
  //     let index = 0;
  //     if (day.day === this.day) {
  //       index = this.days.indexOf(day);
  //       if ($event.direction === '2') {
  //         if (index + 1 === this.days.length) index = -1;
  //         this.showSegment(this.days[index + 1].day);
  //         break;
  //       }
  //       if ($event.direction === '4') {
  //         if (index - 1 < 0) index = this.days.length;
  //         this.showSegment(this.days[index - 1].day);
  //         break;
  //       }
  //       break;
  //     }
  //   }
  // }

  loadTimetables() {

    if (this.batch) {
      this.timetableService.loadClassTimetables(this.token, this.batch.id).subscribe(
        (response: any) => {
          console.log(response);
          if (response.success === true && response.timetable_data.length > 0) {
            // var index = 0;
            for (const data of response.timetable_data) {
              this.days.push(new TimetableModel(data));
            }
            console.log(this.days);
            for (const day of this.days) {
              if (day.day === this.weekDay) {
                this.showSegment(day.day);
                this.currentDayFound = true;
                break;
              }
            }
            if (!this.currentDayFound) this.showSegment(this.days[0].day);
          }
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.userService.errorHandler();
          }
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        },
      );
    } else {
      this.timetableService.loadTimetables(this.token).subscribe(
        (response: any) => {
          console.log(response);
          if (response.success === true && response.timetable_data && response.timetable_data.length > 0) {
            // var index = 0;
            response.timetable_data.forEach((i) => {
              this.days.push(new TimetableModel(i));
            });
            console.log(this.days);
            /*for (const data of response.timetable_data) {
              this.days.push(data);
            }*/
            for (const day of this.days) {
              if (day.day === this.weekDay) {
                this.showSegment(day.day);
                this.currentDayFound = true;
                break;
              }
            }
            if (!this.currentDayFound) this.showSegment(this.days[0].day);
          } else {
            if (response.status === 500) {
              this.userService.errorHandler();
            }
          }
        },
        (err) => {
          this.commonService.dismissloading();
          console.log(err.status);
          if (err.status === 500) {
            this.userService.errorHandler();
          }
          if (err.status === 403) {
            this.navCtrl.setDirection('root');
            this.router.navigateByUrl('/tutorial', { replaceUrl: true });
          }
        },
      );
    }
    this.commonService.dismissloading();
    this.isPageLoaded = true;
    // this.content.scrollToTop();


  }
  showSegment(i) {
    this.day = i;
    console.log(i);
  }

  hideSegment(a, b) {
    if (a === b) {
      return false;
      // tslint:disable-next-line:no-else-after-return
    } else {
      return true;
    }

  }
}
