import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TrackPage } from './track';


const routes: Routes = [
  {
    path: '',
    component: TrackPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TrackPageRoutingModule {}
