import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { MomentModule } from 'angular2-moment';
import { TrackPageRoutingModule } from './track-routing.module';
import { TrackPage } from './track';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipesModule,
    MomentModule,
    TrackPageRoutingModule
  ],
  declarations: [TrackPage]
})
export class TrackPageModule { }
