import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Transport } from 'src/providers/transport';

/**
 * Generated class for the TrackPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-track',
  templateUrl: 'track.html',
  styleUrls: ['track.scss']
})
export class TrackPage implements OnInit {
  loaded: boolean = true;
  trackingData: any;
  trackParams: any;
  constructor(
    public changeDetector: ChangeDetectorRef,
    public event: EventsService,
    public transport: Transport,
    public navCtrl: NavController,
    public router: Router,
    public commonService: CommonService) {
    //Tracking details which is passed to the page as NavParams stored in 'this.trackParams' variable.
    this.trackParams = this.router.getCurrentNavigation().extras.state.data.trackParams;
    this.loadData();
    //when the 'Track page' is in 'foreground' and a notification is recieved then this callback gets invoked.
    this.event.subscribe('tracking_details:received', (update) => {

      console.log('track page callback invoked.');
      this.trackParams.direction = update.additionalData.payload.direction;
      this.loadData();

    });

  }
  ngOnInit() { }
  ionViewDidLeave() {
    // this.event.unsubscribe('tracking_details:received')
  }
  goback(){
    this.router.navigateByUrl('/transport');
  }
  loadData() {
    this.loaded = false;
    this.commonService.presentLoading('loading')
    this.trackingData = null;
    console.log(this.trackParams)
    if (this.trackParams.url) {
      this.trackingData = {
        url: this.trackParams.url,
        status: 'trackable'
      }
      this.commonService.dismissloading();
      this.loaded = true;
    } else
      this.transport.fetchTrackingUrl(
        this.trackParams.transportId ? this.trackParams.transportId : 0,
        this.trackParams.routeId,
        this.trackParams.vehicleId,
        this.trackParams.stopId,
        this.trackParams.direction).subscribe(
          (res: any) => {
            this.commonService.dismissloading();
            this.trackingData = { ...res.body, ...res };
            this.loaded = true;
          },
          error => {
            this.commonService.dismissloading();
            this.loaded = true;
          }
        );
  }

}
// {
//   "id": 539,
//   "success": true,
//   "url": "https://web.dhundhoo.com/live?apiKey=f4334ca8-cc4f-458a-a7c4-760e9cd960ca&thingId=ka-03-2055",
//   "status": "trackable",
//   "last_message": "{\"event\"=>\"ETA\", \"vehicle_id\"=>79, \"route_id\"=>141, \"stop_id\"=>87, \"message\"=>\"Your commute Route Bus 1 is 2.0 kms away and willbe reaching at drop point shortly.\", \"category\"=>\"pickup\", \"distance\"=>\"2.0\", \"last_updated\"=>nil, \"api_key\"=>\"gvEJt6IRgB_3lQPl5wk9zw\"}",
//   "last_message_time": "2019-02-08T06:36:43.000Z"
// }
