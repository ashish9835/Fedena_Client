import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PipesModule } from 'src/pipes/pipes.module';
import { TransportPage } from './transport';
import { TransportPageRoutingModule } from './transport-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipesModule,
    TransportPageRoutingModule
  ],
  declarations: [TransportPage]
})
export class TransportPageModule { }
