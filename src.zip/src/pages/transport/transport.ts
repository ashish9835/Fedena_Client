import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { CommonService } from 'src/providers/common/common.service';
import { EventsService } from 'src/providers/events/events.service';
import { Transport } from 'src/providers/transport';
/**
 * Generated class for the TransportPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-transport',
  templateUrl: 'transport.html',
  styleUrls: ['transport.scss']
})
export class TransportPage implements OnInit {
  loaded: boolean = false;
  noDetails: boolean = false;
  transportId: number;
  pickupDetails: any;
  dropDetails: any;
  otherRoutesDetails: any = [];
  constructor(
    public storage: Storage,
    public event: EventsService,
    public navCtrl: NavController,
    public transport: Transport,
    public commonService: CommonService,
    public router: Router
  ) {
    this.commonService.presentLoading('loading');
    this.transport.getTransportDetails().subscribe((res: any) => {
      this.loaded = true;
      this.commonService.dismissloading();
      if (res.success && res.transport_details[0] || res.tracking_details) {
        if (res.transport_details[0]) {
          this.pickupDetails = res.transport_details[0].pickup_route_details;
          this.dropDetails = res.transport_details[0].drop_route_details;
          this.pickupDetails['direction'] = 'pickup';
          this.dropDetails['direction'] = 'drop';
          this.transportId = res.transport_details[0].id;
        }
        if (res.tracking_details) {
          this.otherRoutesDetails = res.tracking_details || [];
          console.log(this.otherRoutesDetails);
        }

      } else this.noDetails = true;

      if (!res.transport_details[0] && res.tracking_details.length === 0) {
        this.noDetails = true;
      }
    }, err => {
      this.loaded = true;
      this.noDetails = true;
      console.log(err)
      this.commonService.dismissloading();
    })
  }
  ngOnInit() { }
  goback(){
    this.router.navigateByUrl('/tabs');
  }
  gotoTrackPage(options: any) {
    let data: any = {
      trackParams: {
        transportId: this.transportId,
        routeId: options.id,
        vehicleId: options.vehicle_id,
        stopId: options.vehicle_stop_id,
        direction: options.direction
      }
    };
    if (options.url) {
      data['trackParams']['url'] = options.url;
    }
    this.router.navigateByUrl('/track', { state: { 'data': data } });
  }
}
// {
//   "success": true,
//   "transport_details": [
//       {
//           "id": 539,
//           "pickup_route_details": {
//               "id": 141,
//               "name": "agara lake",
//               "fare": "50.0",
//               "vehicle_id": 79,
//               "vehicle_no": "ka-03-2055",
//               "vehicle_stop_id": 87,
//               "pickup_time": "11:00 AM"
//           },
//           "drop_route_details": {
//               "id": 142,
//               "name": "silkboard",
//               "fare": "80.0",
//               "vehicle_id": 80,
//               "vehicle_no": "ka-51-5445",
//               "vehicle_stop_id": 92,
//               "drop_time": "03:40 AM"
//           }
//       }
//   ]
// }