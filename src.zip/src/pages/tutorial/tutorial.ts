import { Component, OnInit } from '@angular/core';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { Storage } from '@ionic/storage';
import { Platform, MenuController, AlertController, NavController } from '@ionic/angular';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Router } from '@angular/router';
import { EventsService } from 'src/providers/events/events.service';
import { School } from 'src/providers/school';
import { Profile } from 'src/providers/profile';
import { User } from 'src/providers/user';
import { TutorialModel } from 'src/models/tutorials/tutorials';
import { AppSettings } from 'src/models/app-settings';
@Component({
  selector: 'page-tutorial',
  templateUrl: './tutorial.html',
  styleUrls: ['./tutorial.scss'],
})
export class TutorialPage implements OnInit {
  showSkip = true;
  poweredByLogo = AppSettings.POWERED_BY_LOGO;
  founderLogo: string;
  schoolLogo = AppSettings.SCHOOL_LOGO;
  schoolname = AppSettings.SCHOOL_NAME;
  schoolName: string;
  show = false;
  schoolData: any;
  schoolAddress: string;
  schoolContact: string;
  schoolEmail: string;
  schoolWebsite: string;
  errorMessage: string;
  poweredWebsite = AppSettings.POWERED_BY_URL;
  statusbarColour = AppSettings.COLOUR_STATUS_BAR;
  userData = [];
  staticPages = [];
  token = '';
  studentId = '';
  employee = true;
  hideNetworkError: boolean = true;
  announcmentsTotal = '22';
  connectSubscription: any;
  showLangDialog: boolean = false;
  schoolCover: string;
  isMultischoolMode: any = AppSettings.MULTI_SCHOOL_MODE;
  constructor(
    private event: EventsService,
    public platform: Platform,
    private school: School,
    private emailComposer: EmailComposer,
    private iab: InAppBrowser,
    private callNumber: CallNumber,
    private profileService: Profile,
    private userService: User,
    private menu: MenuController,
    private statusBar: StatusBar,
    private storage: Storage,
    private router: Router,
    private navCtrl: NavController
  ) {
    platform.ready().then(() => {
      this.statusBar.overlaysWebView(false);
      this.statusBar.styleLightContent();
      this.statusBar.backgroundColorByHexString(this.statusbarColour);
    });
    if (AppSettings.MULTI_SCHOOL_MODE) {
      if (this.router.getCurrentNavigation().extras.state){
        this.schoolName = (this.router.getCurrentNavigation().extras.state.school.school_title) ? this.router.getCurrentNavigation().extras.state.school.school_title : this.router.getCurrentNavigation().extras.state.school.SCHOOL_NAME;
      } 
      this.storage.get('logo_profile_url').then(val => { this.schoolLogo = val });
      this.storage.get('cover_url').then(val => { this.schoolCover = val })

    }
  }
  ngOnInit() {
  }
  ionViewDidEnter() {
    console.log('ion view did enter');
    this.menu.enable(false);
    this.getSchool();
    this.showLangDialog = false
    this.storage.get('first_launch_lang_dialog_shown').then(complete => {
      this.showLangDialog = (!complete && AppSettings.INAPP_LANGUAGE_SWITCHING) ? true : false;
      this.storage.set('first_launch_lang_dialog_shown', true);
    })
  }
  ionViewWillLeave() {
    this.menu.enable(true);
    this.showLangDialog = false;
  }
  getSchool() {
    this.profileService.getSchool()
      .then((data: any) => {
        console.log('School data received');
        console.log(data);
        console.log(data.error);
        if (data.status === 500) {
          this.userService.errorHandler();
        }
        this.schoolData = new TutorialModel(data);
        console.log(this.schoolData);
        this.schoolName = this.schoolData.schoolDetails.schoolName;
        this.schoolAddress = this.schoolData.schoolDetails.schoolAddress;
        this.schoolContact = this.schoolData.schoolDetails.schoolContactNo;
        this.schoolEmail = this.schoolData.schoolDetails.schoolEmail;
        this.schoolWebsite = this.schoolData.schoolDetails.schoolWebsite;
        this.staticPages = this.schoolData.connectAppPages;
        this.school.setSchool('name', this.schoolData.schoolDetails.schoolName);
        this.school.setSchool('currency', this.schoolData.schoolDetails.currencyType);
        this.show = true;
        this.loginCheck();
      })
      .catch((error) => {
        if (error.status === 500) {
          this.userService.errorHandler();
        }
        if (error.status === 403) {
          this.errorMessage =
            'This institution is currently not available or no longer active.' +
            ' Please contact your admin.';
        }
        console.log(error);
      });
  }

  startApp() {
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.navCtrl.setDirection('root');
        this.router.navigateByUrl('/tabs', { replaceUrl: true })
      } else {
        if (AppSettings.DEMO_MODE)
          this.router.navigateByUrl('demo-login-email')
        else
          this.router.navigateByUrl('login-email')
      }
    });
  }
  loginCheck() {
    this.event.publish('school:load', {});
    this.userService.getAccessToken().then((value) => {
      if (value) {
        this.navCtrl.setDirection('root');
        this.router.navigateByUrl('/tabs', { replaceUrl: true })
      }
      else this.show = true;
    });
  }
  launchpowered() {
    // tslint:disable-next-line:max-line-length
    const browser = this.iab.create(this.poweredWebsite, '_blank', 'location=no,toolbar=yes,fullscreen=no,closebuttoncaption=CLOSE');
    browser.show();
  }
  launch(url) {
    // tslint:disable-next-line:max-line-length
    const browser = this.iab.create(url, '_blank', 'location=no,toolbar=yes,fullscreen=no,closebuttoncaption=CLOSE');
    browser.show();

  }
  call(number) {
    this.callNumber.callNumber(number, true)
      .then(() => console.log('Launched dialer!'))
      .catch(() => console.log('Error launching dialer'));
  }
  sendMail(emailId) {
    this.emailComposer.isAvailable().then((available: boolean) => {
      if (available) {
        // Now we know we can send
      }
    });
    const email = {
      to: emailId,
      subject: ' ',
      body: ' ',
      isHtml: true,
    };
    this.emailComposer.open(email);
  }
  openStaticPage(page) {
    this.router.navigateByUrl('/static-page/' + page);
  }
}
