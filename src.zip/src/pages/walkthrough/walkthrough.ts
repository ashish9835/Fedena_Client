import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { IonSlides, MenuController, NavController, Platform } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { AppSettings } from 'src/models/app-settings';
/**
 * Generated class for the WalkthroughPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
@Component({
  selector: 'page-walkthrough',
  templateUrl: 'walkthrough.html',
  styleUrls: ['walkthrough.scss']
})
export class WalkthroughPage implements OnInit {
  app_name: string;
  @ViewChild('slider', { static: true }) slides: IonSlides;
  showLangDialog: boolean = false;
  activeindex: any = 0;
  constructor(public navCtrl: NavController,
    public menu: MenuController,
    public platform: Platform,
    public storage: Storage,
    public router: Router
  ) {
    this.app_name = AppSettings.APP_NAME;
  }
  ngOnInit() { }
  goToNextSlide() {
    this.slides.slideNext();
  }
  goToStart() {
    this.slides.slideTo(0);
  }
  goToPrevSlide() {
    console.log(this.activeindex, 'prev index');
    this.slides.slidePrev();
  }
  async slideChanged() {
    await this.slides.getActiveIndex().then(async (index) => {
      this.activeindex = index
    })
  }
  getStarted() {
    this.router.navigateByUrl('/school-search');
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad WalkthroughPage');
  }
  gotToHome() {
    this.router.navigateByUrl('/school-login', { state: { showWalkthroughLink: true } });
  }

  ionViewDidEnter() {
    this.menu.enable(false);
    // this.slides._rtl = this.platform.dir() === 'ltr' ? false : true;
    // this.goToStart();
    this.showLangDialog = false
    this.platform.ready().then(() => {
      this.storage.get('first_launch_lang_dialog_shown').then(complete => {
        console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ - - " + complete)
        this.showLangDialog = (!complete && AppSettings.INAPP_LANGUAGE_SWITCHING) ? true : false;
        this.storage.set('first_launch_lang_dialog_shown', true);
      })
    })

  }
  // ionViewWillEnter(){
  //   this.getSchool();
  // }
  ionViewWillLeave() {
    this.menu.enable(true);
    this.showLangDialog = false;

  }

}
