import { Pipe, PipeTransform } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core'
import { DateFormatPipe } from 'angular2-moment/date-format.pipe';
import { School } from '../providers/school';
import *  as moment from 'moment';

/**
 * Generated class for the TranslatorPipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'customDateFormat',
})
export class CustomDateFormatPipe extends DateFormatPipe {
  /**
   * Takes a value and makes it lowercase.
   */

  constructor(private school: School){
    super();
    this.school.getSchool('user_preferred_locale').then(pref_locale=>{
      if(pref_locale){
          moment.locale(pref_locale);
      }else{
          this.school.getSchool('locale').then(locale=>{
             if(locale)
             moment.locale(locale)
             else moment.locale('en');
          })
      }
     
  })
  }
  transform(value: Date | any | string | number, ...args: any[]): string {

    var data = super.transform(value, ...args);
    // console.log(data)
    data = this.postFormat(data);
    return data;
  }
  postFormat(str) {
    var symbolMap = {
      '١': '1',
      '٢': '2',
      '٣': '3',
      '٤': '4',
      '٥': '5',
      '٦': '6',
      '٧': '7',
      '٨': '8',
      '٩': '9',
      '٠': '0'
    };
    return str.replace(/[١٢٣٤٥٦٧٨٩٠]/g, function (match) {
      return symbolMap[match];
    }).replace(/،/g, ',');
  }


}
