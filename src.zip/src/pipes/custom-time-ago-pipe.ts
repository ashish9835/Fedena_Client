import { School } from './../providers/school';
import { Pipe, PipeTransform, ChangeDetectorRef, NgZone } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core'
import { TimeAgoPipe } from 'angular2-moment/time-ago.pipe';
import *  as moment from 'moment';

/**
 * Generated class for the TranslatorPipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'customTimeAgo',
})
export class CustomTimeAgoPipe extends TimeAgoPipe {
  /**
   * Takes a value and makes it lowercase.
   */
  constructor(cdRef: ChangeDetectorRef, ngZone: NgZone, private school: School){
    super(cdRef, ngZone);
    this.school.getSchool('user_preferred_locale').then(pref_locale=>{
      if(pref_locale){
          moment.locale(pref_locale);
      }else{
          this.school.getSchool('locale').then(locale=>{
             if(locale)
             moment.locale(locale)
             else moment.locale('en');
          })
      }
     
  })
  }
  transform(value: Date | moment.Moment, omitSuffix?: boolean): string {
    var data = super.transform(value, omitSuffix);
    // console.log("from the fipe..... . .")
    // console.log(data)
    data = this.postFormat(data);
    return data;
  }
  postFormat(str) {
    var symbolMap = {
      '١': '1',
      '٢': '2',
      '٣': '3',
      '٤': '4',
      '٥': '5',
      '٦': '6',
      '٧': '7',
      '٨': '8',
      '٩': '9',
      '٠': '0'
    };
    return str.replace(/[١٢٣٤٥٦٧٨٩٠]/g, function (match) {
      return symbolMap[match];
    }).replace(/،/g, ',');
  }


}
