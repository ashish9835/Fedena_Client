import { Pipe, PipeTransform } from '@angular/core';

/**
 * Generated class for the KeyValuePipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'keyvalue',
})
export class KeyValuePipe implements PipeTransform {
  /**
   * Takes a value and makes it lowercase.
   */
  transform(value: any, ...args) {
    let entries = [];
    for(let key in value){
      entries.push({key, value:value[key]})
    }
    return entries;
  }
}
