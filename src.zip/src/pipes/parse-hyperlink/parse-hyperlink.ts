import { Pipe, PipeTransform } from '@angular/core';

/**
 * Generated class for the ParseHyperlinkPipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'parseHyperlink',
})
export class ParseHyperlinkPipe implements PipeTransform {
  private readonly urllRegex = /(?:(?:href="|src=")?(?:https?|ftp|file):\/\/|ftp\.|www\.)(?:\([-A-Z0-9+&@#\/%=~_|$?!:.]*\)|[-A-Z0-9+&@#\/%=~_|$?!:,.])*(?:\([-A-Z0-9+&@#\/%=~_|$?!:,.]*\)|[A-Z0-9+&@#\/%=~_|$][^ ,><\r\n]+[^\s[",><]*)/igm;
  private readonly emailRegex = /((mailto:)?[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/ig
  private readonly mobileRegex = /(([+]\d{1,2}[.-\s]?)(\d{3}[.-]?){2}\d{4})/ig
  transform(value: string, ...args) {
    value = value.replace(this.urllRegex, (url) => {
      let urlregex = /(?:(?:https?|ftp|file):\/\/|ftp\.)((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))+)/igm
      if (!(/^href\=\"|src\=\"/ig).test(url)) {
        console.log("match found:  ")
        console.log(url)
        let fullUrl = url.trim();
        if (!fullUrl.match('^https?:\/\/')) {
          fullUrl = 'http://' + fullUrl;
        }
        let functionn = 'window.open("' + fullUrl + '", "_system", "location=yes");return false;'
        console.log(functionn)
        let onclickk = "onclick='" + functionn + "'"
        console.log(onclickk)
        return '<a href="#"' + onclickk + '>' + fullUrl + '</a>';
      }
      else if ((/^href\=\"/ig).test(url)) {
        console.log("entered href")
        let link = url.match(urlregex)[0];
        console.log(link)
        let functionn = 'window.open("' + link + '", "_system", "location=yes");return false;'
        console.log(functionn)
        let onclickk = "onclick='" + functionn + "'"
        console.log(onclickk)
        return 'href="#" ' + onclickk;

      }
      return url;
    });
    //replaces email address plain text with anchor tags
    value = value.replace(this.emailRegex, (email) => {
      if (!(/^mailto:/ig).test(email)) {
        return '<a href="' + email + '" target-data="mailopen">' + email + '</a>';
      }
      return email;
    })

    value = value.replace(this.mobileRegex, (number => {
      console.log("Hello:" + number)
      return '<a href="tel:' + number + '" >' + number + '</a>';
    }))
    return value;
  }
}
