import { NgModule } from '@angular/core';
import { SafeHtmlPipe } from './safe-html/safe-html';
import { SafeUrlPipe } from './safe-url/safe-url';
import { TranslateModule } from '@ngx-translate/core';
import { TranslatorPipe } from '../pipes/translator/translator';
import { CustomDateFormatPipe } from '../pipes/custom-dateformat-pipe';
import { MomentModule } from 'angular2-moment';
import * as moment from '../../node_modules/moment';
import { School } from '../providers/school';
import { PluralizePipe } from '../pipes/pluralize/pluralize';
import { ReplacePipe } from '../pipes/replace/replace';
import { KeysPipe } from '../pipes/keys-pipe';

import { TrimPipe } from './trim';
import { CustomTimeAgoPipe } from '../pipes/custom-time-ago-pipe';
import { KeyValuePipe } from './key-value/key-value';
import { ParseHyperlinkPipe } from './parse-hyperlink/parse-hyperlink';


@NgModule({
    declarations: [SafeHtmlPipe,
    TranslatorPipe, CustomDateFormatPipe, PluralizePipe, ReplacePipe, CustomTimeAgoPipe,TrimPipe,
    KeyValuePipe, ParseHyperlinkPipe, SafeUrlPipe, KeysPipe],
    imports: [],
    exports: [SafeHtmlPipe,
    TranslatorPipe, CustomDateFormatPipe, MomentModule, ReplacePipe, CustomTimeAgoPipe,TrimPipe,
    KeyValuePipe, ParseHyperlinkPipe, SafeUrlPipe, KeysPipe]
})
export class PipesModule {
    constructor(
        private school:School
    ){
        this.school.getSchool('user_preferred_locale').then(pref_locale=>{
            if(pref_locale){
                moment.locale(pref_locale);
            }else{
                this.school.getSchool('locale').then(locale=>{
                   if(locale)
                   moment.locale(locale)
                   else moment.locale('en');
                })
            }
           
        })
       
    }
}